const {
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   mentionedJid,
   processTime,
} = require('@adiwajshing/baileys');
const qrcode = require("qrcode-terminal") 
const moment = require("moment-timezone") 
const fs = require("fs") 
const util = require('util')
const fetch = require('node-fetch')
const os = require('os')
const crypto = require('crypto')
const imageToBase64 = require('image-to-base64')
const axios = require('axios')
const { color, bgcolor } = require('./lib/color')
const { donasi } = require('./lib/donasi')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { exec, spawn } = require("child_process")
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const tiktod = require('tiktok-scraper')
const brainly = require('brainly-scraper')
const ffmpeg = require('fluent-ffmpeg')
const ms = require('parse-ms')
const toMs = require('ms')
const path = require('path')
const PhoneNumber = require('awesome-phonenumber')
const cd = 4.32e+7
const imgbb = require('imgbb-uploader')
const { ind } = require('./language')


/*[--------------------------------------------------------------------------> CONFIGURAÇÕES <--------------------------------------------------------------------]*/
const settingan = JSON.parse(fs.readFileSync('./admin/set.json'))
const {
	limitawal,
	memberlimit,
	cr,
	BotPrefix,
	owner,
	author,
	pack,
	game,
	game1,
	azar1,
	azar2
} = settingan

/*[-----------------------------------------------------------------------------> CONFIGURAÇOES MANUAL MUDAR DONO ETC <-------------------------------------------------------------------]*/
const ownerNumber = `${owner}@s.whatsapp.net`
prefix = BotPrefix
blocked = []   

/*[------------------------------------------------------------------------> FUNÇOES GAMES <------------------------------------------------------------------------]*/
/*[--------------------------------------------------------------------------> LEVEL & XP <-----------------------------------------------------------------------]*/
const {
	getLevelingXp,
	getLevelingLevel,
	getLevelingId,
	addLevelingXp,
	addLevelingLevel,
	addLevelingId
} = require('./lib/level.js')

/*[--------------------------------------------------------------------------> REGISTRO <-----------------------------------------------------------------------]*/
const {
	getRegisteredRandomId,
	addRegisteredUser,
	createSerial,
	checkRegisteredUser
} = require('./lib/register.js')

/*[-------------------------------------------------------------------------------> ATM & LIMIT <---------------------------------------------------------------------------]*/
const {
	addATM,
	addKoinUser,
	checkATMuser,
	bayarLimit,
	confirmATM,
	limitAdd,
	l5imitAdd,
	l10imitAdd,
	l15imitAdd,
	l20imitAdd,
	l30imitAdd,
	l40imitAdd,
	l50imitAdd,
	l80imitAdd,
	l100imitAdd,
	l300imitAdd,
	l500imitAdd,
	l1000imitAdd,
	l2000imitAdd,
	l3000imitAdd,
	l4000imitAdd,
	l5000imitAdd
} = require('./lib/limitatm.js')

/*[-----------------------------------------------------------------------------------> AFK <-----------------------------------------------------------------------------------------------]*/
const {
	addAfkUser,
    checkAfkUser,
    getAfkReason,
    getAfkTime,
    getAfkId,
    getAfkPosition
} = require('./lib/afk.js')
	
/*[----------------------------------------------------------------------> VCARD (CONFIGURAÇOES VERSÃO DO BOT) <-------------------------------------------------------------------------]*/
const vcard = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + 'FN:ADMINISTRADOR NANDO\n' 
            + `ORG: UNIVERSO OTAKU BOT;\n`
            + `TEL;type=CELL;type=VOICE;waid=${owner}:${PhoneNumber('+' + owner).getNumber('international')}\n` 
            + 'END:VCARD' 

       
/*[-----------------------------------------------------------------------------> CARREGAMENTOS DE ARQUIVOS <-------------------------------------------------------------------------------------]*/
const videonye = JSON.parse(fs.readFileSync('./strg/video.json'))
const audionye = JSON.parse(fs.readFileSync('./strg/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./strg/image.json'))
const _leveling = JSON.parse(fs.readFileSync('./database/group/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./database/user/level.json'))
const _registered = JSON.parse(fs.readFileSync('./database/bot/registered.json'))
const welkom = JSON.parse(fs.readFileSync('./database/bot/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./database/bot/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./database/bot/simi.json'))
const event = JSON.parse(fs.readFileSync('./database/bot/event.json'))
const _limit = JSON.parse(fs.readFileSync('./database/user/limit.json'))
const uang = JSON.parse(fs.readFileSync('./database/user/uang.json'))
const antilink = JSON.parse(fs.readFileSync('./database/group/antilink.json'))
const bad = JSON.parse(fs.readFileSync('./database/group/bad.json'))
const badword = JSON.parse(fs.readFileSync('./database/group/badword.json'))
const _afk = JSON.parse(fs.readFileSync('./database/user/afk.json'))
const ban = JSON.parse(fs.readFileSync('./database/user/ban.json'))
const premium = JSON.parse(fs.readFileSync('./database/user/premium.json'))
const divindade = JSON.parse(fs.readFileSync('./database/user/divindade.json'))
const sorte = JSON.parse(fs.readFileSync('./database/group/sorte.json'))
const azar = JSON.parse(fs.readFileSync('./database/group/azar.json'))

/*[---------------------------------------------------------------------------------> FUNÇÃO HORARIO, RELOGIO <-------------------------------------------------------------------------------------------------------------------]*/
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `${pad(hours)} 🎯 Horas 🎯 ${pad(minutes)} 🎯 Minutos 🎯 ${pad(seconds)} 🎯 Segundos 🎯`
}

function addMetadata(packname, author) {	
	if (!packname) packname = 'WABot'; if (!author) author = 'Bot';	
	author = author.replace(/[^a-zA-Z0-9]/g, '');	
	let name = `${author}_${packname}`
	if (fs.existsSync(`./${name}.exif`)) return `./${name}.exif`
	const json = {	
		"sticker-pack-name": packname,
		"sticker-pack-publisher": author,
	}
	const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
	const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

	let len = JSON.stringify(json).length	
	let last	

	if (len > 256) {	
		len = len - 256	
		bytes.unshift(0x01)	
	} else {	
		bytes.unshift(0x00)	
	}	

	if (len < 16) {	
		last = len.toString(16)	
		last = "0" + len	
	} else {	
		last = len.toString(16)	
	}	

	const buf2 = Buffer.from(last, "hex")	
	const buf3 = Buffer.from(bytes)	
	const buf4 = Buffer.from(JSON.stringify(json))	

	const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

	fs.writeFile(`./${name}.exif`, buffer, (err) => {	
		return `./${name}.exif`	
	})	

} 


/*[-------------------------------------------------------------------------------------> START BOT <---------------------------------------------------------------------------------------------------]*/
const client = new WAConnection()
client.logger.level = 'warn'
client.on('qr', qr => {
   qrcode.generate(qr, { small: true })
   console.log(color('[','white'),color('∆','red'),color(']','white'),color('qr already scan.subscribe','white'),color('UNIVERSO','red'),color('OTAKU','white'),color('NAN KILLI','yellow'))
})

client.on('credentials-updated', () => {
	const authInfo = client.base64EncodedAuthInfo()
   console.log(color('credentials updated!','red'))
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t'))
})
fs.existsSync('./session.json') && client.loadAuthInfo('./session.json')
client.on('connecting', () => {
	console.log(color('Bot Conecting...','yellow'))
})
client.on('open', () => {
	console.log(color('Bot Conected...','blue'))
})
client.connect({timeoutMs: 30*1000})

/*[-----------------------------------------------------------------------> DAR BOAS VINDAS NO GRUPO <---------------------------------------------------------------------------]*/
client.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await client.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				teks = `*@${num.split('@')[0]}\*\n\n*╔═════❖•ೋ° °ೋ•❖═════╗*\n     ░▒░▒  🌟  𝙱𝚎𝚖 𝚅𝚒𝚗𝚍𝚘 🌟 ░▒░▒\n     ▒░▒░▒░  🌟 𝙰𝚘 🌟 ▒░▒░▒░\n\n       *╭━─━─━─≪✠≫─━─━─━╮*\n                       ${mdata.subject}\n       *╰━─━─━─≪✠≫─━─━─━╯*\n\n          【🇯🇵】  *𝙿𝚛𝚎𝚎𝚗𝚌𝚑𝚊 𝙾 𝙵𝚘𝚛𝚖𝚞𝚕𝚊𝚛𝚒𝚘* :\n\n               *↬* 🐼 𝙽𝚘𝚖𝚎 :                  🍙\n               *↬* 🐼 𝙸𝚍𝚊𝚍𝚎 :                🍣\n\n\n             *╭────╯•╰────╮*\n            ↬ 𝙵𝚘𝚝𝚘 (𝙾𝚙𝚌𝚒𝚘𝚗𝚊𝚕)\n             *╰────╮•╭────╯*\n\n    *⊰᯽⊱┈─────╌❊╌─────┈⊰᯽⊱*\n               𝚅𝚊𝚒 𝚂𝚎𝚛 𝙰𝚝𝚒𝚟𝚘 𝙽𝚘 𝙶𝚛𝚞𝚙𝚘?\n*╚═════❖•ೋ° °ೋ•❖═════╝*\n              💥    ̿’ ̿’\̵͇̿̿\з=(•̪●)=ε/̵͇̿̿/’̿’̿  ̿  ̿ 💥\n\n             ██████████████]99%\n\n✎﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				teks = `_O Membro @${num.split('@')[0]} Saiu Do Grupo_`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
	
	/*[-----------------------------------------------------------------------> ATUALIZAR BLOCKEAR <-----------------------------------------------------------------------------------------------]*/
	client.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})
	

	/*[--------------------------------------------------------------------------> ATUALIZAR MENSAGEM <-----------------------------------------------------------------------------------------------------------------------]*/
	client.on('message-new', async (mek) => {
		try {
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
            global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			const timi = moment.tz('Asia/Jakarta').add(30, 'days').calendar();
			const timu = moment.tz('Asia/Jakarta').add(20, 'days').calendar();
            body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
			var pes = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''
			const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const txt = mek.message.conversation
			const isCmd = body.startsWith(prefix)
			const tescuk = ["0@s.whatsapp.net"]
			const isGroup = from.endsWith('@g.us')
			const q = args.join(' ')
			const botNumber = client.user.jid
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			pushname = client.contacts[sender] != undefined ? client.contacts[sender].vname || client.contacts[sender].notify : undefined
			const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupDesc = isGroup ? groupMetadata.desc : ''
            const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
            
            /*[----------------------------------------------------------------------> COMANDOS SEGUROS <-----------------------------------------------------------------------------------]*/
            const isEventon = isGroup ? event.includes(from) : false
            const isRegistered = checkRegisteredUser(sender)
            const isBadWord = isGroup ? badword.includes(from) : false
			const isAzar = isGroup ? azar.includes(sender) : false
			const isSorte = isGroup ? sorte.includes(from) : false
            const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
            const isLevelingOn = isGroup ? _leveling.includes(from) : false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : false
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isPremium = premium.includes(sender)
			const isDivindade = divindade.includes(sender)
			const isAfkOn = checkAfkUser(sender)
			const isBanned = ban.includes(sender)
			const isAntiLink = isGroup ? antilink.includes(from) : false
			const isImage = type === 'imageMessage'
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				client.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				client.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const sendImage = (teks) => {
		    client.sendMessage(from, teks, image, {quoted:mek})
		    }
		    const costum = (pesan, tipe, target, target2) => {
			client.sendMessage(from, pesan, tipe, {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` }}})
			}
			const costumimg = ( pesan , tipe, target , caption) => {
			client.sendMessage(from, pesan , tipe , {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: {"imageMessage":{url: 'https://mmg.whatsapp.net/d/f/Ahj0ACnTjSHHm6-HjqAUBYiCu2-85zMZp_-EhiXlsd6A.enc',mimetype: 'image/jpeg',caption: `${caption}`,fileSha256: '0Pk0qJyQFn9FCtslZrydJHRQDKryjYcdP7I3CmRrHRs=',fileLength: '20696',height: 360,width: 382,mediaKey: 'N43d/3GY7GYQpgBymb9qFY5O9iNDXuBirXsNZk+X61I=',fileEncSha256: 'IdFM58vy8URV+IUmOqAY3OZsvCN6Px8gaJlRCElqhd4=',directPath: '/v/t62.7118-24/35174026_475909656741093_8174708112574209693_n.enc?oh=2a690b130cf8f912a9ca35f366558743&oe=6061F0C6',mediaKeyTimestamp: '1614240917',jpegThumbnail: '/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMASAMBIgACEQEDEQH/xAAwAAADAAMBAAAAAAAAAAAAAAAABAUBAwYCAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAoy6kcWS2eH8miq17B553Thh1BgyTY9iULYfndGBmbSwNEV3eWXpjwZElG09WJckXCj8sWBVc1ZKXj2ZYaoWHnc67K3PbKwtZOqzLrzdQAg5fWFRUeCNTQG2pEKJ0wCD/xAAoEAACAgIBAQkAAwEAAAAAAAABAgADBBEScQUQEyEiMTJBYSNRYmP/2gAIAQEAAT8AaZzfEdwWcGMTE1jNv3M1ozDb+SD2jTO+Yigk6A3KqhseIdfkroTYbXQRrkVuJOplKEuOpjtpxF+IjTO+YnZoBvj4pa/msHtMnHZrgymZ6hCnSJsDl+ys7rTpGmevxMwLFS/1fcA7iNzPsDXaH1NccYH+2lJ1SnSNMlOdcbY6iYGa9g4OJzXW9zI7SBJrpjqxsA9zMkcMetf2V7NKD/McgAkxsis7EcA2fkxkqSkaYbMGRu3hr0x6q6ckufaUMpsexj0ma4Y0qDKhqlektyntXiQO4qWI0PONVZWNsNTmZwewekEwo1fpYaMZdvWf2DYrXoO/ARWLNL6VuXiYcSsuK9eXGYtHhM/nsTPVQgb7iDkydRCNBYYx1Ozj6nmSStRIgJ8UH/nMJiTZs/c7RPwExhu+vrH+p//EAB4RAAIBBAMBAAAAAAAAAAAAAAABAhAREjIhMDFC/9oACAECAQE/AOpJsxEqIj4TfNqXygIWpLc+ZEdBH//EAB4RAAICAgIDAAAAAAAAAAAAAAABAjEQETJBAxJx/9oACAEDAQE/AHWVeHQtYrDaNkno7GOzxP10xzWipDHZHidx+EuQz//Z',scansSidecar: 'choizTOCOFXo21QcOR/IlCehTFztHGnB3xo4F4d/kwmxSJJIbMmvxg==',scanLengths: [Array],midQualityFileSha256: '68OHK4IyhiKDNgNAZ3SoXsngzYENebQkV4b/RwhhYIY=',midQualityFileEncSha256: '2EYOLCXx+aqg9RyP6xJYChQNbEjXZmc0EcSwHzoyXx0='}}}})
			}
	    


			/*[---------------------------------------------------------------------> FUNÇÃO BARRA DE LEVEL <-----------------------------------------------------------------------------------]*/
			var per = '*[▒▒▒▒▒▒▒▒▒▒] 0%*'
			const peri = 5000 * (Math.pow(2, getLevelingLevel(sender)) - 1)
			const perl = peri-getLevelingXp(sender) 
			const resl = Math.round(100-((perl/getLevelingXp(sender))*100))
			if (resl <= 10) {
				per = `*[█▒▒▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 20) {
				per = `*[██▒▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 30) {
				per = `*[███▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 40) {
				per = `*[████▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 50) {
				per = `*[█████▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 60) {
				per = `*[██████▒▒▒▒] ${resl}%*`
			} else if (resl <= 70) {
				per = `*[███████▒▒▒] ${resl}%*`
			} else if (resl <= 80) {
				per = `*[████████▒▒] ${resl}%*`
			} else if (resl <= 90) {
				per = `*[█████████▒] ${resl}%*`
			} else if (resl <= 100) {
				per = `*[██████████] ${resl}%*`
			} 
				
				
			/*[---------------------------------------------------------------------> EXPIRAÇÃO AUTOMATICA <-------------------------------------------------------------------------------------]*/
			expiredCheck()
			
			/*[--------------------------------------------------------------------> FUNÇOES RANK, TITULOS <---------------------------------------------------------------------------------------]*/
			const levelRole = getLevelingLevel(sender)
   	     var role = '*𝔹𝕦𝕤𝕔𝕒𝕟𝕕𝕠 ℙ𝕠𝕕𝕖𝕣*'
   	     if (levelRole <= 1) {
   	         role = '*𝔼𝕟𝕔𝕠𝕟𝕥𝕣𝕒𝕟𝕕𝕠 𝔸 𝕍𝕖𝕣𝕕𝕒𝕕𝕖*'
   	     } else if (levelRole <= 2) {
   	         role = '*ℙ𝕖𝕣𝕤𝕚𝕤𝕥𝕖𝕟𝕔𝕚𝕒*'
	     } else if (levelRole <= 4) {
   	         role = '*𝚀𝚞𝚎𝚋𝚛𝚊𝚗𝚍𝚘 𝙱𝚊𝚛𝚛𝚎𝚒𝚛𝚊𝚜*'
		 } else if (levelRole <= 6) {
   	         role = '*𝙴𝚡𝚙𝚕𝚘𝚛𝚊𝚍𝚘𝚛 𝙳𝚎 𝙼𝚞𝚗𝚍𝚘𝚜*'
		 } else if (levelRole <= 8) {
   	         role = '*ℂ𝕒𝕔̧𝕒𝕕𝕠𝕣 ℝ𝕒𝕟𝕜 𝔸*'
		 } else if (levelRole <= 10) {
   	         role = '*General De Combate*'
	     } else if (levelRole <= 12) {
   	         role = '*ℙ𝕣𝕚𝕟𝕔𝕖𝕤𝕒 (ℙ𝕣𝕚𝕟𝕔𝕚𝕡𝕖) 𝔻𝕒 𝔾𝕦𝕖𝕣𝕣𝕒*'
	     } else if (levelRole <= 14) {
   	         role = '*𝙲𝚕𝚊𝚜𝚜𝚎 𝚂*'
	     } else if (levelRole <= 16) {
   	         role = '*𝙳𝚎𝚖𝚘𝚗𝚒𝚘 𝙰𝚗𝚝𝚒𝚐𝚘*'
	     } else if (levelRole <= 18) {
   	         role = '*ℂ𝕝𝕒𝕤𝕤𝕖 ℕ𝕒𝕔𝕚𝕠𝕟𝕒𝕝*'
	     } else if (levelRole <= 20) {
   	         role = '*𝙿𝚛𝚒𝚗𝚌𝚒𝚙𝚎 (𝙿𝚛𝚒𝚗𝚌𝚎𝚜𝚊) 𝙳𝚘𝚜 𝚁𝚎𝚒𝚗𝚘𝚜*'
	     } else if (levelRole <= 22) {
   	         role = '*ℍ𝕖𝕣𝕠𝕚 (ℍ𝕖𝕣𝕠𝕚𝕟𝕒) 𝕄𝕦𝕟𝕕𝕚𝕒𝕝*'
		 } else if (levelRole <= 24) {
   	         role = '*𝙰𝚜𝚌𝚎𝚗𝚌̧𝚊̃𝚘 𝙿𝚊𝚛𝚊 𝙻𝚘𝚛𝚍 𝙳𝚎𝚖𝚘𝚗𝚒𝚘*'
		 } else if (levelRole <= 26) {
   	         role = '*𝔸𝕤𝕔𝕖𝕟𝕔̧𝕒̃𝕠 ℙ𝕒𝕣𝕒 𝔻𝕚𝕧𝕚𝕟𝕕𝕒𝕕𝕖*'
		 } else if (levelRole <= 28) {
   	         role = '*𝙲𝚘𝚗𝚑𝚎𝚌𝚎𝚗𝚍𝚘 𝙾𝚜 𝚄𝚗𝚒𝚟𝚎𝚛𝚜𝚘𝚜*'
		 } else if (levelRole <= 30) {
   	         role = '*𝕀𝕞𝕠𝕣𝕥𝕒𝕝𝕚𝕕𝕒𝕕𝕖*'
		 } else if (levelRole <= 32) {
   	         role = 'private'
		 } else if (levelRole <= 34) {
   	         role = 'private'
   	     } else if (levelRole <= 36) {
   	         role = 'corporal'
   	     } else if (levelRole <= 38) {
   	         role = 'Sergeant'
   	     } else if (levelRole <= 40) {
   	         role = 'staff sgt I'
   	     } else if (levelRole <= 42) {
   	         role = 'staff sgt II'
   	     } else if (levelRole <= 44) {
   	         role = 'staff sgt II'
   	     } else if (levelRole <= 46) {
   	         role = 'Sgt 1st class I'
   	     } else if (levelRole <= 48) {
   	         role = 'Sgt 1st class II'
   	     } else if (levelRole <= 50) {
   	         role = 'Sgt 1st class III'
   	     } else if (levelRole <= 55) {
   	         role = 'Ggt 1st class IV'
   	     } else if (levelRole <= 58) {
   	         role = 'Master sgt I'
   	     } else if (levelRole <= 62) {
   	         role = 'Master sgt II'
   	     } else if (levelRole <= 65) {
   	         role = 'Master sgt III'
   	     } else if (levelRole <= 70) {
   	         role = 'Master sgt IV'
   	     } else if (levelRole <= 85) {
   	         role = 'Master sgt V'
   	     } else if (levelRole <= 88) {
   	         role = '2nd Lt I'
   	     } else if (levelRole <= 90) {
   	         role = '2nd Lt II'
   	     } else if (levelRole <= 95) {
   	         role = '2nd Lt III'
   	     } else if (levelRole <= 100) {
   	         role = '2nd Lt IV'
   	     }
   		 
			/*[-----------------------------------------------------------------------> CRIAR NOMES PERSONALIZADOS <-----------------------------------------------------------------------------------------------------------------------------]*/
			var premium = '*𝒩𝒶̃ℴ 𝒮ℴ𝓊* 😔'
			if (isPremium) {
				premium = '*P̷r̷e̷m̷i̷u̷m̷* 🔥'
			} 
			if (isOwner) {
				premium = '*𝙲𝚛𝚒𝚊𝚍𝚘𝚛 𝙳𝚎 𝚃𝚞𝚍𝚘 ⛈️*'
			}
			
            var divindade = '𝓝𝓸𝓹 😢'
			if (isDivindade) {
				divindade = 'Dɪᴠɪɴᴅᴀᴅᴇ 🌫️ '
			}			
			if (isOwner) {
				divindade = '*𝙲𝚛𝚒𝚊𝚍𝚘𝚛 𝙳𝚎 𝚃𝚞𝚍𝚘 ⛅*'
			}	
				
	       /*[-------------------------------------------------------------------------------> FUNÇÃO LEVEL <---------------------------------------------------------------------------]*/
            if (isGroup && isRegistered && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
                if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
                const amountXp = Math.floor(Math.random() * 1) + 100
                const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
                const getLevel = getLevelingLevel(sender)
                addLevelingXp(sender, amountXp)
                if (requiredXp <= getLevelingXp(sender)) {
                    addLevelingLevel(sender, 1)
                    bayarLimit(sender, 2)
                    await reply(ind.levelup(pushname, sender, getLevelingXp,  getLevel, getLevelingLevel, role))
                }
            } catch (err) {
                console.error(err)
            }
        }
         
         /*[---------------------------------------------------------------------------> FUNÇÃO AFK <-----------------------------------------------------------------------------------------]*/
         if (isGroup) {
            mentioneddd = mek.message[Object.keys(mek.message)[0]].contextInfo ? mek.message[Object.keys(mek.message)[0]].contextInfo.mentionedJid : []
            for (let ment of mentioneddd) {
                if (checkAfkUser(ment)) {
                    const getId = getAfkId(ment)
                    const getReason = getAfkReason(getId)
                    const getTime = getAfkTime(getId)
                    reply(ind.afkMentioned(getReason, getTime))
                }
            }
            if (checkAfkUser(sender) && !isCmd) {
                _afk.splice(getAfkPosition(sender), 1)
                fs.writeFileSync('./database/user/afk.json', JSON.stringify(_afk))
                await reply(ind.afkDone(pushname))
            }
        }

          /*[--------------------------------------------------------------------------------> FUNÇÃO CHECANDO LIMIT <-------------------------------------------------------------------------------------]*/
          const checkLimit = (sender) => {
          	let found = false
                    for (let lmt of _limit) {
                        if (lmt.id === sender) {
                            let limitCounts = limitawal - lmt.limit
                            if (limitCounts <= 0) return client.sendMessage(from,`*🇧🇷🇯🇵 seus tickets acabaram 🇯🇵🇧🇷*\n\n*🐼 Compre ou suba de nivel para conseguir mais 🐼*`, text,{ quoted: mek})
                            client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                            found = true
                        }
                    }
                    if (found === false) {
                        let obj = { id: sender, limit: 0 }
                        _limit.push(obj)
                        fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
                        client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                    }
				} 
		
			/*[---------------------------------------------------------------------------> FUNÇÃO LIMIT 0 <--------------------------------------------------------------------------]*/
            const isLimit = (sender) =>{ 
          	if (isOwner ) {return false;}
		      let position = false
              for (let i of _limit) {
              if (i.id === sender) {
              	let limits = i.limit
              if (limits >= limitawal ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
     	  }
     	}
/*[------------------------------------------------------------------------------------> FUNÇÃO LIMIT 5 <-----------------------------------------------------------------------------------------]*/
            const isL5imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 5 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[-------------------------------------------------------------------------------------> FUNÇÃO LIMIT 10 <----------------------------------------------------------------------------]*/
            const isL10imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 10 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[------------------------------------------------------------------------------> FUNÇÃO LIMIT 15 <----------------------------------------------------------------------------------------------]*/
            const isL15imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 15 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[------------------------------------------------------------------------------------------> FUNÇÃO LIMIT 20 <--------------------------------------------------------------------------]*/
            const isL20imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 20 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[-----------------------------------------------------------------------------------> FUNÇÃO LIMIT 30 <-----------------------------------------------------------------------------------------------------------]*/
            const isL30imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 30 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[------------------------------------------------------------------------> FUNÇÃO LIMIT 40 <---------------------------------------------------------------------------------------------]*/
            const isL40imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 40 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[-----------------------------------------------------------------------------> FUNÇÃO LIMIT 50 <---------------------------------------------------------------------------------------]*/
            const isL50imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 50 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[---------------------------------------------------------------------------------> FUNÇÃO LIMIT 80 <----------------------------------------------------------------------------------------------------]*/
            const isL80imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 80 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[---------------------------------------------------------------------------------> FUNÇÃO LIMIT 100 <-----------------------------------------------------------------------------------------------]*/
            const isL100imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 100 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[-----------------------------------------------------------------------------------------------> FUNÇÃO LIMIT 300 <--------------------------------------------------------------------------]*/
            const isL300imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 300 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[-----------------------------------------------------------------------------------------> FUNÇÃO LIMIT 500 <--------------------------------------------------------------------------]*/
            const isL500imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 500 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[---------------------------------------------------------------------------------------------> FUNÇÃO LIMIT 1000 <--------------------------------------------------------------------------]*/
            const isL1000imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 1000 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[----------------------------------------------------------------------------------------------> FUNÇÃO LIMIT 2000 <---------------------------------------------------------------------------------------]*/
            const isL2000imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 2000 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[--------------------------------------------------------------------------------------> FUNÇÃO LIMIT 3000 <----------------------------------------------------------------------------------------------]*/
            const isL3000imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 3000 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[--------------------------------------------------------------------------------------------> FUNÇÃO LIMIT 4000 <-----------------------------------------------------------------------------------------]*/
            const isL4000imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 4000 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
/*[---------------------------------------------------------------------------------------> FUNÇÃO LIMIT 5000 <----------------------------------------------------------------------------------------------------]*/
            const isL5000imit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 5000 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
     	   /*[---------------------------------------------------------------------------------> FUNÇÃO SAIR DO GRUPO POR FALTA DE MEMBROS  <-------------------------------------------------------------------------------------]*/
 	       if (isGroup) {
				try {
					const getmemex = groupMembers.length	
				    if (getmemex <= memberlimit) {
					reply(`🚧 _O numero de Membros é muito pouco_ 🚧\n\n *Minimo De Membros = ${memberlimit}*`)
					setTimeout( () => {
 	                           client.groupLeave(from) 
 					   	}, 5000)
							setTimeout( () => {
							client.updatePresence(from, Presence.composing)
							reply("1️⃣")
						}, 4000)
							setTimeout( () => {
							client.updatePresence(from, Presence.composing)
							reply("2️⃣")
						}, 3000)
							setTimeout( () => {
							client.updatePresence(from, Presence.composing)
							reply("3️⃣")
						}, 2000)
							setTimeout( () => {
							client.updatePresence(from, Presence.composing)
							reply("4️⃣")
						}, 1000)
							setTimeout( () => {
							client.updatePresence(from, Presence.composing)
							reply("5️⃣")
						}, 0)
				    }
		       } catch (err) { console.error(err)  }
 	       }
 
 		   /*[-----------------------------------------------------------------------------> FUNÇOES PALAVRÕES  <----------------------------------------------------------------------------]*/
 	   	if (isGroup && isBadWord) {
            if (bad.includes(messagesC)) {
                if (!isGroupAdmins) {
                    try { 
                        reply("⚠️ *Sem Palavrões No Grupo* ⚠️")
                        setTimeout( () => {
 	                           client.groupRemove(from, sender) 
 					   	}, 5000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("⚠️ *Irei Remove-lo* ⚠️")
							}, 4000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("⚠️ *1* ⚠️")
							}, 3000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("⚠️ *2* ⚠️")
							}, 2000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("⚠️ *3* ⚠️")
							}, 1000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("*「🚧 ANTI PALAVROES 🚧 」*\n\n_Detectei Alguem Falando Um Palavrão_")
							}, 0)
                        } catch { client.sendMessage(from, `🚨 *Acho que estou sem ADM, não consegui remove-lo* 🚨`, text , {quoted : mek}) }
                } else {
                    return reply("*${mdata.subject}*")
                }
            }
        }
 
				/*[---------------------------------------------------------------------> FUNÇÃO ANTILINK <--------------------------------------------------------------------------------------]*/
				if (messagesC.includes("://chat.whatsapp.com/")){
					if (!isGroup) return
					if (!isAntiLink) return
					if (isGroupAdmins) return reply('🇯🇵 *Liberado Para ADMS* 🇯🇵')
					client.updatePresence(from, Presence.composing)
					if (messagesC.includes("#izinadmin")) return reply("#izinadmin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
						reply(`⚠️ *Adeus* ⚠️`)
						setTimeout( () => {
						client.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 1000)
						setTimeout( () => {
						client.updatePresence(from, Presence.composing)
						reply("🚧 _Apagar_ 🚧")
					}, 500)
				}
 	       
 	     
 	           /*[-----------------------------------------------------------------------> FUNÇÃO DINHEIRO <-------------------------------------------------------------------------------]*/
 	           if (isRegistered ) {
 	           const checkATM = checkATMuser(sender)
 	           try {
 	               if (checkATM === undefined) addATM(sender)
 	               const uangsaku = Math.floor(Math.random() * 1) + 10
	                addKoinUser(sender, uangsaku)
  	          } catch (err) {
   	             console.error(err)
   	         }
	        }
/*
]=============================================================================> FUNÇÃO JOGO DO AZAR ACHE A PALAVRA CERTA <==========================================================================[
*/
// PARALAVRA DE AZAR
                if (messagesC.includes(azar1)){
				if (!isGroup) return
                if (!isAzar) return
	            client.updatePresence(from, Presence.composing)
	            if (messagesC.includes("nando")) return reply("*cuidado")
	            const acertu = `${sender.split("@")[0]}@s.whatsapp.net`
	            reply(`⚠️ *Analisando* ⚠️`)
			    var ars = resistencia
			    for( var i = 0; i < ars.length; i++){
			    if ( ars[i] === acertu) {
			    ars.splice(i, 1);
			    i--;
			    fs.writeFileSync('./database/group/azar.json', JSON.stringify(ars))
			     }
			    }
	            setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
                reply("*Voce Perdeu - Vou Retirar Voce Do Jogo*")
	            }, 500)
            }
// PALAVRA DA SORTE
                if (messagesC.includes(azar2)){
				if (!isGroup) return
                if (!isAzar) return
	            client.updatePresence(from, Presence.composing)
	            if (messagesC.includes("nando")) return reply("*Sem spam*")
	            const acertu = `${sender.split("@")[0]}@s.whatsapp.net`
	            reply(`⚠️ *Analisando* ⚠️`)
			    azar.splice(from, 1)
			    fs.writeFileSync('./database/group/azar.json', JSON.stringify(azar))
				setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
				obj2 = '[]'
			      azar.splice(obj2)
				   fs.writeFileSync('./database/group/azar.json', JSON.stringify(azar))
				   reply(`Inteligencia Finalizado`)
				}, 4000)
	            setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
                const mining6 = Math.ceil(Math.random() * 10000)
		      const ale1 = Math.ceil(Math.random() * 150)
		      const ace1 = Math.ceil(Math.random() * 20)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ GANHOU O EVENTO* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	            }, 3000)
            }
           	
             //kolor
			colors = ['red','white','black','blue','yellow','green']
			
			//detector media
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			
			//private chat message
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			
			//group message
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			
			switch(command) { 
/*
]=============================================================================> MENU TEXTO PERSONALIZADOS <==========================================================================[
*/				
				case 'nome': 
				    if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
                    if (isLimit(sender)) return reply(ind.limitend(pusname))
					pngttp = './tmp/ttp.png'
					webpng = './tmp/ttp.webp'
					const ttptext = body.slice(5)
					fetch(`https://api.areltiyan.site/sticker_maker?text=${ttptext}`, { method: 'GET'})
					.then(async res => {
					const ttptxt = await res.json()
					base64Img.img(ttptxt.base64, 'tmp', 'ttp', function(err, filepath) {
					if (err) return console.log(err);
					exec(`ffmpeg -i ${pngttp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${webpng}`, (err) => {
					buffer = fs.readFileSync(webpng)
					client.sendMessage(from, buffer, sticker)
					fs.unlinkSync(webpng)
					fs.unlinkSync(pngttp)
					})
					})
					});
					await limitAdd(sender)
				break
                case 'imgmaker':
		        if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                var ghh = body.slice(9)
		    var quote = ghh.split("/")[0];
		    var wm = ghh.split("/")[1];
		    var bg = ghh.split("/")[2];
		    const pref = `🖋️ *Como Usar* 🖋️: \n${prefix}imgmaker texto/nome/tema\n\n🖋️ *Exemplo* 🖋️ \n\n${prefix}imgmaker Meu Bot É Muito Top/Nando/random`
		    if (args.length < 1) return reply(pref)
		    reply(ind.wait())
		    anu = await fetchJson(`https://terhambar.com/aw/qts/?kata=${quote}&author=${wm}&tipe=${bg}`, {method: 'get'})
		    buffealr = await getBuffer(anu.result)
		    client.sendMessage(from, buffealr, image, {caption: '✒️', quoted: mek})
		    await limitAdd(sender)
			    break
				case 'texto1':
				    if (isBanned) return reply(ind.benned())
                	if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					var gh = body.slice(9)
					var porn = gh.split("/")[0];
					var hub = gh.split("/")[1];
					if (args.length < 1) return reply(`「❗」 🚧 _Como fazer: ${prefix}texto1   Nando / Legal_ 🚧 「❗」`)
					reply(ind.wait())
					alan = await getBuffer(`https://vinz.zeks.xyz/api/pornhub?text1=${porn}&text2=${hub}`)
					client.sendMessage(from, alan, image, {quoted: mek})
					await limitAdd(sender)
				break
				case 'texto2':
				    if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))				
					if (args.length < 1) return reply(ind.wrongf())
					ligh = body.slice(11)
					if (ligh.length > 10) return reply('「❗」 🚧 _O Seu Texto É Muito Longo_ 🚧 「❗」')
					reply(ind.wait())
					lawak = await getBuffer(`https://api.zeks.xyz/api/tlight?text=${ligh}&apikey=apivinz`)
			    	client.sendMessage(from, lawak, image, {quoted: mek})
			   	 await limitAdd(sender)
		  	  break
                case 'texto3':
				    if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					var gh = body.slice(12)
					var gli = gh.split("/")[0];
					var tch = gh.split("/")[1];
					if (args.length < 1) return reply(`「❗」 🚧 _Como fazer: ${prefix}texto3   Nando / Legal_ 🚧 「❗」`)
					reply(ind.wait())
					buffer = await getBuffer(`https://api.zeks.xyz/api/gtext?text1=${gli}&text2=${tch}&apikey=apivinz`)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)
				break
				case 'nulis':
				    if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply(`🧐 *Não vai escrever nada?* 🧐`)
					nul = body.slice(7)
					reply('「❗」⏳ _Estou Fazendo Espera Uns Instantes_ ⏳ 「❗」')
					tak = await getBuffer(`https://api.zeks.xyz/api/nulis?text=${nul}&apikey=apivinz`)
					client.sendMessage(from, tak, image, {quoted: mek, caption: 'Lebih baik nulis sendiri ya kak :*'})
					await limitAdd(sender)				
				break			
				case 'texto4':
				    if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply(`「❗」 🚧 _Como fazer_ : ${prefix}texto4 Nando Legal Demais`)
					har = body.slice(12)
					reply('「❗」⏳ _Estou Fazendo Espera Uns Instantes_ ⏳ 「❗」')
					buffer = await getBuffer(`https://api.zeks.xyz/api/hartatahta?text=${har}&apikey=apivinz`)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)
				break	
                case 'text3d':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
              	    if (args.length < 1) return reply('🧐 *Não vai escrever nada?* 🧐')
                    teks = `${body.slice(8)}`
                    if (teks.length > 10) return client.sendMessage(from, '「❗」 🚧 _O Seu Texto É Muito Longo_ 🚧 「❗」', text, {quoted: mek})
                    buff = await getBuffer(`https://docs-jojo.herokuapp.com/api/text3d?text=${teks}`, {method: 'get'})
                    client.sendMessage(from, buff, image, {quoted: mek, caption: `${teks}`})
			     	await limitAdd(sender)
				break				
/*
]=============================================================================> MENU CODIGO QR <==========================================================================[
*/ 
				case 'qrcode':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					const tex = encodeURIComponent(body.slice(8))
					if (!tex) return client.sendMessage(from, '「❗」 🚧 _Escreve um Texto, Palavra ou Coloque uma URL_ 🚧 「❗」', text, {quoted: mek})
					const buff = await getBuffer(`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${tex}`)
					client.sendMessage(from, buff, image, {quoted: mek})
					await limitAdd(sender)
					break
/*
]=============================================================================> MENU DE BAIXAR MUSICAS & LETRAS DE MUSICAS <==========================================================================[
*/ 
                case 'music':
		if (isBanned) return reply(ind.benned())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
		if (!isRegistered) return reply(ind.noregis())
                teks = body.slice(7)
		    anu = await fetchJson(`http://scrap.terhambar.com/lirik?word=${teks}`, {method: 'get'})
		    reply('✒️ *Letra da musica* ✒️ '+teks+' 🎼🎤 :\n\n'+anu.result.lirik)
		await limitAdd(sender)
                break
                case 'boxmsc':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
                data = await fetchJson(`https://tobz-api.herokuapp.com/api/joox?q=${body.slice(6)}&apikey=BotWeA`, {method: 'get'})
               if (data.error) return reply(data.error)
                 infomp3 = `*🇧🇷🇯🇵 Canção encontrada 🇧🇷🇯🇵*\n*🎧 Titulo 🎧* : ${data.result.judul}\n*🎧 Album 🎧* : ${data.result.album}\n*🎧 Publicados 🎧*: ${data.result.dipublikasi}`
                buffer = await getBuffer(data.result.thumb)
                lagu = await getBuffer(data.result.mp3)
                client.sendMessage(from, buffer, image, {quoted: mek, caption: infomp3})
                client.sendMessage(from, lagu, audio, {mimetype: 'audio/mp4', filename: `${data.result.title}.mp3`, quoted: mek})
                await limitAdd(sender)
				break 
/*
]=============================================================================> MENU DE MOD APK <==========================================================================[
*/				
				case 'mod':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			data = await fetchJson(`https://tobz-api.herokuapp.com/api/moddroid?q=${body.slice(10)}&apikey=BotWeA`)
			hepi = data.result[0] 
			teks = `↬ 🕋 *Nome*: ${data.result[0].title}\n↬ 🕋 *Publicado*: ${hepi.publisher}\n↬ 🕋 *Informação:* ${hepi.mod_info}\n↬ 🕋 *Arquivo*: ${hepi.size}\n↬ 🕋 *Versão Mais Recente*: ${hepi.latest_version}\n↬ 🕋 *Genero*: ${hepi.genre}\n↬ 🕋 *link:* ${hepi.link}\n↬ 🕋 *download*: ${hepi.download}`
			buffer = await getBuffer(hepi.image)
			client.sendMessage(from, buffer, image, {quoted: mek, caption: `${teks}`})
			await limitAdd(sender)
			break
			case 'modx':
			    if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			data = await fetchJson(`https://tobz-api.herokuapp.com/api/happymod?q=${body.slice(10)}&apikey=BotWeA`)
			hupo = data.result[0] 
			teks = `↬ 🕋 *Nome*: ${data.result[0].title}\n↬ 🕋 *Versão*: ${hupo.version}\n↬ 🕋 *Arquivo*: ${hupo.size}\n↬ 🕋 *Root*: ${hupo.root}\n↬ 🕋 *Compra*: ${hupo.price}\n↬ 🕋 *link*: ${hupo.link}\n↬ 🕋 *download*: ${hupo.download}`
			buffer = await getBuffer(hupo.image)
			client.sendMessage(from, buffer, image, {quoted: mek, caption: `${teks}`})
			await limitAdd(sender)
                break
/*
]=============================================================================> MENU FIGURINHAS <==========================================================================[
*/
                case 'anime😢':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/cry?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
                case 'anime+18':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
					case 'animekiss':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/kiss?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
					case 'animegif':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/hug?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
					case '🔥':
					if (!isNsfw) return reply(ind.nsfwoff())
					if (!isRegistered) return reply(ind.noregis())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (isBanned) return reply(ind.benned())
				    ranp = getRandom('.gif')
					rano = getRandom('.webp')
				anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/screed?text=${args[0]}`,{method: 'get'})
				exec(`wget ${anu} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
				case '🦁': 
				case '🐯':
				case '🦊': 
				if (!isNsfw) return reply(ind.nsfwoff())
				if (!isRegistered) return reply(ind.noregis())
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				await limitAdd(sender)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(ind.stikga)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(pack, author)} ${ran} -o ${ran}`, async (error) => {
									 if (error) {
											 reply(ind.stikga())
											 fs.unlinkSync(media)	
											 fs.unlinkSync(ran)
											 }
									client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(ind.wait())
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`⚠️ *Falha, ao converter imagem ${tipe} em figurinha* ⚠️`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(pack, author)} ${ran} -o ${ran}`, async (error) => {
									if (error) {
											 reply(ind.stikga())
											 fs.unlinkSync(media)	
											 fs.unlinkSync(ran)
											 }
									client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else {
						reply(`🚧 _Envie A Imagem Com O Comando ${prefix}🦁_ 🚧`)
					}
					break
					case 'triggered':
				case 'ger':
				 if (!isNsfw) return reply(ind.nsfwoff())
				 if (isLimit(sender)) return reply(ind.limitend(pusname))
				 if (isBanned) return reply(ind.benned())
				 if (!isRegistered) return reply(ind.noregis())
				           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
				           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
				           reply(ind.wait())
				         owgi = await client.downloadAndSaveMediaMessage(ger)
				           anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
				        teks = `${anu.display_url}`
				         ranp = getRandom('.gif')
				        rano = getRandom('.webp')
				        anu1 = `https://some-random-api.ml/canvas/triggered?avatar=${teks}`
				       exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
                        fs.unlinkSync(ranp)
                        if (err) return reply(imd.stikga())
                        nobg = fs.readFileSync(rano)
                        client.sendMessage(from, nobg, sticker, {quoted: mek})
                        fs.unlinkSync(rano)
                })
            
                     } else {
                         reply('🧸 *Mande com uma foto* 🧸')
                  }
				  await limitAdd(sender)
                     break
					 case 'wasted':
				  case 'was':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if(!isRegistered) return reply(ind.noregis())
				if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
				  ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
				  reply(ind.wait())
				  owgi = await client.downloadAndSaveMediaMessage(ger)
				  anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
				  teks = `${anu.display_url}`
				  ranp = getRandom('.gif')
				  rano = getRandom('.webp')
				  anu1 = `https://some-random-api.ml/canvas/wasted?avatar=${teks}`
				  exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
				fs.unlinkSync(ranp)
				if (err) return reply(ind.stikga())
				nobg = fs.readFileSync(rano)
				client.sendMessage(from, nobg, sticker, {
				  quoted: mek
				})
				fs.unlinkSync(rano)
				  })
				
				} else {
				  reply('🧸 *Mande com uma foto* 🧸')
				}
				await limitAdd(sender)
				break
/*
]=============================================================================> MENU IMAGENS <==========================================================================[
*/					
				case 'neko':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			    anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nekonime?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
			    await limitAdd(sender)
				break
                case 'waifus':
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isNsfw) return reply(ind.nsfwoff())
					gatauda = body.slice(8)
					reply(ind.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)
			    break
			    case 'waifu':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			    anu = await fetchJson(`https://tobz-api.herokuapp.com/api/waifu?apikey=BotWeA`)
				buf = await getBuffer(anu.image)
				texs = ` *🐬 Nome da personagem 🐬* : ${anu.name} \n\n*🐋 Descrição 🐋* : ${anu.desc} \n\n*🐳 Fonte 🐳* : ${anu.source} \n\n 🇧🇷🇯🇵`
				client.sendMessage(from, buf, image, { quoted: mek, caption: `${texs}` })
			    await limitAdd(sender)
				 break 
				case 'anime🚹':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				    try {
						res = await fetchJson(`https://tobz-api.herokuapp.com/api/husbu?apikey=BotWeA`)
						buffer = await getBuffer(res.image)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '*Universo Otaku*'})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('❌ *ERROR* ❌')
					}
					await limitAdd(sender)
				break
                case 'anime🚺':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					gatauda = body.slice(8)
					reply(ind.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)	
				break 
                case 'animes':
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isNsfw) return reply(ind.nsfwoff())
					gatauda = body.slice(8)
					reply(ind.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)
					break
				case 'pin':
		            if (!isNsfw) return reply(ind.nsfwoff())
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					client.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.fdci.se/rep.php?gambar=${body.slice(11)}`, {method: 'get'})
					reply(ind.wait())
					n = JSON.parse(JSON.stringify(data));
					nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek, caption: `*🐯 Universo Otaku 🐯*`})
					await limitAdd(sender)
				break
                case 'imgale':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                const trut =['🦁 *Imagem Aleatoria Saindo* 🦁']
					const ttrth = trut[Math.floor(Math.random() * trut.length)]
					truteh = await getBuffer(`https://source.unsplash.com/user/erondu/1600x900`)
					client.sendMessage(from, truteh, image, { caption: '*Universo Otaku*\n\n'+ ttrth, quoted: mek })
					await limitAdd(sender)
					break
                case 'pokemon':
				if (!isNsfw) return reply(ind.nsfwoff())
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=pokemon`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
					break
                case 'loli':
		if (!isNsfw) return reply(ind.nsfwoff())
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomloli?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
			break
			    case 'kpop':
		if (!isNsfw) return reply(ind.nsfwoff())
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomkpop?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'fofo':
		if (!isNsfw) return reply(ind.nsfwoff())
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/husbu2?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'anime':
		if (!isNsfw) return reply(ind.nsfwoff())
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'dog':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=anjing`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
					break
				case 'cat':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=kucing`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
                break
				case 'aleatorio':
				    if (isBanned) return reply(ind.benned())
				    if (!isNsfw) return reply(ind.nsfwoff())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					client.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.fdci.se/rep.php?gambar=${body.slice(11)}`, {method: 'get'})
					reply(ind.wait())
					n = JSON.parse(JSON.stringify(data));
					nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek, caption: `*Eu Acho Qualquer Imagem*`})
					await limitAdd(sender)
					break 
					case 'emoji':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isRegistered) return reply(ind.noregis())
				if (!isNsfw) return reply(ind.nsfwoff())
				anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/emoji2png?emoji=${args[0]}&type=aple`, {method: 'get'})
				jes = await getBuffer(anu)
				client.sendMessage(from, jes, image,{quoted : mek, caption : '${args[0]} _ksksksks_'})
				await limitAdd(sender)
				break
				case 'map':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
               	 anu = await fetchJson(`https://mnazria.herokuapp.com/api/maps?search=${body.slice(5)}`, {method: 'get'})
               	 buffer = await getBuffer(anu.gambar)
              	  client.sendMessage(from, buffer, image, {quoted: mek, caption: `${body.slice(5)}`})
				await limitAdd(sender)
				break
				case 'toimg':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isNsfw) return reply(ind.nsfwoff())
				if (!isRegistered) return reply(ind.noregis())
				if (!isQuotedSticker) return reply('🚧 *Marque Alguma Figurinha* 🚧')
					reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(ran)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '𝗱𝗮?? 𝗷𝗮𝗱𝗶 '})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
				break 
/*
]=============================================================================> MENU CADASTRAR <==========================================================================[
*/  
				case 'registrar':
                if (isRegistered) return  reply(ind.rediregis())
                if (!q.includes('/')) return  reply(ind.wrongf())
                const namaUser = q.substring(0, q.indexOf('/') - 0)
                const umurUser = q.substring(q.lastIndexOf('/') + 1)
                const serialUser = createSerial(20)
                if(isNaN(umurUser)) return await reply('🦧  *A idade tem que ser um numero* 🦧')
                if (namaUser.length >= 30) return reply(`*Seu nome é longo demais*`)
                if (umurUser > 40) return reply(`*Você é muito velho*`)
                if (umurUser < 12) return reply(`*Você é muito novo*`)
                try {
					ppimg = await client.getProfilePicture(`${sender.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
                veri = sender
                if (isGroup) {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await client.sendMessage(from, ppimg, image, {quoted: mek, caption: ind.registered(namaUser, umurUser, serialUser, time, sender)})
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'), 'in', color(sender || groupName))
                } else {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await client.sendMessage(from, ppimg, image, {quoted: mek, caption: ind.registered(namaUser, umurUser, serialUser, time, sender)})
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'))
                }
				break
/*
]=============================================================================> MENU TIKTOK <==========================================================================[
*/
				case 'tiktok':
				if (!isRegistered) return reply(ind.noregis())
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				anu = await fetchJson (`https://docs-jojo.herokuapp.com/api/tiktok_nowm?url=${args[0]}`, {method : 'get' })
				if (anu.error) return reply(anu.error)
					teks = `*From* : ${anu.result.from}\n*Judul* : ${anu.result.title}\n*Upload* : ${anu.result.uploaded}`
					thumb = await getBuffer(anu.result.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result.url)
					client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
					await limitAdd(sender)
					break	
                case 'fototiktok':
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
                    gatauda = body.slice(12)
                    anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/tiktokpp?user=${gatauda}` , {method: 'get'})
			        buff = await getBuffer(anu.result)
                    reply(buff)
			        await limitAdd(sender)
				break	
                case 'perseguir':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				try {
						if (args.length < 1) return client.sendMessage(from, '🚧 *Nome do usuario do tiktok tem que ser o nome certo* 🚧', text, {quoted: mek})
						let { user, stats } = await tiktod.getUserProfileInfo(args[0])
						reply(ind.wait())
						teks = `*ID* : ${user.id}\n*Usuario* : ${user.uniqueId}\n*Nome* : ${user.nickname}\n*Seguidores* : ${stats.followerCount}\n*Seguindo* : ${stats.followingCount}\n*Posts* : ${stats.videoCount}\n*👍🏻* : ${stats.heart}\n`
						buffer = await getBuffer(user.avatarLarger)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*[ERROR]* 🚧 _O Nome De Usuario Não É Valido_ 🚧')
					}
					await limitAdd(sender)
                break					
/*
]=============================================================================> MENU DE BAIXAR AUDIOS E VIDEOS DO YOUTUBE <==========================================================================[
*/
					case 'tube':
				if (isBanned) return reply(ind.benned())	  
				if (!isRegistered) return reply(ind.noregis())
			    if (isLimit(sender)) return reply(ind.limitend(pusname))
                if (args.length < 1) return reply('🐤 *Cade o Texto?* 🐤')
				client.updatePresence(from, Presence.composing)	
			        texto = blody.slice(9)
					anu = await fetchJson(`http://indonesian-java-security.ezyro.com/playmp3.php?apikey=FarhanXCode7&query=${texto}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
				    esc = `${anu.result}`
					teks = `*Titulo* : ${anu.title}\n*Tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.esc.image)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.esc.mp3)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
					await limitAdd(sender)
                break
                case 'yta':
				    if (isBanned) return reply(ind.benned())
                    if (!isRegistered) return reply(ind.noregis())
                    if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply('🐤 *Cade a URL?* 🐤')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(ind.wrogf())
					anu = await fetchJson(`https://st4rz.herokuapp.com/api/yta2?url=${args[0]}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Titulo* : ${anu.title}\n*Tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
					await limitAdd(sender)
                break		
                case 'ytv':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply('🐦 *Cade a URL mano* 🐦')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(ind.stikga())
					anu = await fetchJson(`https://st4rz.herokuapp.com/api/ytv2?url=${args[0]}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Titulo* : ${anu.title}\n*tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
					await limitAdd(sender)	
				break
/*
]=============================================================================> MENU PING VELOCIDADE DA NET DO BOT <==========================================================================[
*/
				case 'ping':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
          		if (!isRegistered) return reply(ind.noregis())
           		 await client.sendMessage(from, `Pong!!!!\nSpeed: ${processTime(time, moment())} _Second_`)
			     await limitAdd(sender)	
					break
/*
]=============================================================================> MENU DO MENU/HELP <==========================================================================[
*/					
               case 'help': 
				case 'menu':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				    const reqXp  = 5000 * (Math.pow(2, getLevelingLevel(sender)) - 1)
				    const uangku = checkATMuser(sender)
					await costum(ind.menu(pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku, role, client, process,kyun), text, tescuk, cr)
					break
				case 'admin':
                case 'dono':
                case 'creator':
				     if (!isRegistered) return reply(ind.noregis())
				     if (isLimit(sender)) return reply(ind.limitend(pusname))
			         if (isBanned) return reply(ind.benned())
                     client.sendMessage(from, {displayname: "Nan", vcard: vcard}, MessageType.contact, { quoted: mek})
                     client.sendMessage(from, '*Esse é o numero do meu dono, cuidado quando for mandar mensagem para ele, voce pode ser bloqueado*',MessageType.text, { quoted: mek} )
                     await limitAdd(sender)	
                     break 
/*
]=============================================================================> MENU DE ADICIONAR OU REMOVER PREVILEGIOS OU CASTIGOS  <=======================================================[
*/					
				    case 'premiar':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnom = `${args[0].replace('@','')}@s.whatsapp.net`
				    premium.push(pnom)
				    fs.writeFileSync('./database/user/premium.json',JSON.stringify(premium))
				    reply(ind.premadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'despremiar':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnom = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = premium
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/premium.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellprem(args[0]))
					await limitAdd(sender)
					break
					case 'premiuns':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem = JSON.parse(fs.readFileSync('./database/user/premium.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Premiums 🇧🇷🇯🇵 ]==*\n'
				    for (let premau of krem){
				 	teks += `┣➢👑 @${premau.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢🐺 *Total de usuarios premiums* : ${krem.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": premium}})
					await limitAdd(sender)
					break
					case 'comprarpremium':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isL1000imit(sender)) return reply(ind.limitend(pusname))	
				    const pnam = `${sender.split('@','')}@s.whatsapp.net`
				    premium.push(pnam)
				    fs.writeFileSync('./database/user/premium.json',JSON.stringify(premium))
				    reply(ind.premadd(sender))
					await l1000imitAdd(sender)
					break
/*
]============> COMANDO COLOCAR NA LISTA DE DIVINDADES  <=======================[
*/
				    case 'divindade':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.onipo())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const pnom1 = `${args[0].replace('@','')}@s.whatsapp.net`
				    divindade.push(pnom1)
				    fs.writeFileSync('./database/user/divindade.json',JSON.stringify(divindade))
				    reply(ind.divindadeadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exdivindade':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (!isOwner) return reply(ind.onipo())
				    const hnom1 = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = divindade
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom1) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/divindade.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.delldivindade(args[0]))
					await limitAdd(sender)
					break
					case 'divindades':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem1 = JSON.parse(fs.readFileSync('./database/user/divindade.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Divindade 🇧🇷🇯🇵 ]==*\n'
				    for (let premau1 of krem1){
					teks += `┣➢👑 @${premau1.replace('@s.whatsapp.net','')}\n`
				    }
			 	    teks += `┣➢🐺 *Total de usuarios Divinos* : ${krem1.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": divindade}})
					await limitAdd(sender)
					break
/*
]=============================================================================> MENU INFORMAÇOES DO BOT <==========================================================================[
*/
				case 'info':
				     if (!isRegistered) return reply(ind.noregis())
				     if (isLimit(sender)) return reply(ind.limitend(pusname))
			         if (isBanned) return reply(ind.benned())
					me = client.user
					uptime = process.uptime()
					teks = `*Nome bot* : ${me.name}\n*DONO* : *Nando*\n*AUTOR* : Nando\n*NUMERO* : @${me.jid.split('@')[0]}\n*Prefix* : ${prefix}\n*TOTAL CONTATOS BLOQUEADOS* : ${blocked.length}\n\n*BOT ESTA ATIVADO* : ${kyun(uptime)}`
					buffer = await getBuffer(me.imgUrl)
					client.sendMessage(from, buffer, image, {caption: teks, contextInfo:{mentionedJid: [me.jid]}})
					await limitAdd(sender)	
					break
/*
]=============================================================================> MENU LISTA DE BLOQUEADOS <==========================================================================[
*/
				case 'bloqueados': 
			         if (!isRegistered) return reply(ind.noregis())
				     if (isLimit(sender)) return reply(ind.limitend(pusname))
			         if (isBanned) return reply(ind.benned())
					teks = 'LISTA DE BLOQUEADOS\n\n'
					for (let block of blocked) {
						teks += `┣➢ 🇯🇵🇧🇷 @${block.split('@')[0]}\n`
					}
					teks += `𝗧𝗼𝘁𝗮𝗹 : ${blocked.length}`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					await limitAdd(sender)
					break 
/*
]=============================================================================> MENUS <==========================================================================[
*/
				case 'donasi':
				case 'donate':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			    if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					client.sendMessage(from, donasi(), text)
				    await limitAdd(sender)
					break 
/*
]==================================================================> MENU DO EXILAR MEMBRO DOS COMANDOS DO BOT  <======================================================================================[
*/					
					case 'exilar':
					if (isBanned) return reply(ind.benned())
					if (isL50imit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    const pnom3 = `${args[0].replace('@','')}@s.whatsapp.net`
				    ban.push(pnom3)
				    fs.writeFileSync('./database/user/ban.json',JSON.stringify(ban))
				    reply(ind.banadd(args[0]))
					await l50imitAdd(sender)
					break
				
				    case 'buscar':
					if (isL50imit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    const hnom3 = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = ban
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom3) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/ban.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellban(args[0]))
					await l50imitAdd(sender)
					break
					case 'exilados':
                    if (isBanned) return reply(ind.benned())				
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem3 = JSON.parse(fs.readFileSync('./database/user/ban.json'))
				    teks = '*==[ 🇧🇷🇯🇵 ⚔️ Exilado ⚔️ 🇧🇷🇯🇵 ]==*\n'
				    for (let premau3 of krem3){
					teks += `┣➢🛡️ @${premau3.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢⌛ *Total de usuarios Exilados* : ${krem3.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": ban}})	
					await limitAdd(sender)
					break
/*
]=============================================================================> MENU DE RANKS, TOPS, TABELAS <==========================================================================[
*/					
				case 'levels':
				case 'top':
				if (isBanned) return reply(ind.benned())
			    if (!isRegistered) return reply( ind.noregis())
			    if (isLimit(sender)) return reply(ind.limitend(pusname))
				bo = args[0]
				_level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
				uang.sort((a, b) => (a.uang < b.uang) ? 1 : -1)
                let leaderboardlvl = '*┏━┅┅┄┄⟞⟦⟧⟝┄┄┉┉━┓*\n       ℝ𝔸ℕ𝕂 𝔻𝕆𝕊 𝕄𝔼𝕃ℍ𝕆ℝ𝔼𝕊\n*┗━┅┅┄┄⟞⟦⟧⟝┄┄┉┉━┛*\n\n👑 _𝙽𝚘 𝚃𝚘𝚙𝚘 𝙳𝚎𝚜𝚜𝚎 𝚁𝚊𝚗𝚔, 𝙽𝚎𝚖 𝙾𝚜 𝙲𝚎́𝚞𝚜 𝙾𝚞𝚜𝚊 𝙾𝚕𝚑𝚊𝚛 𝙿𝚊𝚛𝚊 𝚅𝚘𝚌𝚎̂ 𝙳𝚎 𝙲𝚒𝚖𝚊._ 👑\n\n🚧 *Quem Estiver No Topo Desse Rank Até Domingo As 22:00 Hrs Ganha 300 Tickets, 2º Ganha 200, 3º Ganha 100.* 🚧'
                let leaderboarduang = '*╔─━━━━━━░★░━━━━━━─╗*\n            ℝ𝔸ℕ𝕂 𝔻𝕆𝕊 𝕄𝕀𝕃𝕀𝕆ℕ𝔸ℝ𝕀𝕆𝕊\n*╚─━━━━━━░★░━━━━━━─╝*\n\n💎 𝔒𝔰 ℜ𝔦𝔠𝔬𝔰, ℭ𝔬𝔫𝔰𝔢𝔤𝔲𝔦𝔫𝔡𝔬 𝔗𝔲𝔡𝔬 ℭ𝔬𝔪 𝔇𝔦𝔫𝔥𝔢𝔦𝔯𝔬, 𝔇𝔢𝔰𝔡𝔢𝔪 𝔇𝔞𝔰 𝔐𝔞𝔦𝔬𝔯𝔢𝔰 𝔏𝔲𝔵𝔲𝔯𝔦𝔞𝔰 𝔇𝔬 𝔐𝔲𝔫𝔡𝔬 💎\n\n🚧 *Quem Estiver No Topo Desse Rank Até Domingo As 22:00 Hrs Ganha 200 Tickets, 2º Ganha 100, 3º Ganha 50.* 🚧'
                let nom = 0
                try {
                    for (let i = 0; i < 10; i++) {
                        nom++
                        leaderboardlvl += `🪨🌹 *[${nom}]* wa.me/${_level[i].id.replace('@s.whatsapp.net', '')}\n┗⊱ ❄️ *XP*: ${_level[i].xp} *Level*: ${_level[i].level}\n`
                        leaderboarduang += `🍱🌟 *[${nom}]* wa.me/${uang[i].id.replace('@s.whatsapp.net', '')}\n┣⊱ 💷 *Uang*: _Rp${uang[i].uang}_\n`
                    }
                    await reply(leaderboardlvl)
                    await reply(leaderboarduang)
                } catch (err) {
                    console.error(err)
                    await reply(` ${len} *🏆 Ainda Não Criei O Top 10 Aguarde 🏆*`)
                }
				await limitAdd(sender)
				break
/*
]=============================================================================> MENU DE PRESENTES <==========================================================================[
*/				
				case 'giftlimit': 
				if (isBanned) return reply(ind.benned())
			    if (!isRegistered) return reply( ind.noregis())
				if (!isOwner) return reply(ind.ownero())
				const nomerr = args[0].replace('@','')
                const jmla = args[1]
                if (jmla <= 1) return reply(`🚧 _O limite minimo de presentes é 1_ 🚧`)
                if (isNaN(jmla)) return reply(`🚧 _O presente deve ser um numero_ 🚧`)
                if (!nomerr) return reply(`🚧 *Você Usou O Comando de Forma Incorreta* 🚧\n\n🕋 Exemplo : ${prefix}presente @556290304536 20`)
                const cysz = nomerr + '@s.whatsapp.net'
                var found = false
                        Object.keys(_limit).forEach((i) => {
                            if(_limit[i].id === cysz){
                                found = i
                            }
                        })
                        if (found !== false) {
                            _limit[found].limit -= jmla
                            const updated = _limit[found]
                            const result = `🎁 _Limite De Cota De Presente_ 🎁\n\n ${createSerial(8)} pada ${moment().format('DD/MM/YY HH:mm:ss')}
*「 🎁 Limite De Cota De Presente 🎁 」*

• Usuario : @${updated.id.replace('@s.whatsapp.net','')}
• Tickets: ${limitawal-updated.limit}`
                            console.log(_limit[found])
                            fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit));
                            reply(result)
                        } else {
                                reply(`⛅ _O Numero ${nomerr} Ainda Não Se Cadastrou_ 🌨️`)
                        }
                break
/*
]=============================================================================> MENU ACHAR MEMBROS ALEATORIAMENTE <==========================================================================[
*/
				case 'parceiro':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply( ind.noregis())
                if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('🧺 *Procurando um Parceiro* 🧺')
                await reply(`wa.me/${anug}`)
                await reply( `*🐻 Encontrei um vai la conversa 🐻*\n*${prefix}parceiro* 🐦 *Use esse comando se quer encontrar outro* 🐦`)
				await limitAdd(sender)
            break
            case 'next':
			    if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply( ind.noregis())
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('🧺 *Procurando um Parceiro* 🧺')
                await reply(`wa.me/${anug}`)
                await reply( `🐻 Encontrei um vai la conversa 🐻*\n*${prefix}parceiro* 🐦 *Use esse comando se quer encontrar outro* 🐦`)
				await limitAdd(sender)
            break
/*
]=============================================================================> MENU DE TRANSFERENCIA DE TICKETS <==========================================================================[
*/			
				case 'ticket1':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan1 = ('1')
                const tujuan11 = args[0].replace('@','')
				const tujuan11tf = tujuan11 + '@s.whatsapp.net'
                fee = 0 *  tujuan1
                hasiltf = tujuan1 - fee
                bayarLimit(tujuan11tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan11}\n\n🧧 *Valor da transferência* : ${tujuan1} \n\n🧧 *Imposto* : ${fee}`)      
                await limitAdd(sender)
			break
				case 'ticket5':
				if (isBanned) return reply(ind.benned())
				if (isL5imit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan2 = ('5')
                const tujuan22 = args[0].replace('@','')
				const tujuan22tf = tujuan22 + '@s.whatsapp.net'
                fee = 0 *  tujuan2
                hasiltf = tujuan2 - fee
                bayarLimit(tujuan22tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan22}\n\n🧧 *Valor da transferência* : ${tujuan2} \n\n🧧 *Imposto* : ${fee}`)      
                await l5imitAdd(sender)	
			break
				case 'ticket10':
				if (isBanned) return reply(ind.benned())
				if (isL10imit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan3 = ('10')
                const tujuan33 = args[0].replace('@','')
				const tujuan33tf = tujuan33 + '@s.whatsapp.net'
                fee = 0 *  tujuan3
                hasiltf = tujuan3 - fee
                bayarLimit(tujuan33tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan33}\n\n🧧 *Valor da transferência* : ${tujuan3} \n\n🧧 *Imposto* : ${fee}`)      
                await l10imitAdd(sender)	
			break
				case 'ticket50':
				if (isBanned) return reply(ind.benned())
				if (isL50imit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan4 = ('50')
                const tujuan44 = args[0].replace('@','')
				const tujuan44tf = tujuan44 + '@s.whatsapp.net'
                fee = 0 *  tujuan4
                hasiltf = tujuan4 - fee
                bayarLimit(tujuan44tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan44}\n\n🧧 *Valor da transferência* : ${tujuan4} \n\n🧧 *Imposto* : ${fee}`)      
                await l50imitAdd(sender)	
			break
				case 'ticket100':
				if (isBanned) return reply(ind.benned())
				if (isL100imit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan5 = ('100')
                const tujuan55 = args[0].replace('@','')
				const tujuan55tf = tujuan55 + '@s.whatsapp.net'
                fee = 0 *  tujuan5
                hasiltf = tujuan5 - fee
                bayarLimit(tujuan55tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan55}\n\n🧧 *Valor da transferência* : ${tujuan5} \n\n🧧 *Imposto* : ${fee}`)      
                await l100imitAdd(sender)	
			break
				case 'ticket1000':
				if (isBanned) return reply(ind.benned())
				if (isL1000imit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan6 = ('1000')
                const tujuan66 = args[0].replace('@','')
				const tujuan66tf = tujuan66 + '@s.whatsapp.net'
                fee = 0.10 *  tujuan6
                hasiltf = tujuan6 - fee
                bayarLimit(tujuan66tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan66}\n\n🧧 *Valor da transferência* : ${tujuan6} \n\n🧧 *Imposto* : ${fee}`)      
                await l1000imitAdd(sender)	
                break
/*
]=============================================================================> MENU TRANSFERENCIAS DINHEIRO <==========================================================================[
*/
				case 'grana':
				if (isBanned) return reply(ind.benned())
			    if (!isPremium) return reply(ind.premon())
				if (!isRegistered) return reply(ind.noregis())
				if (!q.includes('/')) return  reply(ind.wrongf())
                const tujuan = q.substring(0, q.indexOf('/') - 1)
                const jumblah = q.substring(q.lastIndexOf('/') + 1)
                if(isNaN(jumblah)) return await reply('🚧 _O Valor Tem Que Ser Um Número_ 🚧 ')
                if (jumblah < 100 ) return reply(`🚧 _Transferencia Minima é 100_ 🚧`)
                if (checkATMuser(sender) < jumblah) return reply(`🚧 *Você não tem dinheiro suficiente para fazer a transferência* 🚧`)
                const tujuantf = `${tujuan.replace("@", '')}@s.whatsapp.net`
                fee = 0.30 *  jumblah
                hasiltf = jumblah - fee
                addKoinUser(tujuantf, hasiltf)
                confirmATM(sender, jumblah)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🌟 SUCESSO 🌟 」*\n\n🕋 _Transferido Com Sucesso_ 🕋\n\n↬ 🐼 *De*  : +${sender.split("@")[0]}\n↬ 🐼 *Para* : +${tujuan}\n↬ 💸 *Valor Transferido* : ${jumblah}\n↬ 😨 *Imposto* : ${fee}`)
                break
				case 'dinheiro':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuan00 = args[0].replace('@','')
                const jumblah0 = ('1000')
				if(isNaN(jumblah0)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblah0) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuan0tf = tujuan00 + '@s.whatsapp.net'
                fee = 0.30 *  jumblah0
                hasiltf = jumblah0 - fee
                addKoinUser(tujuan0tf, hasiltf)
                confirmATM(sender, jumblah0)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuan00}\n\n💰 *Valor da transferência* : ${jumblah0}\n\n💰 *Imposto* : ${fee}`)
                break
			    case 'dinheiro+':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuan000 = args[0].replace('@','')
                const jumblah00 = ('10000')
				if(isNaN(jumblah00)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblah00) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuan00tf = tujuan000 + '@s.whatsapp.net'
                fee = 0.30 *  jumblah00
                hasiltf = jumblah00 - fee
                addKoinUser(tujuan00tf, hasiltf)
                confirmATM(sender, jumblah00)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuan000}\n\n💰 *Valor da transferência* : ${jumblah00}\n\n💰 *Imposto* : ${fee}`)
                break
				case 'dinheiro++':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuanp = args[0].replace('@','')
                const jumblahp= ('50000')
				if(isNaN(jumblahp)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblahp) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuanptf = tujuanp + '@s.whatsapp.net'
                fee = 0.30 *  jumblahp
                hasiltf = jumblahp - fee
                addKoinUser(tujuanptf, hasiltf)
                confirmATM(sender, jumblahp)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuanp}\n\n💰 *Valor da transferência* : ${jumblahp}\n\n💰 *Imposto* : ${fee}`)
                break
				case 'dinheiro+++':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuant = args[0].replace('@','')
                const jumblaht= ('100000')
				if(isNaN(jumblaht)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblaht) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuanpttf = tujuant + '@s.whatsapp.net'
                fee = 0.30 *  jumblaht
                hasiltf = jumblaht - fee
                addKoinUser(tujuanpttf, hasiltf)
                confirmATM(sender, jumblaht)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuant}\n\n💰 *Valor da transferência* : ${jumblaht}\n\n💰 *Imposto* : ${fee}`)
                break
/*
]=============================================================================> MENU DO DONO PARA DOAR PONTOS TICKETS ETC... <==========================================================================[
*/
                case 'doarticket':
				if (isBanned) return reply(ind.baned())
				if (!isOwner) return reply(ind.ownerb())
				if (!isRegistered) return reply(ind.noregis())
				if (!q.includes('/')) return  reply(ind.wrongf())
                const destino = q.substring(0, q.indexOf('/') - 1)
                const tudo = q.substring(q.lastIndexOf('/') + 1)
				if(isNaN(jumblah)) return await reply('🚧 _O Valor Tem Que Ser Um Número_ 🚧 ')
                if (checkATMuser(sender) < tudo) return reply(`🐡 *tem certeza?* 🐡`)
                const destinotf = `${destino.replace("@", '')}@s.whatsapp.net`
                fee = 0 *  tudo
                hasiltf = tudo - fee
                bayarLimit(destinotf, hasiltf)
                confirmATM(sender, tudo)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Parabens 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${destino}\n\n🧧 *Valor dado* : ${tudo}\n\n🧧 *Metade vai pro bolso do patrão* : ${fee}\n\n*🇯🇵🇧🇷 Universo Otaku 🇯🇵🇧🇷*`)	
                break
/*
]=============================================================================> MENU DE APOSTAS DE DINHEIRO E XP <==========================================================================[
*/				
				case 'apostaxp':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())   
                      if (isL50imit(sender)) return reply(ind.limitend(pushname))
                      if (isOwner) {
                      const one1 = Math.ceil(Math.random() * 20000)
                      addLevelingXp(sender, one1)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Criador ? Hihihihi ${one1} XP* ⚜️`)
                      }else{ 
                      const mining1 = Math.ceil(Math.random() * 20000)
                      addLevelingXp(sender, mining1)
                      await reply(`*Ha ha ha, ${pushname} Voce esta com sorte? ${mining1} XP*`)
                      }
                    await l50imitAdd(sender)			
				break
				case 'aposta$':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (isL10imit(sender)) return reply(ind.limitend(pushname))
                      if (isOwner) {
                      const one2 = Math.ceil(Math.random() * 20000)
                      addKoinUser(sender, one2)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Criador ? Hihihihi ${one2} R$* ⚜️`)
                      }else{
                      const mining2 = Math.ceil(Math.random() * 11000)
                      addKoinUser(sender, mining2)
                      await reply(`*Ha ha ha, ${pushname} voce esta com sorte? ${mining2} R$*`)
					  }if (isPremium) {
                      const mining3 = Math.ceil(Math.random() * 14000)
                      addKoinUser(sender, mining3)
                      await reply(`*Ha ha ha, ${pushname} voce esta com sorte? ${mining3} R$*`)
                      }if (isDivindade) {
                      const mining4 = Math.ceil(Math.random() * 17000)
                      addKoinUser(sender, mining4)
                      await reply(`*Ha ha ha, ${pushname} voce esta com sorte? ${mining4} R$*`)
                      }
                    await l10imitAdd(sender)	   					
					break
/*
]=============================================================================> MENU DE COMPRA DE TICKETS <==========================================================================[
*/				
				case 'comprar':
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('1')
				const koinPerlimit = 900
				const total = koinPerlimit * payout
				if ( checkATMuser(sender) <= total) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total ){ 
				    confirmATM(sender, total)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar5':
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('5')
				const koinPerlimit1 = 700
				const total1 = koinPerlimit1 * payout
				if ( checkATMuser(sender) <= total1) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total1 ){ 
				    confirmATM(sender, total1)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit1} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar10':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('10')
				const koinPerlimit2 = 700
				const total2 = koinPerlimit2 * payout
				if ( checkATMuser(sender) <= total2) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total2 ){ 
				    confirmATM(sender, total2)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit2} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar50':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('50')
				const koinPerlimit3 = 700
				const total3 = koinPerlimit3 * payout
				if ( checkATMuser(sender) <= total3) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total3 ){ 
				    confirmATM(sender, total3)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit3} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar500':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('500')
				const koinPerlimit4 = 600
				const total4 = koinPerlimit4 * payout
				if ( checkATMuser(sender) <= total4) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total4 ){ 
				    confirmATM(sender, total4)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit4} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar5mil':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('5000')
				const koinPerlimit5 = 500
				const total5 = koinPerlimit5 * payout
				if ( checkATMuser(sender) <= total5) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total5 ){ 
				    confirmATM(sender, total5)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit5} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar50mil':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('50000')
				const koinPerlimit6 = 400
				const total6 = koinPerlimit6 * payout
				if ( checkATMuser(sender) <= total6) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total6 ){ 
				    confirmATM(sender, total6)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit6} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
/*
]=======================> COMANDO DE COMPRA PARA QUEM É PREMIUM <==================[
*/				
				case 'comprarpremium':
				if (isBanned) return reply(ind.benned())
				if (!isPremium) return reply(ind.premon(pushname))	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('100')
				const koinPerlimit7 = 450
				const total7 = koinPerlimit7 * payout
				if ( checkATMuser(sender) <= total7) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total7 ){ 
				    confirmATM(sender, total7)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit7} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ Você é premium promoção 10 tickets por apenas 300,00 RS ⚠️*\n\n*Exemplo : ${prefix}comprar+1*\n\n${createSerial(15)}`)
					}
				break
/*
]=======================> COMANDO DE COMPRA PARA QUEM É DIVINDADE <==================[
*/				
				case 'comprardemais':
				if (isBanned) return reply(ind.benned())
				if (!isDivindade) return reply(ind.deuso(pushname))	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('100')
				const koinPerlimit8 = 250
				const total8 = koinPerlimit8 * payout
				if ( checkATMuser(sender) <= total8) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total8 ){ 
				    confirmATM(sender, total8)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit8} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ Você tem divindade promoção 20 tickets por apenas 300,00 RS KD ⚠️*\n\n*Exemplo : ${prefix}comprar+1*\n\n${createSerial(15)}`)
					}	
				break
/*
]=============================================================================> MENU CONTA, TICKETS, LEVELS<==========================================================================[
*/
				case 'conta':
				if (isBanned) return reply(ind.baned())
				if (!isRegistered) return reply(ind.noregis())
				const kantong = checkATMuser(sender)
				reply(ind.uangkau(pushname, sender, kantong))
				break
				case 'ticket':
				   if (isBanned) return reply(ind.baned())
				   if (!isRegistered) return reply(ind.noregis())
				   checkLimit(sender)
					break 
				case 'level':
				if (isBanned) return reply(ind.baned())
                if (!isRegistered) return reply(ind.noregis())
                if (!isLevelingOn) return reply(ind.lvlnoon())
                if (!isGroup) return reply(ind.groupo())
                const userLevel = getLevelingLevel(sender)
                const userXp = getLevelingXp(sender)
                if (userLevel === undefined && userXp === undefined) return reply(ind.lvlnul())
                const requiredXp = 5000 * (Math.pow(2, userLevel) - 1)
                resul = `*╔═══❖•ೋ° °ೋ•❖═══╗*\n               𝚂𝚝𝚊𝚝𝚞𝚜 𝙳𝚎 𝙻𝚎𝚟𝚎𝚕\n*╚═══❖•ೋ° °ೋ•❖═══╝*\n\n┣⊱ 🌟 *Nome* : ${pushname}\n┣⊱ 🌹 *Numero* : wa.me/${sender.split("@")[0]}\n┣⊱ 🔥 XP :  ${userXp}/${requiredXp}\n┣⊱ 🍄 *Level* : ${userLevel}\n\n 🚧 _Fique Ativo No Grupo & Suba De Level Para Chegar Ao Topo_ 🚧`
                costum(resul, text, tescuk, per)
				break 
/*
]=============================================================================> MENU COMPRA TICKETS DONO <==========================================================================[
*/
				case 'ticket+':
				if (!isGroup) return reply(ind.groupo())
				if (isBanned) return reply(ind.baned())
				if (!isRegistered) return reply(ind.noregis())
				payout = body.slice(10)
				if(isNaN(payout)) return await reply('🚧 _Os Tickets Tem Que Ser Um Numero_ 🚧')
			    if (payout < 10 ) return reply(`🚧 _Transferencia Minima é 10_ 🚧`)
				const koinPerlimit9 = 100
				const total9 = koinPerlimit9 * payout
				if ( checkATMuser(sender) <= total9) return reply(`🚧 *Você Não Tem Dinheiro Suficiente* 🚧`)
				if ( checkATMuser(sender) >= total9 ) {
					confirmATM(sender, total9)
					bayarLimit(sender, payout)
					await reply(`*「 🛒 COMPRA FEITA COM SUCESSO 🛒 」*\n\n↬ 🛍️ *De* : Nan Killi\n↬ 🛍️ *Para* : ${pushname}\n↬ 🛍️ *Pagamento* : ${payout} \n↬ 🛍️ *Preço Dos Tickets* : ${koinPerlimit9}/limit\n↬ 🛍️ *Seu Dinheiro Final* : ${checkATMuser(sender)}\n\n🚧 _Compra Bem Sucedida Numero do Pagamento_ 🚧\n\n${createSerial(15)}`)
				} 
				break
/*
]=============================================================================> MENU BRINCADEIRAS <==========================================================================[
*/ 
				case 'posso':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					posso = body.slice(1)
					const pos =['🇯🇵🇧🇷 Pode 🇯🇵🇧🇷','🇯🇵🇧🇷 Não pode 🇯🇵🇧🇷','🇯🇵🇧🇷 Irei pensar 🇯🇵🇧🇷','🇯🇵🇧🇷 Talvez 🇯🇵🇧🇷','🇯🇵🇧🇷 Voce decide dessa vez 🇯🇵🇧🇷','🇯🇵🇧🇷 Que pergunta sem noção 🇯🇵🇧🇷']
					const so = pos[Math.floor(Math.random() * pos.length)]
					client.sendMessage(from, 'Questão : *'+posso+'*\n\nResposta : '+ so, text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'sorte':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					sorte = body.slice(1)
					const sor =['*1*','*2*','*3*','*4*','*5*','*6*','*7*','*8*','*9*','*10*','*Perdeu 🐣*','*Ganhou 🦁*']
					const te = sor[Math.floor(Math.random() * sor.length)]
					client.sendMessage(from, 'Questão : *'+sorte+'*\n\nResposta : '+ te+'%', text, { quoted: mek })
					await limitAdd(sender)
					break
					break
				case 'quando':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					quando = body.slice(1)
					const qua =['*daqui 1*','*daqui 2*','*daqui 3*','*daqui 4*','*daqui 5*','*daqui 6*','*daqui 7*','*daqui 8*','*daqui 9*','*daqui 10*','*daqui 11*','*daqui 12*','*daqui 13*','*daqui 14*','*daqui 15*','*daqui 16*','*daqui 17*','*daqui 18*','*daqui 19*','*daqui 20*','*daqui 21*','*daqui 22*','*daqui 23*','*daqui 24*','*daqui 25*','*daqui 26*','*daqui 27*','*daqui 28*','*daqui 29*','*daqui 30*','*daqui 31*','*daqui 32*','*daqui 33*','*daqui 34*','*daqui 35*','*daqui 36*','*daqui 37*','*daqui 38*','*daqui 39*','*daqui 40*','*daqui 41*','*daqui 42*','*daqui 43*','*daqui 44*','*daqui 45*','*daqui 46*','*daqui 47*','*daqui 48*','*daqui 49*','*daqui 50*','*daqui 51*','*daqui 52*','*daqui 53*','*daqui 54*','*daqui 55*','*daqui 56*','*daqui 57*','*daqui 58*','*daqui 59*','*daqui 60*','*daqui 61*','*daqui 62*','*daqui 63*','*daqui 64*','*daqui 65*','*daqui 66*','*daqui 67*','*daqui 68*','*daqui 69*','*daqui 70*','*daqui 71*','*daqui 72*','*daqui 73*','*daqui 74*','*daqui 75*','*daqui 76*','*daqui 77*','*daqui 78*','*daqui 79*','*daqui 80*','*daqui 81*','*daqui 82*','*daqui 83*','*daqui 84*','*daqui 85*','*daqui 86*','*daqui 87*','*daqui 88*','*daqui 89*','*daqui 90*','*daqui 91*','*daqui 94*','*daqui 95*','*daqui 96*','*daqui 97*','*daqui 98*','*daqui 99*','*daqui 100*','*Iludido por mais de*']
					const ndo = qua[Math.floor(Math.random() * qua.length)]
					client.sendMessage(from, 'Questão : *'+quando+'*\n\nResposta : '+ ndo+' anos', text, { quoted: mek })
					await limitAdd(sender)
					break	
/*
]=============================================================================> MENU OCR COMANDO MEIO SEM SENTIDO ESSE KK <==========================================================================[
*/					
				case 'ocr': 
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						reply(ind.wait())
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply('🚧 _Manda uma foto junto do comando_ 🚧')
					}
					await limitAdd(sender)
				break
/*
]=============================================================================> MENU CRIAR AUDIO ATRAVES DO BOT <==========================================================================[
*/
				case 'voz':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (args.length < 1) return client.sendMessage(from, '⚜️ *Codigo idioma necessario* ⚜️', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return client.sendMessage(from, '🇧🇷 *qual texto voce esta criando? minha? voz?* 🇯🇵', text, {quoted: mek})
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 600
					? reply('*bem falhe, repeti dnv* 😤')
					: gtts.save(ranm, dtt, function() {
						exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
							fs.unlinkSync(ranm)
							buffer = fs.readFileSync(rano)
							if (err) return reply('😤')
							client.sendMessage(from, buffer, audio, {quoted: mek, ptt:true})
							fs.unlinkSync(rano)
						})
					})
					await limitAdd(sender)
				break
/*
]=============================================================================> MENU SIMI <==========================================================================[
*/
				case 'simi':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (!isRegistered) return reply(ind.noregis())
				    if (isBanned) return reply(ind.benned())
					if (args.length < 1) return reply('🕋 _Escreva Algo_ 🕋')
					teks = body.slice(5)
					anu = await simih(teks) 
					reply(anu)
					await limitAdd(sender)
				break
				case 'simih':
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isSimi) return reply('🧺 *Simi Ja Esta Ativo* 🧺')
						samih.push(from)
						fs.writeFileSync('./database/bot/simi.json', JSON.stringify(samih))
						reply('🌨️ _Simih Esta Ativado_ 🌨️')
					} else if (Number(args[0]) === 0) {
						samih.splice(from, 1)
						fs.writeFileSync('./database/bot/simi.json', JSON.stringify(samih))
						reply('⛅ _Simih Esta Desativado_ ⛅')
					} else {
						reply(ind.satukos())
					}
					break
/*
]===========================================================================> MENU HIDETAG <=================================================================================================[
*/ 
				case 'hidetag':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					var value = body.slice(9)
					var group = await client.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: mek
					}
					client.sendMessage(from, options, text)
					await limitAdd(sender)
					break
/*
]===========================================================================> MENU ADICIONAR PESSOAS NO GRUPO <==============================================================================[
*/
				case 'add':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (args.length < 1) return reply('🐺 *Você quer adicionar um gênio?* 🐺')
					if (args[0].startsWith('08')) return reply('🐯 *Use o código do país mas* 🐯 *Exemplo: add 5598452532*')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						client.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :', e)
						reply('⚠️ *Falha ao adicionar destino, talvez porque é privado* ⚠️')
					}
				break 
/*
]===========================================================================> MENU JOGO DA SORTE <=======================================================================================[
*/
                    case 'sorte':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isJogo) return reply('🦄 *Jogo da sorte ja esta ativo* 🦄')
						sorte.push(from)
						fs.writeFileSync('./database/group/sorte.json', JSON.stringify(sorte))
						reply('🕋 *ATENÇAO GALERA VAI ROLAR QUIZ AGORA FIQUEM LIGADOS* 🕋\n\n🌟 O premio para quem acerta é muito variado 🌟\n\n 💸 _Boa sorte a todos_ 💸\n\n🚧 *Como Jogar* 🚧\nVocês vão ter que colocar a tag ${prefix}resposta\n\n ⚠️ _Exemplo_ ⚠️\n ${prefix}resposta 2\n ${prefix}resposta a')
					} else if (Number(args[0]) === 0) {
						sorte.splice(from, 1)
						fs.writeFileSync('./database/group/sorte.json', JSON.stringify(sorte))
						reply('*❬ 𝗦ucesso ❭ 🐮 O jogo da sorte esta desativado*')
					} else {
						reply(ind.satukos())
					}
					break	
					case 'resposta':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (!isJogo) return reply(`${pushname} ⚠️ *JA ACERTARAM A PERGUNTA, FIQUE LIGADO PARA A PROXIMA* ⚠️`) 
                      if (args[0] === game) {
                      const one5 = Math.ceil(Math.random() * 5000)
					  const ale = Math.ceil(Math.random() * 10)
					  const ace = Math.ceil(Math.random() * 3)
					  addPontUser(sender, ace)
                      addLevelingXp(sender, one5)
                      addLevelingLevel(sender, 0)
					  bayarLimit(sender, ale)
                      reply(`️🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n🆙 *XP* 🆙: ${one5}\n🧧 *Tickets* 🧧: ${ale}\n🌟 *Pontos* 🌟: ${ace}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
					  jogo.splice(from, 1)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('🌟🇯🇵 ✅ 🇯🇵🌟')
                      } else if (args[0] === game1) {
                      const mining6 = Math.ceil(Math.random() * 2500)
					  const ale1 = Math.ceil(Math.random() * 10)
					  const ace1 = Math.ceil(Math.random() * 3)
					  addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
					  bayarLimit(sender, ale1)
                      await reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
					  jogo.splice(from, 1)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('🌟🇯🇵 ✅ 🇯🇵🌟')
                      } else {
						reply(ind.jogando())
					  }
				break
/*
]===========================================================================> MENU JOGO DO AZAR PALAVRA DA SORTE PALAVRA DO AZAR <=================================================================[
*/
                     case 'jogodoazar':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const kremresi = JSON.parse(fs.readFileSync('./database/group/azar.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Participantes Do Jogo  🇧🇷🇯🇵 ]==*\n'
				    for (let premauresi of kremresi){
					teks += `┣➢👑 @${premauresi.replace('@s.whatsapp.net','')}\n`
				    }
			 	    teks += `┣➢🐺 *Total Participantes* : ${kremresi.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": azar}})
					await limitAdd(sender)
					break
					case 'addazar':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnomresi = `${args[0].replace('@','')}@s.whatsapp.net`
				    azar.push(pnomresi)
				    fs.writeFileSync('./database/group/azar.json',JSON.stringify(azar))
				    reply(ind.azaradd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exazar':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnomresi = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = azar
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnomresi) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/group/azar.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellazar(args[0]))
					await limitAdd(sender)
					break
					case 'azar1':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    azar1 = args[0]
                    reply(`🐦 *piu* ${azar1} *Sucesso*`)
					break
					case 'azar2':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    azar2 = args[0]
                    reply(`🐦 *piu* ${azar2} *Sucesso*`)
					break
/*
]===========================================================================> MENU PARA UPAR DE LEVEL <=====================================================================================[
*/
				case 'up':
                      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (isLimit(sender)) return reply(ind.limitend(pushname))
                      if (!isEventon) return reply(`*Desculpa ${pushname} O evento não esta ativado*`)
                      if (isOwner) {
                      const one = Math.ceil(Math.random() * 30000)
                      addLevelingXp(sender, one)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Nivel desconhecido, mais ${one}XP para você* ⚜️`)
                      }else{
                      const mining = Math.ceil(Math.random() * 15000)
                      addLevelingXp(sender, mining)
                      await reply(`🆙 *Parabens* 🆙 *${pushname}* *🆙 voce pega xp 🆙* *${mining}Xp*`)
                      }if (isPremium) {
                      const mining5 = Math.ceil(Math.random() * 23000)
                      addLevelingXp(sender, mining5)
                      await reply(`🆙 *Parabens* 🆙 *${pushname}* *🆙 voce pega xp 🆙* *${mining5}Xp*`)
                      }if (isDivindade) {
                      const mining6 = Math.ceil(Math.random() * 30000)
                      addLevelingXp(sender, mining6)
                      await reply(`🆙 *Parabens* 🆙 *${pushname}* *🆙 voce pega xp 🆙* *${mining6}Xp*`)
                      }
                    await limitAdd(sender)
					break
				case 'upador':
					 if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isEventon) return reply('🦄 *Up Esta Ativo No Grupo* 🦄')
						event.push(from)
						fs.writeFileSync('./database/bot/event.json', JSON.stringify(event))
						reply('*❬ 𝗦𝗨cesso ❭ 🐮 Upador esta ativado nesse grupo*')
					} else if (Number(args[0]) === 0) {
						event.splice(from, 1)
						fs.writeFileSync('./database/bot/event.json', JSON.stringify(event))
						reply('*❬ 𝗦ucesso ❭ 🐮 Upador esta desativado nesse grupo*')
					} else {
						reply(ind.satukos())
					}
					break 
/*
]===========================================================================> MENU MODIFICAR COISAS NO GRUPO <=================================================================[
*/
				 case 'linkgp':
				    if (isBanned) return reply(ind.benned())
				    if (!isGroup) return reply(ind.groupo())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (!isBotGroupAdmins) return reply(ind.badmin())	
				    linkgc = await client.groupInviteCode (from)
				    yeh = `https://chat.whatsapp.com/${linkgc}\n\n🐺 *Link do grupo* 🐺  *${groupName}*`
				    client.sendMessage(from, yeh, text, {quoted: mek})
			        await limitAdd(sender)
					break
					case 'gp':
					case 'grupo':
					if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (args[0] === 'abrir') {
					    reply(`🦊 *Grupo aberto* 🦊`)
						client.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'fechar') {
						reply(`🐶 *Grupo fechado* 🐶`)
						client.groupSettingChange(from, GroupSettingChange.messageSend, true)
					}
					await limitAdd(sender)   
					break
/*
]===========================================================================> MENU CONTRATAR & DEMITIR ADMS <=================================================================[
*/
           case 'demitir':
		            if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque Alguem*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `Rebaixado com sucesso :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupDemoteAdmin(from, mentioned)
					} else {
						mentions(`*O* @${mentioned[0].split('@')[0]}  *Acabou de perder o ADM*`, mentioned, true)
						client.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'contratar':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque Alguem*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `*Contratado com sucesso* :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupMakeAdmin(from, mentioned)
					} else {
						mentions(`*Agora* @${mentioned[0].split('@')[0]} foi contratado como ADM* 🐼`, mentioned, true)
						client.groupMakeAdmin(from, mentioned)
					}
					break	
/*
]=======================================================================> MENU DE BANIMENTO <===============================================================================[
*/
			     	case 'contagem':
			if (isBanned) return reply(ind.benned())    
				if (!isRegistered) return reply(ind.noregis())
				if (isL1000imit(sender)) return reply(ind.limitend(pusname))	
					if (!isGroup) return reply(ind.groupo())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('A marca-alvo que você deseja chutar!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedido recebido, emitido\n'
						for (let i= 0; i < 1; mentioned) {
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						 client.groupRemove(from, mentioned)
					} else {
						setTimeout( () => {
						mentions(`🛡️ *Contagem regressiva para eu te apagar* 🛡️ @${mentioned[0].split('@')[0]}`, mentioned, true)
						}, 1000)
					setTimeout( () => {
					 client.groupRemove(from, mentioned, {quoted: mek}) // ur cods
					}, 35000)
					setTimeout( () => {
					 client.sendMessage(from, '🛡️ *Tiro Confirmado, Na Cabeça Do Alvo, HeadShot Lindo !!!* 🛡️', text) // ur cods
					}, 30000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ ( ऀืົཽ₍₍ළ₎₎ ऀืົཽ)▄︻̷̿┻̿═━一 💥💥💥 🛡️*', text) // ur cods
					}, 20000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ Ajustando Mira He He He 🛡️*', text) // ur cods
					}, 10000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ Preparando Para Mirar 🛡️*', text, { quoted: mek }) // ur cods
					}, 5000)
					}
					await l1000imitAdd(sender)
					break
			     	case 'ban':
					if (isBanned) return reply(ind.benned())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque alguem que deseje banir*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let i= 0; i < 1; mentioned) {
							teks += `Pedidos recebidos, emitidos  :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`😨😨😨 @${mentioned[0].split('@')[0]} *foi banido 🦊* `, mentioned, true)
						client.groupRemove(from, mentioned)
					}
					await limitAdd(sender)
					break
/*
]=======================================================================> MENU LISTA DE ADMINISTRADORES <===============================================================================[
*/
				case 'adms':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					teks = `🔰 *Lista de admins do grupo* 🔰 *${groupMetadata.subject}*\n🔓 *Total* 🔒 : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					await limitAdd(sender)
					break
/*
]=======================================================================> MENU DE BOAS VINDAS <===============================================================================[
*/
				case 'bv':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('🚧 _Ja Esta Ativo_ 🚧')
						welkom.push(from)
						fs.writeFileSync('./database/bot/welkom.json', JSON.stringify(welkom))
						reply('*❬ 🌟 SUCESSO 🌟 ❭* 🕋 _Comando De Boas Vindas Esta Ativo Nesse Grupo_ 🕋 ')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./database/bot/welkom.json', JSON.stringify(welkom))
						reply('*❬ 🍱 SUCESSO 🍱 ❭*  🌹 _Comando De Boas Vindas Esta Desativado Nesse Grupo_ 🌹 ')
					} else {
						reply(ind.satukos())
					}
					break 
/*
]=======================================================================> MENU NSFW <===============================================================================[
*/
				case 'nsfw':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isNsfw) return reply('🔑 *Coloca 1 ou 0 na frente com espaço* 🔑')
						nsfw.push(from)
						fs.writeFileSync('./database/bot/nsfw.json', JSON.stringify(nsfw))
						reply('❬ *Sucesso* ❭ NSFW esta ativado no grupo')
					} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./database/bot/nsfw.json', JSON.stringify(nsfw))
						reply('❬ *Sucesso* ❭ NSFW esta desativado no grupo')
					} else {
						reply(ind.satukos())
					}
					break
/*
]=======================================================================> MENU AFK <===============================================================================[
*/
				case 'afk':
	                if (!isRegistered) return reply(ind.noregis())
	                if (!isGroup) return reply(ind.groupo())
	                if (isAfkOn) return reply(ind.afkOnAlready())
	                if (isLimit(sender)) return reply(ind.limitend(pushname))
	                limitAdd(sender)
	                reason = body.slice(5)
					if (reason === undefined || reason === ' ' || reason === '') { reason = 'nothing'}
	                addAfkUser(sender, time, reason)
	                reply(ind.afkOn(pushname, reason))
					await limitAdd(sender)
	            break
/*
]=======================================================================> MENU LEVELING <===============================================================================[
*/
                case 'leveling':
				if (isBanned) return reply(ind.benned())
                if (!isGroup) return reply(ind.groupo())
                if (!isGroupAdmins) return reply(ind.admin())
                if (args.length < 1) return reply('Boo :??')
                if (args[0] === 'ativar') {
                    if (isLevelingOn) return reply('🔱 *Use o comando ativar ou desativar na frente com espaço* 🔱')
                    _leveling.push(from)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                     reply(ind.lvlon())
                } else if (args[0] === 'desativar') {
                    _leveling.splice(from, 1)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                     reply(ind.lvloff())
                } else {
                    reply(ind.satukos())
                }
				break 
/*
]===========================================================================> MENU MARCAR <=================================================================[
*/
				case 'marcar':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `┣➥ 🇯🇵🇧🇷 @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break 
        		case 'online':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
        		let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
			    let online = [...Object.keys(client.chats.get(ido).presences), client.user.jid]
			    client.sendMessage(from, '*🕋 Lista De Pessoas Online No Grupo 🕋*\n\n' + online.map(v => '🔛 @' + v.replace(/@.+/, '')).join`\n`, text, { quoted: mek,
  			  contextInfo: { mentionedJid: online }
			    })
				  await limitAdd(sender)
					break
/*
]===========================================================================> MENU DELETAR MENSAGEM <=================================================================[
*/
				case 'delete':
				case 'del':
				case 'd':
				if (isBanned) return reply(ind.benned())
				if (!isGroup) return reply(ind.groupo())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				client.deleteMessage(from, { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true }) 
			    await limitAdd(sender)
				break 
/*
]===========================================================================> MENU ANTI PALAVROES ADICIONAR REMOVER LISTA <=================================================================[
*/
				case 'addpalavra':
				    if (isBanned) return reply(ind.benned())
                    if (!isOwner) return reply(ind.ownerb())
                    if (!isGroupAdmins) return reply(ind.admin())
                    if (args.length < 1) return reply( `🚧 _Como Adicionar As Palavras ${prefix}addpalavra idiota_ 🚧`)
                    const bw = body.slice(12)
                    bad.push(bw)
                    fs.writeFileSync('./database/group/bad.json', JSON.stringify(bad))
                    reply('🌟 *Palavra Adicionada Com Sucesso* 🌟')
                    break
                case 'delpalavra':
				    if (isBanned) return reply(ind.benned())
                    if (!isOwner) return reply(ind.ownerb())
                    if (!isGroupAdmins) return reply(ind.admin())
                    if (args.length < 1) return reply( `🚧 _Como Remover As Palavras ${prefix}delpalavra idiota_ 🚧`)
                    let dbw = body.slice(12)
                    bad.splice(dbw)
                    fs.writeFileSync('./database/group/bad.json', JSON.stringify(bad))
                    reply('🌟 *Palvra Removida Com Sucesso* 🌟')
                    break 
                case 'palavras':
				    if (isBanned) return reply(ind.benned())
                    let lbw = `🕋 ℙ𝕒𝕝𝕧𝕣𝕒𝕤 ℚ𝕦𝕖 ℕ𝕒̃𝕠 ℙ𝕠𝕕𝕖 𝕊𝕖𝕣 𝔻𝕚𝕥𝕒 🕋\n\n🌹 𝚃𝚘𝚝𝚊𝚕 🌹 : ${bad.length}\n\n`
                    for (let i of bad) {
                        lbw += `➸ 🔥 ${i.replace(bad)}\n`
                    }
                    await reply(lbw)
                    break 
				case 'antipalavra':
				if (isBanned) return reply(ind.benned())
                if (!isGroup) return reply(ind.groupo())
                if (!isGroupAdmins) return reply(ind.admin())
                if (args.length < 1) return reply('Boo :??')
                if (args[0] === 'ativar') {
                if (isBadWord) return reply('*🚧 Anti Palavroes Ja Esta Ativo 🚧*')
                 	   badword.push(from)
                 	   fs.writeFileSync('./database/group/badword.json', JSON.stringify(badword))
                  	   reply(`🔥 _Anti Palavroes Esta Ativado_ 🔥`)
              	  } else if (args[0] === 'desativar') {
                  	  badword.splice(from, 1)
                 	   fs.writeFileSync('./database/group/badword.json', JSON.stringify(badword))
                 	    reply(`🕋 _Anti Palavroes Esta Desativado_ 🕋`)
             	   } else {
                 	   reply(ind.satukos())
                	}
                    break
/*
]===========================================================================> MENU DONO <=================================================================[
*/
				case 'kickall':
                    if (!isOwner) return reply(ind.ownerb())
			        members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `*😘* ${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					client.groupRemove(from, members_id)
					break 
					case 'setreply':
					if (!isOwner) return reply(ind.ownerb())
                    client.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					cr = body.slice(10)
					reply(`🍄 _A resposta foi alterada com sucesso para_ 🍄 ${cr}`)
					await limitAdd(sender)
					break
					case 'sair': 
				if (!isGroup) return reply(ind.groupo())
				if (!isOwner) return reply(ind.ownerb())
				await reply(from, 'bye').then(() => client.groupLeave(from))
					break 
/*
]===========================================================================> MENU ANTI LINK <=================================================================[
*/
				case 'antilink':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.ownerg())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isAntiLink) return reply('*🚧 Anti Link Ja Esta Ativado 🚧*')
						antilink.push(from)
						fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
						reply('*❬ 🔥 Ativado 🔥 ❭ ANTI LINK*')
					} else if (Number(args[0]) === 0) {
						antilink.splice(from, 1)
						fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
						reply('*❬ 🔥 Desativado 🔥 ❭ ANTI LINK*')
					} else {
						reply(ind.satukos())
					}
					break 				
/*
]===========================================================================> MENU PREFIX MUDAR <=================================================================[
*/
				case 'setprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    prefix = args[0]
                    reply(`🍄 *Prefixo Mudado Com Sucesso* 🍄`)
					break 
				case 'membrolimit':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
					if (isNaN(args[0])) return reply('limit harus angka')
                    memberlimit = args[0]
                    reply(`🍄 _Membro Limite Mudado_ 🍄`)
				break 
/*
]===========================================================================> MENU NÃO SEI O QUE É AINDA <=================================================================[
*/
				case 'avaliar':
				if (!isOwner) return reply(ind.ownerb())
                if (!q) return reply(ind.wrongf())
                try {
         	           let evaled = await eval(q)
         	           if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
          	          await reply(evaled)
          		//	client.sendMessage(from, JSON.stringify(eval(body.slice(6))). text)
       	         } catch (err) {
        	            console.error(err)
          	          await reply('Error!')
  	   	       }
				break 
				case '=>':
				if (!isOwner) return reply(ind.ownerb())
				const cmd = body.slice(4)
				exec(cmd, (err, stdout) => {
					if (err) return client.sendMessage(from, `root@Nfz.01:~ ${err}`, text, { quoted: mek })
					if (stdout) {
						client.sendMessage(from, stdout, text)
					}
				})
				break
/*
]===========================================================================> MENU AUDIOS SALVAR LISTA DE AUDIOS <=================================================================[
*/
				case 'audio':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isRegistered) return reply(ind.noregis())
				if (isBanned) return reply(ind.benned())
				client.updatePresence(from, Presence.composing)
				if (!isQuotedVideo) return reply('itu video bruh?:V')
				reply(ind.wait())
				encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				media = await client.downloadAndSaveMediaMessage(encmedia)
				ran = getRandom('.mp4')
				exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media)
					if (err) return reply('Yahh emrror bruh:(')
					buffer = fs.readFileSync(ran)
					client.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek })
					fs.unlinkSync(ran)
				})
				await limitAdd(sender)
				break 
				case 'audiolento':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
				media = await client.downloadAndSaveMediaMessage(encmedia)
				ran = getRandom('.mp3')
				exec(`ffmpeg -i ${media} -filter:a "atempo=0.7,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
				fs.unlinkSync(media)
				if (err) return reply('Error!')
				uhh = fs.readFileSync(ran)
				client.sendMessage(from, uhh, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
				fs.unlinkSync(ran)
				})
				await limitAdd(sender)
				break

				case 'audiofast':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -filter:a "atempo=0.5,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(media)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
				break
				case 'audiogordo':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -filter:a "atempo=1.6,asetrate=22100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(media)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
				break
				case 'audiobaixo':  
                if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())				
				if (!isRegistered) return reply(ind.noregis())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -af equalizer=f=94:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(media)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
				break
				case 'adaud':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					if (!isQuotedAudio) return reply('🚧 _Marque Um Audio_ 🚧')
					svst = body.slice(7)
					if (!svst) return reply('🚧 _De Um Nome Para O Audio_ 🚧')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await client.downloadMediaMessage(boij)
					audionye.push(`${svst}`)
					fs.writeFileSync(`./strg/audio/${svst}.mp3`, delb)
					fs.writeFileSync('./strg/audio.json', JSON.stringify(audionye))
					client.sendMessage(from, `🌳 *Audio Adicionado com Sucesso digite ${prefix}audios* 🌳`, MessageType.text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'exaud':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					namastc = body.slice(7)
					buffer = fs.readFileSync(`./strg/audio/${namastc}.mp3`)
					client.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek, ptt: true })
					await limitAdd(sender)
					break
				case 'audios':
				case 'listaad':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					teks = '*🎧 Lista De Audios 🎧*\n\n'
					for (let awokwkwk of audionye) {
						teks += `- 🎼 ${awokwkwk}\n`
					}
					teks += `\n*Total : ${audionye.length}*`
					client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": audionye } })
					await limitAdd(sender)
					break
/*
]===========================================================================> MENU SALVAR IMAGEM LISTA DE IMAGENS <=================================================================[
*/
				case 'addimage':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					if (!isQuotedImage) return reply('🚧 _Marque Uma Imagem_ 🚧')
					svst = body.slice(10)
					if (!svst) return reply('🚧 _De um nome para a imagem_ 🚧')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await client.downloadMediaMessage(boij)
					imagenye.push(`${svst}`)
					fs.writeFileSync(`./strg/image/${svst}.jpeg`, delb)
					fs.writeFileSync('./strg/image.json', JSON.stringify(imagenye))
					client.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listimage`, MessageType.text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'eximagem':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					namastc = body.slice(10)
					buffer = fs.readFileSync(`./strg/image/${namastc}.jpeg`)
					client.sendMessage(from, buffer, image, { quoted: mek, caption: `Result From Database : ${namastc}.jpeg` })
					await limitAdd(sender)
					break
				case 'imagens':
				case 'imagenlist':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					teks = '*🏖️ Lista De Imagens 🏜️*\n\n'
					for (let awokwkwk of imagenye) {
						teks += `- 🏝️ ${awokwkwk}\n`
					}
					teks += `\n*Total : ${imagenye.length}*`
					client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": imagenye } })
					await limitAdd(sender)
					break
/*
]===========================================================================> MENU SALVAR VIDEOS LISTA DE VIDEOS <=================================================================[
*/	
				case 'addvideo':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					if (!isQuotedVideo) return reply('🚧 _Marque Algum Video_ 🚧')
					svst = body.slice(10)
					if (!svst) return reply('🚧 _De Um Nome Para O Video_ 🚧')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await client.downloadMediaMessage(boij)
					videonye.push(`${svst}`)
					fs.writeFileSync(`./strg/video/${svst}.mp4`, delb)
					fs.writeFileSync('./strg/video.json', JSON.stringify(videonye))
					client.sendMessage(from, `*Video Adicionado Com Sucesso Digite ${prefix}videos Para Ver A Lista*`, MessageType.text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'exvideos':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					namastc = body.slice(10)
					buffer = fs.readFileSync(`./strg/video/${namastc}.mp4`)
					client.sendMessage(from, buffer, video, { mimetype: 'video/mp4', quoted: mek })
					await limitAdd(sender)
					break
				case 'videos':
				case 'videolist':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					teks = '*🎥 Lista De Videos 🎥*\n\n'
					for (let awokwkwk of videonye) {
						teks += `- 📽️ ${awokwkwk}\n`
					}
					teks += `\n*Total : ${videonye.length}*`
					client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": videonye } })
					await limitAdd(sender)
					break	
/*
]===========================================================================> MENU NÃO SEI O QUE ISSO FAZ <=================================================================[
*/
				case 'tourl':
				 if (isLimit(sender)) return reply(ind.limitend(pusname))
				 if (isBanned) return reply(ind.benned())
				 if (!isRegistered) return reply(ind.noregis())
		           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
		           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
		           reply(ind.wait())
		         owgi = await client.downloadAndSaveMediaMessage(ger)
		           anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
		        teks = `${anu.display_url}`
				reply(teks)
				}
				await limitAdd(sender)
				break
/*
]===========================================================================> MENU ACHAR ANIMES ALEATORIOS <=================================================================[
*/
				case 'wait':
				    if (!isRegistered) return reply(ind.noregis())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(ind.wait())
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await client.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							client.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply(ind.ocron())
					}
					await limitAdd(sender)
					break
				
				default:
			if (body.startsWith(`${prefix}${command}`)) {
                  reply(`🕋 *${pushname}* 🕋, 🚧 _Comando Não Encontrado_ 🚧`)
                  }
            if (/^>/.test(pes)) {
            	if (!isOwner) return
	            let txt = pes.replace(/^>/, '')
	            let type = Function
	            if (/await/.test(pes)) type = (async () => {}).constructor
	            let func = new type('print', 'client', 'MessageType', 'mek', 'text', 'from', 'image', 'os', 'fetch', txt)
	            console.log('[EvalF]', func.toString())
	            let output
	            try {
	                output = await func((...args) => {
	                    console.log('[EvalP]', ...args)
	                    client.sendMessage(from, util.format(...args), MessageType.extendedText, {
	                        quoted: mek
	                    })
	                }, client, MessageType, mek, text, from, await image, os, fetch)
	                console.log('[EvalO]', output)
	                client.sendMessage(from, util.format(output), MessageType.extendedText, {
	                    quoted: mek
	                })
	            } catch (e) {
	                console.error('[EvalE]', e)
	                client.sendMessage(from, util.format(e), MessageType.extendedText, {
	                    quoted: mek
	                })
	            }
            }
			if (isGroup && !isCmd && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						reply(ind.cmdnf(prefix, command))
					} else {
						console.log(color('[ERROR]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
					}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
