const a = '```'

exports.wait = () => {
	return`*「 🍱 Aguarde 🍱 」* _⌛ ESTA EM PROCESSO ⌛_`
}

exports.succes = () => {
	return`*「 🌹 Deu Certo 🌹 」*`
}

exports.lvlon = () => {
	return`*「 🔥 ATIVADO 🔥 」* _LEVELING_`
}

exports.lvloff = () => {
	return`*「 😞 DESATIVADO 😞 」* _LEVELING_`
}

exports.lvlnul = () => {
	return`🐤 _Voce ainda não possui Level_ 🐤`
}

exports.lvlnoon = () => {
	return`💂🏻‍♀️ _Leveling Esta Desativado_ 💂🏻‍♀️`
}

exports.noregis = () => {
	return`*「 🧐 Voce não esta Registrado 🧐 」*\n\n _🌟 Se registre para participar de eventos e subir ate o topo 🌟_ \n\n *💂🏻‍♀️ Para se Registrar é so Digitar 💂🏻‍♀️*\n\n ${prefix}registrar nome - idade`
}

exports.rediregis = () => {
	return`*「 🚨 Usuario Ja Registrado 🚨 」*`
}

exports.stikga = () => {
	return`*🕋 Falhou, Tente repetir depois. 🕋*`
}

exports.linkga = () => {
	return`*❌ Link Invalido ❌*`
}

exports.groupo = () => {
	return`*「⚠️ So Pode Usar Esse Comando Nos Grupos ⚠️」*`
}

exports.ownerb = () => {
	return`*「⚠️ Esse Comando So Pode Ser Usado Pelo Dono Do Bot ⚠️」*`
}

exports.ownerg = () => {
	return`*「⚠️ Esse Comando So Pode Ser Usado Pelo Dono Do Bot ⚠️」*`
}

exports.admin = () => {
	return`*「⚠️ So Administradores Podem Usar Esse Comando ⚠️」*`
}

exports.badmin = () => {
	return`*「🎪 Para Esse Comando Funcionar Eu Tenho Que Ser Administrador 🎪」*`
}

exports.nsfwoff = () => {
	return`*「NSFW」* _🍷 Ja Esta Ativo 🍷_`
}

exports.bug = () => {
	return`*🍯 Sua Mensagem Ja Foi Enviado Para O Meu Dono, Mensagens Atoa e Falsas Não Serão Respondidas 🍯*`
}

exports.wrongf = () => {
	return`_📝 Você Esta Escrevendo Errado Ou Esta Deixando Algo Em Branco 📝_`
}

exports.clears = () => {
	return`*🗞️ Limpando Tudo 🗞️*`
}

exports.pc = () => {
	return`*「 📚 Se Cadastrando 📚 」*\n\n_Para saber se você se cadastrou, verifique a mensagem que enviei_ \n\n*📜 Se Voce Não Achou A Mensagem É Por Que Voce Não Se Cadastrou 📜*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender) => {
	return`*「 📥 Membro Cadastrado 📤 」*\n\n_📝 Parabens Voce Se Cadastrou 📝_ \n\n┏━⊱🏰 *「Nome」* 🏰\n┗⊱${namaUser}\n┏━⊱🏰 *「Numero」* 🏰\n┗⊱wa.me/${sender.split("@")[0]}\n┏━⊱🏰 *「Idade」* 🏰\n┗⊱${umurUser}\n┏━⊱🏰 *Horario Do Registro* 🏰\n┗⊱${time}\n\n┏━❉ *🕋 Serial 🕋* ❉━\n┣⊱${serialUser}\n\n 🚧 _Salva esse codigo ai, talvez voce vai precisar dele_ 🚧`
}

exports.cmdnf = (prefix, command) => {
	return`⚠️ _Comando_ *${prefix}${command}* _não encontrado teste ecrever_ *${prefix}menu* ⚠️`
}

exports.owneresce = (pushname) => {
	return`*🚧 ${pushname} Script do dono não encontrado 🚧*`
}

exports.reglevelaha = (command, pushname, getLevelingLevel, sender, aha) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.reglevelahb = (command, pushname, getLevelingLevel, sender, ahb) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.reglevelahc = (command, pushname, getLevelingLevel, sender, ahc) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.reglevelahd = (command, pushname, getLevelingLevel, sender, ahd) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.reglevelahe = (command, pushname, getLevelingLevel, sender, ahe) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.reglevelahf = (command, pushname, getLevelingLevel, sender, ahf) => {
	return`*${pushname} _🌟 Seu Level Não É Suficiente 🌟_\n\n*┏⊱ 🔥 *「Seu Level」 : ${getLevelingLevel(sender)}*\n*┣⊱ ⛅ *「Comando」  : ${command}*\n*┗⊱ 🌧️ *「Requisito de Level」 : ${aha}*\n\n_🚧 Atenção 🚧_\n 🕋 *Sempre falar no grupo para ganhar XP* 🕋`
}

exports.menu = (pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku, role, premi, client , process) => { 
	return `
${a}❏ ABOUT USER${a}
 ${a}│ Nama : ${pushname}${a}
 ${a}│ Premium :${a} ${premi}
 ${a}│ Nomer : wa.me/${sender.split("@")[0]}${a}
 ${a}│ Uang mu : Rp${uangku}${a}
 ${a}│ XP : ${getLevelingXp(sender)}/${reqXp} ${a}
 ${a}│ Level : ${getLevelingLevel(sender)}${a}
 ${a}│ Role : ${role}${a}
 ${a}╰ User register : ${_registered.length}${a}

 *${prefix}info*
 *${prefix}donasi*
 *${prefix}owner*

${a}❏MAKER MENU${a}
 ${a}│•${prefix}sticker${a}
 ${a}│•${prefix}quotemaker${a}
 ${a}│•${prefix}qrcode${a}
 ${a}│•${prefix}nulis${a}
 ${a}│•${prefix}tahta${a}
 ${a}╰•${prefix}ttp${a}
 
${a}❏FUN MENU${a}
 ${a}│•${prefix}lirik${a}
 ${a}│•${prefix}artinama${a}
 ${a}│•${prefix}chord${a}
 ${a}│•${prefix}bisakah${a}
 ${a}│•${prefix}kapankah${a}
 ${a}│•${prefix}apakah${a}
 ${a}│•${prefix}rate${a}
 ${a}│•${prefix}tebakgambar${a}
 ${a}│•${prefix}meme${a}
 ${a}│•${prefix}textlight${a}
 ${a}│•${prefix}glitchtext${a}
 ${a}│•${prefix}slap${a}
 ${a}│•${prefix}tampar${a}
 ${a}│•${prefix}moddroid${a} *[VIP]*
 ${a}╰•${prefix}happymod${a} *[VIP]*
 
${a}❏MUTUAL${a}
 ${a}│•${prefix}mutual${a}
 ${a}╰•${prefix}next${a}
 
${a}❏MEDIA MENU${a}
 ${a}│•${prefix}brainly${a} *[VIP]*
 ${a}│•${prefix}pinterest${a}
 ${a}│•${prefix}resepmasakan${a}
 ${a}│•${prefix}igstalk${a}
 ${a}│•${prefix}bitly${a}
 ${a}│•${prefix}tiktokstalk${a} *[VIP]*
 ${a}│•${prefix}ssweb${a}
 ${a}╰•${prefix}kbbi${a}
 
${a}❏SONG${a}
 ${a}╰•${prefix}joox${a} *[VIP]*
 
${a}❏NSFW${a}
 ${a}│•${prefix}anjing${a}
 ${a}│•${prefix}blowjob${a}
 ${a}│•${prefix}nekonime${a}
 ${a}│•${prefix}pokemon${a}
 ${a}│•${prefix}husbu${a}
 ${a}│•${prefix}nangis${a}
 ${a}│•${prefix}cium${a}
 ${a}│•${prefix}peluk${a}
 ${a}╰•${prefix}ranime${a}
 
${a}❏LIMIT & UANG${a}
 ${a}│•${prefix}limit${a}
 ${a}│•${prefix}buylimit${a}
 ${a}│•${prefix}transfer${a}
 ${a}│•${prefix}dompet${a}
 ${a}│•${prefix}giftlimit${a}
 ${a}╰•${prefix}leaderboard${a}
 
${a}❏GROUP MENU${a}
 ${a}│•${prefix}delete${a}
 ${a}│•${prefix}hidetag${a}
 ${a}│•${prefix}blocklist${a}
 ${a}│•${prefix}grouplist${a}
 ${a}│•${prefix}level${a}
 ${a}│•${prefix}linkgc${a}
 ${a}│•${prefix}tagall${a}
 ${a}│•${prefix}setpp${a}
 ${a}│•${prefix}add${a}
 ${a}│•${prefix}kick${a}
 ${a}│•${prefix}setname${a}
 ${a}│•${prefix}setdesc${a}
 ${a}│•${prefix}demote${a}
 ${a}│•${prefix}promote${a}
 ${a}│•${prefix}listadmin${a}
 ${a}│•${prefix}group [buka/tutup]${a}
 ${a}│•${prefix}leveling [enable/disable]${a}
 ${a}│•${prefix}nsfw [1/0]${a}
 ${a}│•${prefix}simih [1/0]${a}
 ${a}│•${prefix}welcome [1/0]${a}
 ${a}│•${prefix}antilink [1/0]${a}
 ${a}╰•${prefix}nobadword [enable/disable]${a}
 
${a}❏TOOLS${a}
 ${a}│•${prefix}bass${a}
 ${a}│•${prefix}tomp3${a}
 ${a}│•${prefix}slowmo${a}
 ${a}│•${prefix}gemok${a}
 ${a}│•${prefix}wasted${a}
 ${a}│•${prefix}tourl${a}
 ${a}│•${prefix}triggered${a}
 ${a}╰•${prefix}tupai${a}
 
${a}❏CLOUD STORAGE${a}
 ${a}│•${prefix}addsticker${a}
 ${a}│•${prefix}getsticker${a}
 ${a}│•${prefix}stickerlist${a}
 ${a}│•${prefix}addvideo${a}
 ${a}│•${prefix}getvideo${a}
 ${a}│•${prefix}videolist${a}
 ${a}│•${prefix}getimage${a}
 ${a}│•${prefix}addImage${a}
 ${a}│•${prefix}imagelist${a}
 ${a}│•${prefix}addaudio${a}
 ${a}│•${prefix}getaudio${a}
 ${a}╰•${prefix}audiolist${a}
 
${a}❏OWNER MENU${a}
 ${a}│•${prefix}bc${a}
 ${a}│•${prefix}addbadword${a}
 ${a}│•${prefix}delbadword${a}
 ${a}│•${prefix}bcgc${a}
 ${a}│•${prefix}kickall${a}
 ${a}│•${prefix}setreply${a}
 ${a}│•${prefix}setprefix${a}
 ${a}│•${prefix}clearall${a}
 ${a}│•${prefix}block${a}
 ${a}│•${prefix}unblock${a}
 ${a}│•${prefix}leave${a}
 ${a}│•${prefix}event [1/0]${a}
 ${a}│•${prefix}clone${a}
 ${a}╰•${prefix}setppbot${a}
 
${a}❏ABOUT BOT${a}
 ${a}│ • Name : ${client.user.name}${a}
 ${a}│ • browser : ${client.browserDescription[1]}${a}
 ${a}│ • server : ${client.browserDescription[0]}${a}
 ${a}│ • version : ${client.browserDescription[2]}${a}
 ${a}│ • speed : ${process.uptime()}${a}
 ${a}│ • handphone : ${client.user.phone.device_manufacturer}${a}
 ${a}╰ • versi wa : ${client.user.phone.wa_version}${a}
 
${a}❏THANGKS TO${a}
 ${a}│${a}
 ${a}│ • AFFIS JUNIANTO <dev>${a}
 ${a}│ • FADHIL GRAPHY <partner>${a}
 ${a}│ • MHANKBARBARS <sc ori>${a}
 ${a}│ • MYBOT TEAM <team>${a}
 ${a}│${a}
 ${a}╰ • NOTE : jangan ngemis${a}
`
}

exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel, role) => {
	return`
	
*「 🆙 Voce Upou Parabens 🆙 」*
┏⊱ 🍱 *「Nome」* : ${pushname}
┣⊱ 🎪 *「Numero」* : wa.me/${sender.split("@")[0]}
┣⊱ 🤿 *「Seu XP」* : ${getLevelingXp(sender)}
┣⊱ 🌟 *「Tickets」* : +2
┣⊱ ☃️ *「Titulo」*: ${role}
┗⊱ 🕋 *「Level」* : ${getLevel} ⊱🆙 ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*${pushname} ⚓ Seus tickets são insuficientes ⚓*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 🆙 Seus tickets 🆙 」*

*🌟 Quantidade de tickets 🌟* : 
🧧🧧🧧🧧🧧🧧 ${limitCounts}

*⚠️ Consiga tickets comprando, subindo de level ou com o criador ⚠️*\n\nVocê tambem pode pedir para um amigo transferir dinheiro para você vou ensinar\n\n*Exemplo: ${prefix}tfticket+ @*`
}

exports.satukos = () => {
	return`*🍯 Use o comando junto do 1 / ativar ou 0 / desativar 🍯*`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`*┏◚◚◚◚◚◚◚◚◚◚◚◚┓*\n      🔥 𝚂𝚞𝚊 𝙲𝚘𝚗𝚝𝚊🔥\n*┗◛◛◛◛◛◛◛◛◛◛◛◛┛*\n\n┣⊱ 🌹 *Nome* : ${pushname}\n┣⊱ 🪝 *Numero* : ${sender.split("@")[0]}\n┣⊱ 💸 *Dinheiro* : ${uangkau}\n┗━━━━━━━━━━`
}

exports.afkOn = (pushname, reason) => {
    return `_「AFK Ativado Com Sucesso」_\n\n➸ *Nome*: ${pushname}\n➸ *Motivo*: ${reason}`
}

exports.afkOnAlready = () => {
    return `_AF Ja Esta Ativo_`
}

exports.afkMentioned = (getReason, getTime) => {
    return `*「 AFK EM PRECESSO 」*\n\n_Esta AFK Não Se Preocupe_\n➸ *Alasan*: ${getReason}\n➸ *Sejak*: ${getTime}`
}

exports.afkDone = (pushname) => {
    return `*${pushname} _Voltou Do AFK_`
}

exports.banadd = (pnom3) => {
	return`*「🐺 Voce esta exilado 🐺」*

*Nome* : ${pnom3}`
}

exports.dellban = (hnom3) => {
	return`*「🆙 Você voltou do exilamento🆙」*

*Nome* : ${hnom3}
*Expiração* : 🇯🇵🇧🇷\n\n*⚔️ Voltou ⚔️*`
}

exports.benned = () => {
	return`*「Voce esta exilado」*`
}

exports.premadd = (pnom) => {
	return`*「🐺 Parabens Você agora é Premium 🐺」*

*Nome* : ${pnom}`
}

exports.dellprem = (hnom) => {
	return`*「🆙 Voce perdeu seu premium 🆙」*

*Nome* : ${hnom}
*Expiração* : 🇯🇵🇧🇷\n\n*Tente ganhar novamente gostou das vantagens?*`
}

exports.premon = (pushname) => {
	return`*🆙 Você não é premium 🆙*`
}

exports.divindadeadd = (pnom1) => {
	return`*「🌹 Parabens Você é uma divindade 🌹」*

*Nome* : ${pnom1}`
}

exports.delldivindade = (hnom1) => {
	return`*「🆙 Voce perdeu sua divindade 🆙」*

*Nome* : ${hnom1}
*Expiração* : 🇯🇵🇧🇷\n\n*Tente ganhar novamente gostou das vantagens?*`
}

exports.deuso = (pushname) => {
	return`*🆙 Você não é divindade 🆙*`
}

exports.onipo = (pushname) => {
	return`*🆙 Você não é o dono 🆙*`
}

exports.azaradd = (pnomresi) => {
	return`*「🚧 _Voce Esta Dentro Do Jogo, Cuidado Qualquer Palavra Dita Descuidadamente É Game Over Para Você_ 🚧」*`
}

exports.dellazar = (hnomresi) => {
	return`*「🆙 Voce esta fora do jogo 🆙」*`
}