const {
    WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   mentionedJid,
   processTime,
} = require('@adiwajshing/baileys');
const qrcode = require("qrcode-terminal") 
const moment = require("moment-timezone") 
const fs = require("fs") 
const util = require('util')
const fetch = require('node-fetch')
const os = require('os')
const crypto = require('crypto')
const imageToBase64 = require('image-to-base64')
const axios = require('axios')
const { color, bgcolor } = require('./lib/color')
const { donasi } = require('./lib/donasi')
const { menucompleto } = require('./lib/menucompleto')
const { menuprincipal } = require('./lib/menuprincipal')
const { menuevento } = require('./lib/menuevento')
const { menualeatorio } = require('./lib/menualeatorio')
const { menucompras } = require('./lib/menucompras')
const { ajudaevento } = require('./lib/ajudaevento')
const { menudono } = require('./lib/menudono')
const { menuprevilegio } = require('./lib/menuprevilegio')
const { titulos } = require('./lib/titulos')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { exec, spawn } = require("child_process")
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const tiktod = require('tiktok-scraper')
const brainly = require('brainly-scraper')
const ffmpeg = require('fluent-ffmpeg')
const path = require('path')
const ms = require('parse-ms')
const toMs = require('ms')
const cd = 4.32e+7
const { removeBackgroundFromImageFile } = require('remove.bg')
const { ind } = require('./language')

/********** MENU SETTING **********/
const vcard = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + 'FN:Nando Admin\n' 
            + 'ORG: Pengembang XBot;\n' 
            + 'TEL;type=CELL;type=VOICE;waid=556296831370:+556296831370\n' 
            + 'END:VCARD'			
blocked = []   
prefix = '#'
limitawal = 10
memberlimit = 0
ator = 'Universo'
namo = 'Nan Killi'
game = 'gtx'
game1 = 'logica'
libi = 'leitoa'
umm = '***********'
doism = '***********'
tresm = '***********'
quatrom = '***********'
cincom = '***********'
seism = '***********'
setem = '***********'
oitom = '***********'
novem = '***********'
dezm = '***********'
gprova = '000'
fprova = '9090'
cr = '*🌟 Nan Killi 🌟*'
/*************************************/

/******** OWNER NUMBER**********/
const ownerNumber = ["556296831370@s.whatsapp.net"] 
/************************************/

       
/*********** LOAD FILE ***********/
const setiker = JSON.parse(fs.readFileSync('./strg/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./strg/video.json'))
const audionye = JSON.parse(fs.readFileSync('./strg/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./strg/image.json'))
const _leveling = JSON.parse(fs.readFileSync('./database/group/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./database/user/level.json'))
const _registered = JSON.parse(fs.readFileSync('./database/bot/registered.json'))
const welkom = JSON.parse(fs.readFileSync('./database/bot/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./database/bot/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./database/bot/simi.json'))
const event = JSON.parse(fs.readFileSync('./database/bot/event.json'))
const jogo = JSON.parse(fs.readFileSync('./database/bot/jogo.json'))
const resistencia = JSON.parse(fs.readFileSync('./database/user/resistencia.json'))
const _limit = JSON.parse(fs.readFileSync('./database/user/limit.json'))
const uang = JSON.parse(fs.readFileSync('./database/user/uang.json'))
const rank = JSON.parse(fs.readFileSync('./database/user/rank.json'))
const contador = JSON.parse(fs.readFileSync('./database/user/contador.json'))
const prem = JSON.parse(fs.readFileSync('./database/user/prem.json'))
const luz = JSON.parse(fs.readFileSync('./database/cla/luz.json'))
const escuridao = JSON.parse(fs.readFileSync('./database/cla/escuridao.json'))
const porco = JSON.parse(fs.readFileSync('./database/user/porco.json'))
const deuses = JSON.parse(fs.readFileSync('./database/user/deuses.json'))
const oni = JSON.parse(fs.readFileSync('./database/user/oni.json'))
const ban = JSON.parse(fs.readFileSync('./database/user/ban.json'))
const antilink = JSON.parse(fs.readFileSync('./database/group/antilink.json'))
const antitrava = JSON.parse(fs.readFileSync('./database/group/antitrava.json'))
const liberei = JSON.parse(fs.readFileSync('./database/quiz/liberei.json'))
const um = JSON.parse(fs.readFileSync('./database/quiz/um.json'))
const dois = JSON.parse(fs.readFileSync('./database/quiz/dois.json'))
const tres = JSON.parse(fs.readFileSync('./database/quiz/tres.json'))
const quatro = JSON.parse(fs.readFileSync('./database/quiz/quatro.json'))
const cinco = JSON.parse(fs.readFileSync('./database/quiz/cinco.json'))
const seis = JSON.parse(fs.readFileSync('./database/quiz/seis.json'))
const sete = JSON.parse(fs.readFileSync('./database/quiz/sete.json'))
const oito = JSON.parse(fs.readFileSync('./database/quiz/oito.json'))
const nove = JSON.parse(fs.readFileSync('./database/quiz/nove.json'))
const dez = JSON.parse(fs.readFileSync('./database/quiz/dez.json'))
/*********** END LOAD ***********/

/********** FUNCTION ***************/
const getLevelingXp = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].xp
            }
        }

        const getLevelingLevel = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].level
            }
        }

        const getLevelingId = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].id
            }
        }

        const addLevelingXp = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].xp += amount
                fs.writeFileSync('./database/user/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingLevel = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].level += amount
                fs.writeFileSync('./database/user/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingId = (sender) => {
            const obj = {id: sender, xp: 1, level: 1}
            _level.push(obj)
            fs.writeFileSync('./database/user/level.json', JSON.stringify(_level))
        }
             
         const getRegisteredRandomId = () => {
            return _registered[Math.floor(Math.random() * _registered.length)].id
        }

        const addRegisteredUser = (userid, sender, age, time, serials) => {
            const obj = { id: userid, name: sender, age: age, time: time, serial: serials }
            _registered.push(obj)
            fs.writeFileSync('./database/bot/registered.json', JSON.stringify(_registered))
        }

        const createSerial = (size) => {
            return crypto.randomBytes(size).toString('hex').slice(0, size)
        }

        const checkRegisteredUser = (sender) => {
            let status = false
            Object.keys(_registered).forEach((i) => {
                if (_registered[i].id === sender) {
                    status = true
                }
            })
            return status
        }
        
        const addATM = (sender) => {
        	const obj = {id: sender, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
        }
        
        const addKoinUser = (sender, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
        
        const checkATMuser = (sender) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }   

        const addNAN = (sender) => {
        	const obj1 = {id: sender, rank : 0}
            rank.push(obj1)
            fs.writeFileSync('./database/user/rank.json', JSON.stringify(rank))
        }
        
        const addPontUser = (sender, amount) => {
            let position = false
            Object.keys(rank).forEach((i) => {
                if (rank[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                rank[position].rank += amount
                fs.writeFileSync('./database/user/rank.json', JSON.stringify(rank))
            }
        }
        
        const checkNANuser = (sender) => {
        	let position = false
            Object.keys(rank).forEach((i) => {
                if (rank[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return rank[position].rank
            }
        }
		
		const addNON = (sender) => {
        	const obj2 = {id: sender, contador : 0}
            contador.push(obj2)
            fs.writeFileSync('./database/user/contador.json', JSON.stringify(contador))
        }
        
        const addContUser = (sender, amount) => {
            let position = false
            Object.keys(contador).forEach((i) => {
                if (contador[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                contador[position].contador += amount
                fs.writeFileSync('./database/user/contador.json', JSON.stringify(contador))
            }
        }
        
        const checkNONuser = (sender) => {
        	let position = false
            Object.keys(contador).forEach((i) => {
                if (contador[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return contador[position].contador
            }
        }
        
        const bayarLimit = (sender, amount) => {
        	let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit -= amount
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }
        	
        const confirmATM = (sender, amount) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
		
		const confirmNAN = (sender, amount) => {
        	let position = false
            Object.keys(rank).forEach((i) => {
                if (rank[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                rank[position].rank -= amount
                fs.writeFileSync('./database/user/rank.json', JSON.stringify(rank))
            }
        }
		
		const confirmNON = (sender, amount) => {
        	let position = false
            Object.keys(contador).forEach((i) => {
                if (contador[i].id === contador) {
                    position = i
                }
            })
            if (position !== false) {
                contador[position].contador -= amount
                fs.writeFileSync('./database/user/contador.json', JSON.stringify(contador))
            }
        }
        
         const limitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 1
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }	

         const laimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 5
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }

         const lbimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 10
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }

         const lcimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 25
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }

         const ldimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 50
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }

         const leimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 100
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }

         const lfimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 250
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }	

         const lgimitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 400
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            }
        }		
        
         const getPremiumExpired = (sender) => {
		    let position = null
		    Object.keys(prem).forEach((i) => {
		        if (prem[i].id === sender) {
		            position = i
		        }
		    })
		    if (position !== null) {
		        return prem[position].expired
		    }
		} 
		
		const expiredCheck = () => {
		    setInterval(() => {
		        let position = null
		        Object.keys(prem).forEach((i) => {
		            if (Date.now() >= prem[i].expired) {
		                position = i
		            }
		        })
		        if (position !== null) {
		            console.log(`Premium Expirado: ${prem[position].id}`)
		            prem.splice(position, 1)
		            fs.writeFileSync('./database/user/prem.json', JSON.stringify(prem))
		        }
		    }, 1000)
		}
		
		const getAllPremiumUser = () => {
		    const array = []
		    Object.keys(prem).forEach((i) => {
		        array.push(prem[i].id)
		    })
		    return array
		}

         
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `${pad(hours)} Hora ${pad(minutes)} Minuto ${pad(seconds)} Segundo`
}

function addMetadata(packname, author) {	
	if (!packname) packname = 'WABot'; if (!author) author = 'Bot';	
	author = author.replace(/[^a-zA-Z0-9]/g, '');	
	let name = `${author}_${packname}`
	if (fs.existsSync(`./${name}.exif`)) return `./${name}.exif`
	const json = {	
		"sticker-pack-name": packname,
		"sticker-pack-publisher": author,
	}
	const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
	const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

	let len = JSON.stringify(json).length	
	let last	

	if (len > 256) {	
		len = len - 256	
		bytes.unshift(0x01)	
	} else {	
		bytes.unshift(0x00)	
	}	

	if (len < 16) {	
		last = len.toString(16)	
		last = "0" + len	
	} else {	
		last = len.toString(16)	
	}	

	const buf2 = Buffer.from(last, "hex")	
	const buf3 = Buffer.from(bytes)	
	const buf4 = Buffer.from(JSON.stringify(json))	

	const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

	fs.writeFile(`./${name}.exif`, buffer, (err) => {	
		return `./${name}.exif`	
	})	

}

/********** FUNCTION ***************/

const client = new WAConnection()
   client.on('qr', qr => {
   qrcode.generate(qr, { small: true })
   console.log(color('[','white'),color('∆','red'),color(']','white'),color('qr already scan.subscribe','white'),color('YOU','red'),color('TUBE','white'),color('Nan Killi','yellow'))
})

client.on('credentials-updated', () => {
	const authInfo = client.base64EncodedAuthInfo()
   console.log(`credentials updated!`)
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t'))
})
fs.existsSync('./session.json') && client.loadAuthInfo('./session.json')
client.connect();


client.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await client.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Olá @${num.split('@')[0]}\n*Bem vindo ao grupo*\n*${mdata.subject}*\n🇧🇷╬ sᴇᴊᴀ ʙᴇᴍ ᴠɪɴᴅᴏ (ᴀ)╬🇯🇵\n🏮 sᴇ ɑᴘʀᴇsᴇɴᴛᴇ ᴄᴏᴍ: (obrigɑtório)\n➦Nome(real):\n➠Idɑde: \n\n➦ *Só fique no grupo se for ser ativo*\n\n➠Foto (opcionɑl)\n\n🧧 Regras na descrição\n\n*Se quiser seguir a gente no instagram segue o link abaixo*\n\n*https://instagram.com/universo.otakuu?igshid=176irbj5c6r17*\n\n*Se vocês estiverem no grupo da recepção marca um ADM para por vcs no grupo principal.*`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `*Digite F para o* @${num.split('@')[0]} *foi embora 😖*`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
	client.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	client.on('message-new', async (mek) => {
		try {
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			const timi = moment.tz('Asia/Jakarta').add(30, 'days').calendar();
			const timu = moment.tz('Asia/Jakarta').add(20, 'days').calendar();
            body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
            var tas = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''
            const mesejAnti = tas.slice(0).trim().split(/ +/).shift().toLowerCase()
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const txt = mek.message.conversation
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)
			const tescuk = ["0@s.whatsapp.net"]
			const isGroup = from.endsWith('@g.us')
			const q = args.join(' ')
			const botNumber = client.user.jid
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			pushname = client.contacts[sender] != undefined ? client.contacts[sender].vname || client.contacts[sender].notify : undefined
			const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupDesc = isGroup ? groupMetadata.desc : ''
            const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
            
            /************** SCURITY FEATURE ************/
            const isEventon = isGroup ? event.includes(from) : false
			const isJogo = isGroup ? jogo.includes(from) : false
			const isLiberei = isGroup ? liberei.includes(from) : false
			const isUm = isGroup ? um.includes(from) : false
			const isDois = isGroup ? dois.includes(from) : false
			const isTres = isGroup ? tres.includes(from) : false
			const isQuatro = isGroup ? quatro.includes(from) : false
			const isCinco = isGroup ? cinco.includes(from) : false
			const isSeis = isGroup ? seis.includes(from) : false
			const isSete = isGroup ? sete.includes(from) : false
			const isOito = isGroup ? oito.includes(from) : false
			const isNove = isGroup ? nove.includes(from) : false
			const isDez = isGroup ? dez.includes(from) : false	
            const isRegistered = checkRegisteredUser(sender)
			const isPrem = prem.includes(sender)
			const isLuz = luz.includes(sender)
			const isEscuridao = escuridao.includes(sender)
			const isPorco = isGroup ? porco.includes(sender) : false
			const isDeuses = deuses.includes(sender)
			const isResistencia = isGroup ? resistencia.includes(sender) : false
			const isOni = oni.includes(sender)
			const isBanned = ban.includes(sender)
			const isAntiLink = isGroup ? antilink.includes(from) : false
			const isAntiTrava = isGroup ? antitrava.includes(from) : false
            const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
            const isLevelingOn = isGroup ? _leveling.includes(from) : false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : false
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isImage = type === 'imageMessage'
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				client.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				client.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const sendImage = (teks) => {
		    client.sendMessage(from, teks, image, {quoted:mek})
		    }
		    const costum = (pesan, tipe, target, target2) => {
			client.sendMessage(from, pesan, tipe, {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` }}})
			}
			const costumimg = ( pesan , tipe, target , caption) => {
			client.sendMessage(from, pesan , tipe , {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: {"imageMessage":{url: 'https://mmg.whatsapp.net/d/f/Ahj0ACnTjSHHm6-HjqAUBYiCu2-85zMZp_-EhiXlsd6A.enc',mimetype: 'image/jpeg',caption: `${caption}`,fileSha256: '0Pk0qJyQFn9FCtslZrydJHRQDKryjYcdP7I3CmRrHRs=',fileLength: '20696',height: 360,width: 382,mediaKey: 'N43d/3GY7GYQpgBymb9qFY5O9iNDXuBirXsNZk+X61I=',fileEncSha256: 'IdFM58vy8URV+IUmOqAY3OZsvCN6Px8gaJlRCElqhd4=',directPath: '/v/t62.7118-24/35174026_475909656741093_8174708112574209693_n.enc?oh=2a690b130cf8f912a9ca35f366558743&oe=6061F0C6',mediaKeyTimestamp: '1614240917',jpegThumbnail: '/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMASAMBIgACEQEDEQH/xAAwAAADAAMBAAAAAAAAAAAAAAAABAUBAwYCAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAoy6kcWS2eH8miq17B553Thh1BgyTY9iULYfndGBmbSwNEV3eWXpjwZElG09WJckXCj8sWBVc1ZKXj2ZYaoWHnc67K3PbKwtZOqzLrzdQAg5fWFRUeCNTQG2pEKJ0wCD/xAAoEAACAgIBAQkAAwEAAAAAAAABAgADBBEScQUQEyEiMTJBYSNRYmP/2gAIAQEAAT8AaZzfEdwWcGMTE1jNv3M1ozDb+SD2jTO+Yigk6A3KqhseIdfkroTYbXQRrkVuJOplKEuOpjtpxF+IjTO+YnZoBvj4pa/msHtMnHZrgymZ6hCnSJsDl+ys7rTpGmevxMwLFS/1fcA7iNzPsDXaH1NccYH+2lJ1SnSNMlOdcbY6iYGa9g4OJzXW9zI7SBJrpjqxsA9zMkcMetf2V7NKD/McgAkxsis7EcA2fkxkqSkaYbMGRu3hr0x6q6ckufaUMpsexj0ma4Y0qDKhqlektyntXiQO4qWI0PONVZWNsNTmZwewekEwo1fpYaMZdvWf2DYrXoO/ARWLNL6VuXiYcSsuK9eXGYtHhM/nsTPVQgb7iDkydRCNBYYx1Ozj6nmSStRIgJ8UH/nMJiTZs/c7RPwExhu+vrH+p//EAB4RAAIBBAMBAAAAAAAAAAAAAAABAhAREjIhMDFC/9oACAECAQE/AOpJsxEqIj4TfNqXygIWpLc+ZEdBH//EAB4RAAICAgIDAAAAAAAAAAAAAAABAjEQETJBAxJx/9oACAEDAQE/AHWVeHQtYrDaNkno7GOzxP10xzWipDHZHidx+EuQz//Z',scansSidecar: 'choizTOCOFXo21QcOR/IlCehTFztHGnB3xo4F4d/kwmxSJJIbMmvxg==',scanLengths: [Array],midQualityFileSha256: '68OHK4IyhiKDNgNAZ3SoXsngzYENebQkV4b/RwhhYIY=',midQualityFileEncSha256: '2EYOLCXx+aqg9RyP6xJYChQNbEjXZmc0EcSwHzoyXx0='}}}})
			}
	        /*****************END SCURITY FEATURE ********/
			
			
			
			var per = '*[▒▒▒▒▒▒▒▒▒▒] 0%*'
			const peri = 5000 * (Math.pow(2, getLevelingLevel(sender)) - 1)
			const perl = peri-getLevelingXp(sender) 
			const resl = Math.round(100-((perl/getLevelingXp(sender))*100))
			if (resl <= 10) {
				per = `*[█▒▒▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 20) {
				per = `*[██▒▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 30) {
				per = `*[███▒▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 40) {
				per = `*[████▒▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 50) {
				per = `*[█████▒▒▒▒▒] ${resl}%*`
			} else if (resl <= 60) {
				per = `*[██████▒▒▒▒] ${resl}%*`
			} else if (resl <= 70) {
				per = `*[███████▒▒▒] ${resl}%*`
			} else if (resl <= 80) {
				per = `*[████████▒▒] ${resl}%*`
			} else if (resl <= 90) {
				per = `*[█████████▒] ${resl}%*`
			} else if (resl <= 100) {
				per = `*[██████████] ${resl}%*`
			}
			
			
			//auto Expired
            expiredCheck()
			
			//function rank
            const levelRole = getLevelingLevel(sender)
         var role = '*Cidadão (A)*'
         if (levelRole <= 3) {
            role = '*Superando Limites*'
        } else if (levelRole <= 5) {
            role = '*Rompendo Os Ceus*'
        } else if (levelRole <= 7) {
            role = '*Iniciando Jornada*'
        } else if (levelRole <= 9) {
            role = '*A Imensidão Dos Universos*'
        } else if (levelRole <= 12) {
            role = '*Em Busca Do Equilibrio*'
        } else if (levelRole <= 14) {
            role = '*Trilhando Meu Caminho*'
        } else if (levelRole <= 17) {
            role = '*Mestre (A)*'
        } else if (levelRole <= 20) {
            role = '*Transcedente do Tempo*'
		} else if (levelRole <= 23) {
            role = '*Imperatriz De Guerra (Imperador)*'	
        } else if (levelRole <= 25) {
            role = '*Heroi (Heroina)*'
        } else if (levelRole <= 30) {
            role = '*Principe (Princesa)*'
        } else if (levelRole <= 35) {
            role = '*Rank SSS*'
        } else if (levelRole <= 40) {
            role = '*Demonio Antigo SSS*'
        } else if (levelRole <= 45) {
            role = '*Rei (Rainha)*'
        } else if (levelRole <= 50) {
            role = '*Entrando No Reino Dos Deuses*'
        } else if (levelRole <= 55) {
            role = '*Filhos de Divindades*'
        } else if (levelRole <= 60) {
            role = '*Soberano Continental*'
        } else if (levelRole <= 65) {
            role = '*Classificação Mundial*'
        } else if (levelRole <= 70) {
            role = '*Divindades*'
        } else if (levelRole <= 80) {
            role = '*⚠️ Perigo Incalculavel ⚠️*'
        } else if (levelRole <= 100) {
            role = '*🌍 Onipotencia 🌎*'
        }
		
		    var premi = '❌'
			if (isPrem) {
				premi = '🔛 '
			}
			if (isOwner) {
				premi = '֍֎⳼ₜᵣₒᵥãₒ ᎧᎮ ᭄'
			}
			
			var divindade = '❌'
			if (isDeuses) {
				divindade = '🔛 '
			}			
			if (isOwner) {
				divindade = '™ꪶ࿋྄ིᤢꫂ๖ۣۜℍ𝕒𝕣𝕦𓊗༢࿔ྀુ𓆪'
			}
			
			var onipotente = '❌'
			if (isOni) {
				onipotente = '🔛 _Zerou_'
			}			
            if (isOwner) {
				onipotente = 'ᏫᎮ• ࿐​ꪀꪖ​ꪀᴳᵒᵈ〗'
			}
			
			if (isRegistered) {
				    const regis =['Feliz','Triste','Raiva','Vingativo','Motivado','Desconfiado','Imperativo','Desafiador','Depressivo','Amargurado','Infeliz','Louco','Sede Por Sangue','Sem emoção','Confiança','Assassino','Escuridão','Explorar','Viajar','Conhecimento','Redenção','Humildade','Motivado','Avançar','Desistir','Sumir','Namorar','Riqueza','Grandeza','Medo','Assustado','Amedrontado','Comediante','Engraçado','Vencedor','Perdedor','Pobreza','Fome','Frio','Quente','Sede','Tesão','Equilibrado']
					const tered = regis[Math.floor(Math.random() * regis.length)]
			        emotion = tered
			}	
			
			if (isRegistered) {
				    const char =['𝒩𝒶𝓇𝓊𝓉𝑜','𝔾𝕠𝕜𝕦','𝒜𝓈𝓉𝒶','𝔾𝕚𝕠𝕣𝕟𝕠','𝔎𝔞𝔪𝔦 𝔗𝔢𝔫𝔠𝔥𝔦','𝕊𝕒𝕤𝕦𝕜𝕖','𝑀𝒶𝒹𝒶𝓇𝒶','𝔅𝔦𝔩𝔩𝔰','𝒲𝒽𝒾𝓈','𝕍𝕖𝕘𝕖𝕥𝕒','𝒰𝓇𝒶𝓂𝑒𝓈𝒽𝒾','𝕃𝕦𝕗𝕗𝕪','𝒵𝑜𝓇𝑜','𝕊𝕒𝕟𝕛𝕚','𝒰𝓈𝑜𝓅𝓅','ℕ𝕒𝕞𝕚','𝒜𝓁𝓊𝒸𝒶𝓇𝒹','𝔾𝕠𝕙𝕒𝕟','𝑀𝒾𝓃𝒶𝓉𝑜','𝕂𝕒𝕟𝕖𝕜𝕚','𝒵𝑒𝓃𝑜-𝓈𝒶𝓂𝒶','𝐵𝒶𝓇𝒷𝒶-𝒩𝑒𝑔𝓇𝒶','𝔹𝕒𝕣𝕓𝕒-𝔹𝕣𝕒𝕟𝕔𝕒','𝒥𝒾𝓇𝒶𝓎𝒶-𝒮𝑒𝓃𝓈𝑒𝒾','ℙ𝕒𝕚𝕟','𝐼𝓉𝒶𝒸𝒽𝒾','𝒮𝒶𝓀𝓊𝓇𝒶','ℍ𝕚𝕟𝕒𝕥𝕒','𝐵𝓊𝓁𝓂𝒶','𝒮𝒶𝒾𝓉𝒶𝓂𝒶','𝔽𝕦𝕓𝕦𝕜𝕚','𝔾𝕖𝕟𝕠𝕤','𝕄𝕚𝕜𝕒𝕤𝕒','𝐸𝓇𝑒𝓃','𝕃𝕖𝕧𝕚','𝒜𝓈𝓊𝓃𝒶','𝐸𝓇𝓏𝒶 𝒮𝒸𝒶𝓇𝓁𝑒𝓉','ℝ𝕚𝕒𝕤 𝔾𝕣𝕖𝕞𝕠𝕣𝕪','𝐻𝑜𝓂𝓊𝓇𝒶 𝒜𝓀𝑒𝓂𝒾','ℝ𝕚𝕟 𝕋𝕠𝕙𝕤𝕒𝕜𝕒','𝑀𝒾𝓀𝑜𝓉𝑜 𝑀𝒾𝓈𝒶𝓀𝒶','𝕄𝕚𝕥𝕤𝕦𝕙𝕒','𝒯𝑜𝓊𝓀𝒶']
					const avatar = char[Math.floor(Math.random() * char.length)]
			        personagem = avatar
			}
			
			
			
	        //function leveling
            if (isGroup && isRegistered && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
                if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
                const amountXp = Math.floor(Math.random() * 2) + 110
                const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
                const getLevel = getLevelingLevel(sender)
                addLevelingXp(sender, amountXp)
                if (requiredXp <= getLevelingXp(sender)) {
                    addLevelingLevel(sender, 1)
                    bayarLimit(sender, 2)
                    await reply(ind.levelup(pushname, sender, getLevelingXp,  getLevel, getLevelingLevel, role, premi, divindade, onipotente))
                }
            } catch (err) {
                console.error(err)
            }
        }
          //function check limit
          const checkLimit = (sender) => {
          	let found = false
                    for (let lmt of _limit) {
                        if (lmt.id === sender) {
                            let limitCounts = limitawal - lmt.limit
                            if (limitCounts <= 0) return client.sendMessage(from,`*🇧🇷🇯🇵 seus tickets acabaram 🇯🇵🇧🇷*\n\n*🐼 Compre ou suba de nivel para conseguir mais 🐼*`, text,{ quoted: mek})
                            client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                            found = true
                        }
                    }
                    if (found === false) {
                        let obj = { id: sender, limit: 0 }
                        _limit.push(obj)
                        fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
                        client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                    }
				}
				
			//funtion limited
            const isLimit = (sender) =>{ 
		      let position = false
              for (let i of _limit) {
              if (i.id === sender) {
              	let limits = i.limit
              if (limits >= limitawal ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //function laimited
            const isLaimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 5 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion lbimited
            const isLbimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 10 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion lcimited
            const isLcimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 25 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion ldimited
            const isLdimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 50 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion leimited
            const isLeimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 100 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion lfimited
            const isLfimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 250 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
	 
	        //funtion lgimited
            const isLgimit = (sender) =>{ 
          	if (isOwner) {return false;}
		      let position = false
              for (let lmt of _limit) {
              if (lmt.id === sender) {
              	let limits = limitawal - lmt.limit
              if (limits <= 400 ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./database/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }
			
		    if (isGroup) {
					try {
						const getmemex = groupMembers.length	
					    if (getmemex <= memberlimit) {
						reply(`Limite de membros do grupo muito pouco o limite minimo é ${memberlimit}`)
						setTimeout( () => {
 	                           client.groupLeave(from) 
 					   	}, 5000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("1")
							}, 4000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("2")
							}, 3000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("3")
							}, 2000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("4")
							}, 1000)
								setTimeout( () => {
								client.updatePresence(from, Presence.composing)
								reply("5")
							}, 0)
					    }
		       } catch (err) { console.error(err)  }
 	       }
	   
         
            //function balance
            if (isRegistered ) {
            const checkATM = checkATMuser(sender)
            try {
                if (checkATM === undefined) addATM(sender)
                const uangsaku = Math.floor(Math.random() * 1) + 20
                addKoinUser(sender, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }
		
		    //function balance rank
            if (isRegistered ) {
            const checkNAN = checkNANuser(sender)
            try {
                if (checkNAN === undefined) addNAN(sender)
                const ranksaku = Math.floor(Math.random() * 0) + 0
                addPontUser(sender, ranksaku)
            } catch (err) {
                console.error(err)
            }
        }
		
		    //function balance contador
            if (!isResistencia ) {
            const checkNON = checkNONuser(sender)
            try {
                if (checkNON === undefined) addNON(sender)
                const contadorsaku = Math.floor(Math.random() * 1) + 1
                addContUser(sender, contadorsaku)
            } catch (err) {
                console.error(err)
            }
        }
// ANTI LINK GRUP
                if (mesejAnti.includes("://chat.whatsapp.com/")){
		        if (!isGroup) return
		        if (!isAntiLink) return
		        if (isGroupAdmins) return reply('✅ *Adms do grupo podem mandar* ✅')
		        client.updatePresence(from, Presence.composing)
		        if (mesejAnti.includes("#Nandinho")) return reply("*#Nando*")
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`⚠️ *Adeus* ⚠️`)
		        setTimeout( () => {
			        client.groupRemove(from, [kic]).catch((e)=>{reply(`🙌 *Preciso de ADM* 🙌`)})
		        }, 500)
		        setTimeout( () => {
			        client.updatePresence(from, Presence.composing)
			        reply("🌟 _Apagar_ 🌟")
		        }, 0)
	        } 
// ANTI TRAVA GRUP			
			    if (txt.length > 500){
                if (!isGroup) return
		        if (!isAntiTrava) return
		        if (isGroupAdmins) return reply(`⚓ *Ele é ADM* ⚓`)
		        frhan.updatePresence(from, Presence.composing)
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        costum(monospace(`❌ _Proibido trava no grupo_ ❌`))
		        setTimeout( () => {
			    client.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
	         	}, 0)
	        }
/*
]=============================================================================> MENU DO QUIZ JOGO  <==========================================================================[
*/
// Resposta Quiz
                if (mesejAnti.includes(game)){
	        if (!isGroup) return
	        if (!isJogo) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
	        setTimeout( () => {
	              const one5 = Math.ceil(Math.random() * 5000)
		      const ale = Math.ceil(Math.random() * 30)
		      const ace = Math.ceil(Math.random() * 8)
		      addPontUser(sender, ace)
                      addLevelingXp(sender, one5)
                      addLevelingLevel(sender, 0)
		      bayarLimit(sender, ale)
                      reply(`️🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n🆙 *XP* 🆙: ${one5}\n🧧 *Tickets* 🧧: ${ale}\n🌟 *Pontos* 🌟: ${ace}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
		      jogo.splice(from, 1)
			fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
			reply('🌟🇯🇵 ✅ 🇯🇵🌟')   
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Resposta Quiz dois
                if (mesejAnti.includes(game1)){
	        if (!isGroup) return
	        if (!isJogo) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 5000)
		      const ale1 = Math.ceil(Math.random() * 30)
		      const ace1 = Math.ceil(Math.random() * 8)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
		      jogo.splice(from, 1)
			fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
			reply('🌟🇯🇵 ✅ 🇯🇵🌟')   
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
/*
]=============================================================================> MENU DO QUIZ DO GAME  <==========================================================================[
*/
// Quiz Personagens
                if (mesejAnti.includes(libi)){
	        if (!isGroup) return
	        if (!isLiberei) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 5000)
		      const ale1 = Math.ceil(Math.random() * 30)
		      const ace1 = Math.ceil(Math.random() * 8)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
		      liberei.splice(from, 1)
			fs.writeFileSync('./database/quiz/liberei.json', JSON.stringify(liberei))
			reply('🌟🇯🇵 ✅ 🇯🇵🌟')   
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens um 
                if (mesejAnti.includes(umm)){
			    if (!isUm) return
	        if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			um.splice(from, 1)
			fs.writeFileSync('./database/quiz/um.json', JSON.stringify(um))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens dois
                if (mesejAnti.includes(doism)){
				if (!isDois) return
	        if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			dois.splice(from, 1)
			fs.writeFileSync('./database/quiz/dois.json', JSON.stringify(dois))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)   
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens tres
                if (mesejAnti.includes(tresm)){
				if (!isTres) return
	        if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			tres.splice(from, 1)
			fs.writeFileSync('./database/quiz/tres.json', JSON.stringify(tres))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens quatro
                if (mesejAnti.includes(quatrom)){
			if (!isQuatro) return		
	        if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			quatro.splice(from, 1)
			fs.writeFileSync('./database/quiz/quatro.json', JSON.stringify(quatro))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens cinco
                if (mesejAnti.includes(cincom)){
			    if (!isCinco) return
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			cinco.splice(from, 1)
			fs.writeFileSync('./database/quiz/cinco.json', JSON.stringify(cinco))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            } 
// Quiz Personagens seis
                if (mesejAnti.includes(seism)){
			    if (!isSeis) return
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			seis.splice(from, 1)
			fs.writeFileSync('./database/quiz/seis.json', JSON.stringify(seis))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            }
// Quiz Personagens sete
                if (mesejAnti.includes(setem)){
			    if (!isSete) return
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
		    sete.splice(from, 1)
			fs.writeFileSync('./database/quiz/sete.json', JSON.stringify(sete))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            }
// Quiz Personagens oito
                if (mesejAnti.includes(oitom)){
				if (!isOito) return
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			oito.splice(from, 1)
			fs.writeFileSync('./database/quiz/oito.json', JSON.stringify(oito))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            }
// Quiz Personagens nove
                if (mesejAnti.includes(novem)){
				if (!isNove) return	
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			nove.splice(from, 1)
			fs.writeFileSync('./database/quiz/nove.json', JSON.stringify(nove))   
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`) 
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            }
// Quiz Personagens dez
                if (mesejAnti.includes(dezm)){
				if (!isDez) return
	            if (!isGroup) return
	        client.updatePresence(from, Presence.composing)
	        if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	        reply(`⚠️ *Analisando sua resposta* ⚠️`)
			dez.splice(from, 1)
			fs.writeFileSync('./database/quiz/dez.json', JSON.stringify(dez))
	        setTimeout( () => {
	              const mining6 = Math.ceil(Math.random() * 3000)
		      const ale1 = Math.ceil(Math.random() * 10)
		      const ace1 = Math.ceil(Math.random() * 3)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	        }, 1000)
	        setTimeout( () => {
	            client.updatePresence(from, Presence.composing)
	            reply("🌟 _Analisando_ 🌟")
	        }, 0)
            }	
/*
]=============================================================================> MENU ANTI PORCO <==========================================================================[
*/			
// ANTI PORCO
                if (mesejAnti.includes('enfiar','putona','putinha','bucetinha','gozando','gozei','goza','pau','cu','puta','desgraçado','lixo','viado','gay','boiola','vtnc','penis','meu pau','filho da puta','lixinho','toma no cu','vai toma no cu','pnc','inuteis','vermes','comi sua mae','comi sua mãe','rabuda','buceta','pauzao','pau','pinto','porra','caralho','viadinho','viadao','cu','bot lixo','grupo lixo','toma no seus cu','meu ovo','seu cu','seu rabo','cala boca','enfia o dedo no cu','lezado','baitola')){
		        if (!isGroup) return
                if (!isPorco) return
		        client.updatePresence(from, Presence.composing)
		        if (mesejAnti.includes("#Nandinho")) return reply("*#Nando*")
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`⚠️ *Porco ${sender.split("@")[0]} Irei de remover por causa da sua porquisse* ⚠️`)
		        setTimeout( () => {
			        client.groupRemove(from, [kic]).catch((e)=>{reply(`🙌 *Preciso de ADM* 🙌`)})
		        }, 5000)
		        setTimeout( () => {
			        client.updatePresence(from, Presence.composing)
			        reply("🌟 _Um Porco Quebrando As Regras, Detectado_ 🌟")
		        }, 500)
	        }
/*
]=============================================================================> MENU DO QUIZ INTELIGENCIA ( CERTO OU ERRADO ) <==========================================================================[
*/
// Inteligencia
                if (mesejAnti.includes(gprova)){
				if (!isGroup) return
                if (!isResistencia) return
	            client.updatePresence(from, Presence.composing)
	            if (mesejAnti.includes("nando")) return reply("*cuidado")
	            const acertu = `${sender.split("@")[0]}@s.whatsapp.net`
	            reply(`⚠️ *Analisando* ⚠️`)
			    var ars = resistencia
			    for( var i = 0; i < ars.length; i++){
			    if ( ars[i] === acertu) {
			    ars.splice(i, 1);
			    i--;
			    fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(ars))
			     }
			    }
	            setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
                reply("*Voce Perdeu - Vou Retirar Voce Do Jogo*")
	            }, 500)
            }
// Inteligencia dois
                if (mesejAnti.includes(fprova)){
				if (!isGroup) return
                if (!isResistencia) return
	            client.updatePresence(from, Presence.composing)
	            if (mesejAnti.includes("nando")) return reply("*Sem spam*")
	            const acertu = `${sender.split("@")[0]}@s.whatsapp.net`
	            reply(`⚠️ *Analisando* ⚠️`)
			    resistencia.splice(from, 1)
			    fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(resistencia))
				setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
				obj2 = '[]'
			      resistencia.splice(obj2)
				   fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(resistencia))
				  await reply(`Inteligencia Finalizado`)
				}, 1000)
	            setTimeout( () => {
			    client.updatePresence(from, Presence.composing)
                const mining6 = Math.ceil(Math.random() * 10000)
		      const ale1 = Math.ceil(Math.random() * 150)
		      const ace1 = Math.ceil(Math.random() * 20)
		      addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
		      bayarLimit(sender, ale1)
                      reply(`🕋 *PARABENS VOCÊ GANHOU O EVENTO* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
	            }, 5000)
            }			
             //kolor
			colors = ['red','white','black','blue','yellow','green']
			
			//detector media
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			
			//private chat message
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			
			//group message
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			
			switch(command) {
/*
]================================================================> MENU LISTA DE RANK & TOPS <=============================================================================[
*/				
				case 'melhoreslvl':
				case 'top':
				if (!isGroup) return reply(ind.groupo())
				if (isLaimit(sender)) return reply(ind.limitend(pusname))	
			    if (!isBotGroupAdmins) return reply(ind.badmin())
				if (isBanned) return reply(ind.benned())
				_level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
				uang.sort((a, b) => (a.uang < b.uang) ? 1 : -1)
                let leaderboardlvl = '*🇧🇷🇯🇵 🇷 🇦 🇳 🇰 🇮 🇳 🇬  🇩 🇦 🇸  🇱 🇪 🇳 🇩 🇦 🇸  🇯🇵🇧🇷*\n\n_🚧 Esse é o top 10 dos que estão com level mais altos So os ativos são capazes de chegar ao topo 🚧_\n\n'
                let leaderboarduang = '*🇯🇵🇧🇷 ℝ𝔸ℕ𝕂𝕀ℕ𝔾 𝔻𝕆𝕊 ℝ𝕀ℂ𝕆 🇧🇷🇯🇵*\n\n_🏔️ Ranking top 10 dos mais ricos, para ficar no topo tem que saber fazer dinheiro 🏔️_\n\n'
                let nom = 0
                try {
                    for (let i = 0; i < 10; i++) {
                        nom++
                        leaderboardlvl += `🌪️🌋 *[${nom}]* wa.me/${_level[i].id.replace('@s.whatsapp.net', '')}\n┗⊱🌺 *XP*: ${_level[i].xp} *Level*: ${_level[i].level}\n`
                        leaderboarduang += `💸💰 *[${nom}]* wa.me/${uang[i].id.replace('@s.whatsapp.net', '')}\n┣⊱💎 *Dinheiro*: ${uang[i].uang}\n`
                    } 
                    await reply(leaderboardlvl)
                    await reply(leaderboarduang)
                } catch (err) {
                    console.error(err)
                    await reply(`*🏆 10 participantes para criar o Top10 🏆*`)
                }
				    await laimitAdd(sender)
				break
                case 'rank':
				case 'ranking':
				if (!isRegistered) return reply(ind.noregis())
				if (!isGroup) return reply(ind.groupo())
				if (isLaimit(sender)) return reply(ind.limitend(pusname))	
			    if (!isBotGroupAdmins) return reply(ind.badmin())
				if (isBanned) return reply(ind.benned())
				rank.sort((a, b) => (a.rank < b.rank) ? 1 : -1)
                  let leaderboardrank = '🧧 *🕋 [я̲̅α̲̅и̲̅k̲̅i̲̅и̲̅g̲̅ ̲̅є̲̅v̲̅є̲̅и̲̅т̲̅σ̲̅s̲̲̅̅] 🕋* 🧧\n\n_Participe de eventos para ganhar pontos para cada evento voce ganha de 1 a 3 pontos aleatoriamente_\n*Final do Ranking O Primeiro Coloca Ganhará um premio*\n _Possiveis Premios_ : *Dinheiro, Previlegios, Cargos ETC...*\n\n'
                let nom1 = 0
                try {
                    for (let i = 0; i < 20; i++) {
                        nom1++                        
                        leaderboardrank += `🔥🔝 *[${nom1}]* wa.me/${rank[i].id.replace('@s.whatsapp.net', '')}\n┣⊱🌟 *Pontos*: ${rank[i].rank}\n`
                    }
                    await reply(leaderboardrank)
                } catch (err) {
                    console.error(err)
                    await reply(`*🏆 10 participantes para criar o Top10 🏆*`)
                }
				    await laimitAdd(sender)
					break
/*
]================================================================> MENU CONTADOR <==================================================================================[
*/
                   case 'resetcontador':
				if (!isRegistered) return reply(ind.noregis())
				if (!isOwner) return reply(mess.only.ownerB)
				  obj = body.slice(10)
			      contador.splice(obj)
				   fs.writeFileSync('./database/user/contador.json', JSON.stringify(contador))
				  await reply(`Contador resetado`)
				  break
                   case 'resetjogo':
				if (!isRegistered) return reply(ind.noregis())
				if (!isOwner) return reply(mess.only.ownerB)
				  obj2 = body.slice(10)
			      resistencia.splice(obj2)
				   fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(resistencia))
				  await reply(`Inteligencia Finalizado`)
                break
                case 'contador':
				case 'contando':
				if (!isRegistered) return reply(ind.noregis())
				if (!isGroup) return reply(ind.groupo())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
			    if (!isBotGroupAdmins) return reply(ind.badmin())
				if (isBanned) return reply(ind.benned())
				contador.sort((a, b) => (a.contador < b.contador) ? 1 : -1)
                  let leaderboardcontador = '🧧 *🕋 Contador Evento 🕋* 🧧\n\n_Evento de inteligencia e sorte_\n*Final do Ranking O Primeiro Coloca Ganhará um premio*\n _Possiveis Premios_ : *Dinheiro, Previlegios, Cargos ETC...*\n\n'
                let nom2 = 0
                try {
                    for (let i = 0; i < 5; i++) {
                        nom2++                        
                        leaderboardcontador += `🔥🔝 *[${nom2}]* wa.me/${contador[i].id.replace('@s.whatsapp.net', '')}\n┣⊱🌟 *Pontos*: ${contador[i].contador}\n`
                    }
                    await reply(leaderboardcontador)
                } catch (err) {
                    console.error(err)
                    await reply(`*🏆 5 participantes para criar o Top5 🏆*`)
                }
				    await limitAdd(sender)											
				break
/*
]=============================================================================> MENU QUE PEGA UM CONTATO ALEATORIO NOS GRUPOS <==========================================================================[
*/				
				case 'parceiro':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
                if (!isRegistered) return reply( ind.noregis())
                if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('🇧🇷🇯🇵 *Procurando um parceiro* 🇧🇷🇯🇵')
                await reply(`wa.me/${anug}`)
				await limitAdd(sender)
                await reply( `*🐻 Encontrei um vai la conversa 🐻*\n*${prefix}next* 🐦 *Use esse comando se quer encontrar outro* 🐦`)
            break
            case 'next':
			    if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
                if (!isRegistered) return reply( ind.noregis())
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('🇧🇷🇯🇵 *Procurando um membro* 🇧🇷🇯🇵')
                await reply(`wa.me/${anug}`)
                await reply( `*🐻 Essa pessoa sera seu desafio 🐻*\n\n*🇧🇷🇯🇵 Boa Sorte 🇧🇷🇯🇵*`)
				await limitAdd(sender)
            break
/*
]=============================================================================> MENU DE TRANSFERENCIA DE DINHEIRO <==========================================================================[
*/			
				case 'tfdinheiro':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuan0 = args[0].replace('@','')
                const jumblah = ('550')
				if(isNaN(jumblah)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblah) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuantf = tujuan0 + '@s.whatsapp.net'
                fee = 0.10 *  jumblah
                hasiltf = jumblah - fee
                addKoinUser(tujuantf, hasiltf)
                confirmATM(sender, jumblah)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuan0}\n\n💰 *Valor da transferência* : ${jumblah}\n\n💰 *Imposto* : ${fee}`)
            break
				case 'tfdinheiro+':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuan00 = args[0].replace('@','')
                const jumblah0 = ('1550')
				if(isNaN(jumblah0)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblah0) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuan0tf = tujuan00 + '@s.whatsapp.net'
                fee = 0.10 *  jumblah0
                hasiltf = jumblah0 - fee
                addKoinUser(tujuan0tf, hasiltf)
                confirmATM(sender, jumblah0)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuan00}\n\n💰 *Valor da transferência* : ${jumblah0}\n\n💰 *Imposto* : ${fee}`)
            break
				case 'tfdinheiro++':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuan000 = args[0].replace('@','')
                const jumblah00 = ('5500')
				if(isNaN(jumblah00)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblah00) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuan00tf = tujuan000 + '@s.whatsapp.net'
                fee = 0.10 *  jumblah00
                hasiltf = jumblah00 - fee
                addKoinUser(tujuan00tf, hasiltf)
                confirmATM(sender, jumblah00)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuan000}\n\n💰 *Valor da transferência* : ${jumblah00}\n\n💰 *Imposto* : ${fee}`)
            break
				case 'tfgrana':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    const tujuanp = args[0].replace('@','')
                const jumblahp= ('15000')
				if(isNaN(jumblahp)) return await reply('*Tem que ser numeros*')	
                if (checkATMuser(sender) < jumblahp) return reply(`🐡 *Você nem tem esse dinheiro como quer transferi-lo* 🐡`)
                const tujuanptf = tujuanp + '@s.whatsapp.net'
                fee = 0.10 *  jumblahp
                hasiltf = jumblahp - fee
                addKoinUser(tujuanptf, hasiltf)
                confirmATM(sender, jumblahp)
                addKoinUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Dinheiro 🇯🇵🇧🇷 」*\n\n💰 *de* : +${sender.split("@")[0]}\n\n💰 *para* : +${tujuanp}\n\n💰 *Valor da transferência* : ${jumblahp}\n\n💰 *Imposto* : ${fee}`)
            break
/*
]=============================================================================> MENU DE TRANSFERENCIA DE TICKETS <==========================================================================[
*/			
				case 'tfticket':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan1 = ('1')
                const tujuan11 = args[0].replace('@','')
				const tujuan11tf = tujuan11 + '@s.whatsapp.net'
                fee = 0 *  tujuan1
                hasiltf = tujuan1 - fee
                bayarLimit(tujuan11tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan11}\n\n🧧 *Valor da transferência* : ${tujuan1} \n\n🧧 *Imposto* : ${fee}`)      
                await limitAdd(sender)
			break
				case 'tfticket+':
				if (isBanned) return reply(ind.benned())
				if (isLaimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan2 = ('5')
                const tujuan22 = args[0].replace('@','')
				const tujuan22tf = tujuan22 + '@s.whatsapp.net'
                fee = 0 *  tujuan2
                hasiltf = tujuan2 - fee
                bayarLimit(tujuan22tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan22}\n\n🧧 *Valor da transferência* : ${tujuan2} \n\n🧧 *Imposto* : ${fee}`)      
                await laimitAdd(sender)	
			break
				case 'tfticket++':
				if (isBanned) return reply(ind.benned())
				if (isLbimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan3 = ('10')
                const tujuan33 = args[0].replace('@','')
				const tujuan33tf = tujuan33 + '@s.whatsapp.net'
                fee = 0 *  tujuan3
                hasiltf = tujuan3 - fee
                bayarLimit(tujuan33tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan33}\n\n🧧 *Valor da transferência* : ${tujuan3} \n\n🧧 *Imposto* : ${fee}`)      
                await lbimitAdd(sender)	
			break
				case 'tfticket+++':
				if (isBanned) return reply(ind.benned())
				if (isLcimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan4 = ('25')
                const tujuan44 = args[0].replace('@','')
				const tujuan44tf = tujuan44 + '@s.whatsapp.net'
                fee = 0 *  tujuan4
                hasiltf = tujuan4 - fee
                bayarLimit(tujuan44tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan44}\n\n🧧 *Valor da transferência* : ${tujuan4} \n\n🧧 *Imposto* : ${fee}`)      
                await lcimitAdd(sender)	
			break
				case 'tfticket++++':
				if (isBanned) return reply(ind.benned())
				if (isLdimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan5 = ('50')
                const tujuan55 = args[0].replace('@','')
				const tujuan55tf = tujuan55 + '@s.whatsapp.net'
                fee = 0 *  tujuan5
                hasiltf = tujuan5 - fee
                bayarLimit(tujuan55tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan55}\n\n🧧 *Valor da transferência* : ${tujuan5} \n\n🧧 *Imposto* : ${fee}`)      
                await ldimitAdd(sender)	
			break
				case 'tftickets':
				if (isBanned) return reply(ind.benned())
				if (isLeimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
                const tujuan6 = ('100')
                const tujuan66 = args[0].replace('@','')
				const tujuan66tf = tujuan66 + '@s.whatsapp.net'
                fee = 0 *  tujuan6
                hasiltf = tujuan6 - fee
                bayarLimit(tujuan66tf, hasiltf)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Transferencia Tickets 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${tujuan66}\n\n🧧 *Valor da transferência* : ${tujuan6} \n\n🧧 *Imposto* : ${fee}`)      
                await leimitAdd(sender)	
                break
/*
]=============================================================================> MENU DE COMPRA DE TICKETS <==========================================================================[
*/				
				case 'comprar+1':
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('1')
				const koinPerlimit = 600
				const total = koinPerlimit * payout
				if ( checkATMuser(sender) <= total) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total ){ 
				    confirmATM(sender, total)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+5':
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('5')
				const koinPerlimit1 = 550
				const total1 = koinPerlimit1 * payout
				if ( checkATMuser(sender) <= total1) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total1 ){ 
				    confirmATM(sender, total1)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit1} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+10':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('10')
				const koinPerlimit2 = 520
				const total2 = koinPerlimit2 * payout
				if ( checkATMuser(sender) <= total2) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total2 ){ 
				    confirmATM(sender, total2)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit2} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+20':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('20')
				const koinPerlimit3 = 510
				const total3 = koinPerlimit3 * payout
				if ( checkATMuser(sender) <= total3) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total3 ){ 
				    confirmATM(sender, total3)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit3} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+30':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('30')
				const koinPerlimit4 = 500
				const total4 = koinPerlimit4 * payout
				if ( checkATMuser(sender) <= total4) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total4 ){ 
				    confirmATM(sender, total4)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit4} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+40':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('40')
				const koinPerlimit5 = 480
				const total5 = koinPerlimit5 * payout
				if ( checkATMuser(sender) <= total5) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total5 ){ 
				    confirmATM(sender, total5)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit5} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
				case 'comprar+50':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('50')
				const koinPerlimit6 = 450
				const total6 = koinPerlimit6 * payout
				if ( checkATMuser(sender) <= total6) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total6 ){ 
				    confirmATM(sender, total6)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit6} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ para comprar tickets use o comando comprar+1, comprar+5, comprar+10, comprar+20, comprar+30, comprar+40, comprar+50 ⚠️*\n\n*Exemplo : ${prefix}comprar +1*\n\n${createSerial(15)}`)
					}
				break
/*
]=======================> COMANDO DE COMPRA PARA QUEM É PREMIUM <==================[
*/				
				case 'comprar+':
				if (isBanned) return reply(ind.benned())
				if (!isPrem) return reply(ind.premon(pushname))	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('20')
				const koinPerlimit7 = 150
				const total7 = koinPerlimit7 * payout
				if ( checkATMuser(sender) <= total7) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total7 ){ 
				    confirmATM(sender, total7)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit7} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ Você é premium promoção 10 tickets por apenas 300,00 RS ⚠️*\n\n*Exemplo : ${prefix}comprar+1*\n\n${createSerial(15)}`)
					}
				break
/*
]=======================> COMANDO DE COMPRA PARA QUEM É DIVINDADE <==================[
*/				
				case 'comprardemais':
				if (isBanned) return reply(ind.benned())
				if (!isDeuses) return reply(ind.deuso(pushname))	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('40')
				const koinPerlimit8 = 150
				const total8 = koinPerlimit8 * payout
				if ( checkATMuser(sender) <= total8) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total8 ){ 
				    confirmATM(sender, total8)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit8} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ Você tem divindade promoção 20 tickets por apenas 300,00 RS KD ⚠️*\n\n*Exemplo : ${prefix}comprar+1*\n\n${createSerial(15)}`)
					}	
				break
/*
]=======================> COMANDO DE COMPRA PARA QUEM É DIVINDADE <==================[
*/				
				case 'comprartudo':
				if (isBanned) return reply(ind.benned())
				if (!isOni) return reply(ind.deuso(pushname))	
				if (!isRegistered) return reply(ind.noregis())
			    payout = ('100')
				const koinPerlimit9 = 50
				const total9 = koinPerlimit9 * payout
				if ( checkATMuser(sender) <= total9) return reply(`💰 *Seu dinheiro não é suficiente* 💰`)
				if ( checkATMuser(sender) >= total9 ){ 
				    confirmATM(sender, total9)
			        bayarLimit(sender, payout)
					await reply(`*「 🇯🇵🇧🇷 Compre Tickets Aqui 🇯🇵🇧🇷 」*\n\n*Vendedor* : *Bot*\n*Comprador* : *${pushname}*\n\n*Quantidades de Tickets Comprado* : ${payout} \n\n*Preço do ticket* : ${koinPerlimit9} / *🐼 Cada Ticket 🐼*\n\n*Seu dinheiro final* : ${checkATMuser(sender)}\n\n*⚠️ Você tem divindade promoção 20 tickets por apenas 300,00 RS KD ⚠️*\n\n*Exemplo : ${prefix}comprar+1*\n\n${createSerial(15)}`)
					}	
				break
/*
]=============================================================================> MENU DE DISTRIBUIÇÃO DE TICKET E PONTOS <==========================================================================[
*/				
				case 'ticket':
				if (isBanned) return reply(ind.baned())
				if (!isOwner) return reply(ind.ownerb())
				if (!isRegistered) return reply(ind.noregis())
				if (!q.includes('/')) return  reply(ind.wrongf())
                const destino = q.substring(0, q.indexOf('/') - 1)
                const tudo = q.substring(q.lastIndexOf('/') + 1)
                if (checkATMuser(sender) < tudo) return reply(`🐡 *tem certeza?* 🐡`)
                const destinotf = `${destino.replace("@", '')}@s.whatsapp.net`
                fee = 0 *  tudo
                hasiltf = tudo - fee
                bayarLimit(destinotf, hasiltf)
                confirmATM(sender, tudo)
                bayarLimit('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Parabens 🇯🇵🇧🇷 」*\n\n🧧 *de* : +${sender.split("@")[0]}\n\n🧧 *para* : +${destino}\n\n🧧 *Valor dado* : ${tudo}\n\n🧧 *Metade vai pro bolso do patrão* : ${fee}\n\n*🇯🇵🇧🇷 Universo Otaku 🇯🇵🇧🇷*`)	
                break
				case 'rank+':
				if (isBanned) return reply(ind.baned())
				if (!isOwner) return reply(ind.ownerb())
				if (!isRegistered) return reply(ind.noregis())
				if (!q.includes('/')) return  reply(ind.wrongf())
                const destino0 = q.substring(0, q.indexOf('/') - 1)
                const tudo00 = q.substring(q.lastIndexOf('/') + 1)
                if (checkATMuser(sender) < tudo00) return reply(`🐡 *tem certeza?* 🐡`)
                const destino00tf = `${destino0.replace("@", '')}@s.whatsapp.net`
                fee = 0 *  tudo00
                hasiltf = tudo00 - fee
                addPontUser(destino00tf, hasiltf)
                confirmATM(sender, tudo00)
                addPontUser('556296831370@s.whatsapp.net', fee)
                reply(`*「 🇧🇷🇯🇵 Parabens 🇯🇵🇧🇷 」*\n\n⚠️ *de* : +${sender.split("@")[0]}\n\n⚠️ *para* : +${destino0}\n\n⚠️ *Valor dado* : ${tudo00}`)
				break
/*
]=============================================================================> MENU DE RESPOSTA <==========================================================================[
*/				
				case 'resposta':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (!isJogo) return reply(`${pushname} ⚠️ *JA ACERTARAM A PERGUNTA, FIQUE LIGADO PARA A PROXIMA* ⚠️`) 
                      if (args[0] === game) {
                      const one5 = Math.ceil(Math.random() * 5000)
					  const ale = Math.ceil(Math.random() * 10)
					  const ace = Math.ceil(Math.random() * 3)
					  addPontUser(sender, ace)
                      addLevelingXp(sender, one5)
                      addLevelingLevel(sender, 0)
					  bayarLimit(sender, ale)
                      reply(`️🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n🆙 *XP* 🆙: ${one5}\n🧧 *Tickets* 🧧: ${ale}\n🌟 *Pontos* 🌟: ${ace}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
					  jogo.splice(from, 1)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('🌟🇯🇵 ✅ 🇯🇵🌟')
                      } else if (args[0] === game1) {
                      const mining6 = Math.ceil(Math.random() * 2500)
					  const ale1 = Math.ceil(Math.random() * 10)
					  const ace1 = Math.ceil(Math.random() * 3)
					  addPontUser(sender, ace1)
                      addKoinUser(sender, mining6)
					  bayarLimit(sender, ale1)
                      await reply(`🕋 *PARABENS VOCÊ ACERTOU* 🕋\n\n💸 *Dinheiro* 💸: ${mining6}\n🧧 *Tickets* 🧧: ${ale1}\n🌟 *Pontos* 🌟: ${ace1}\n\n⚠️ _Fale para o wa.me/556296831370 que voce ganhou_ ⚠️`)
					  jogo.splice(from, 1)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('🌟🇯🇵 ✅ 🇯🇵🌟')
                      } else {
						reply(ind.jogando())
					  }
				break
/*
]=============================================================================> MENU DO EVENTO DE XP <==========================================================================[
*/				
				case 'up':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (isLimit(sender)) return reply(ind.limitend(pushname))
                      if (!isEventon) return reply(`Desculpa ${pushname} O evento não esta ativado`)
                      if (isOwner) {
                      const one = Math.ceil(Math.random() * 20000)
                      addLevelingXp(sender, one)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Nivel desconhecido, mais ${one}XP para você* ⚜️`)
                      }else{
                      const mining = Math.ceil(Math.random() * 15000)
                      addLevelingXp(sender, mining)
                      await reply(`🆙 *Parabens* 🆙 *${pushname}* *🆙 voce pega xp 🆙* *${mining}Xp*`)
                      }
                    await limitAdd(sender)
				break
/*
]=============================================================================> MENU DE APOSTAS DE DINHEIRO E XP <==========================================================================[
*/				
				case 'apostaxp':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())   
                      if (isLcimit(sender)) return reply(ind.limitend(pushname))
                      if (isOwner) {
                      const one1 = Math.ceil(Math.random() * 20000)
                      addLevelingXp(sender, one1)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Criador ? Hihihihi ${one1} XP* ⚜️`)
                      }else{ 
                      const mining1 = Math.ceil(Math.random() * 19000)
                      addLevelingXp(sender, mining1)
                      await reply(`*Ha ha ha, ${pushname} Voce esta com sorte? ${mining1} XP*`)
                      }
                    await lcimitAdd(sender)			
				break
				case 'aposta$':
				      if (isBanned) return reply(ind.benned())
                      if (!isRegistered) return reply(ind.noregis())
                      if (isLcimit(sender)) return reply(ind.limitend(pushname))
                      if (isOwner) {
                      const one2 = Math.ceil(Math.random() * 19500)
                      addKoinUser(sender, one2)
                      addLevelingLevel(sender, 0)
                      reply(`️ *Criador ? Hihihihi ${one2} R$* ⚜️`)
                      }else{
                      const mining2 = Math.ceil(Math.random() * 19500)
                      addKoinUser(sender, mining2)
                      await reply(`*Ha ha ha, ${pushname} voce esta com sorte? ${mining2} R$*`)
                      }
                    await lcimitAdd(sender)	   					
					break
/*
]=============================================================================> MENU DE LEVEL, CONTA E TICKETS <==========================================================================[
*/					
				case 'level':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
                if (!isLevelingOn) return reply(ind.lvlnoon())
                if (!isGroup) return reply(ind.groupo())
                const userLevel = getLevelingLevel(sender)
                const userXp = getLevelingXp(sender)
                if (userLevel === undefined && userXp === undefined) return reply(ind.lvlnul())
                const requiredXp = 5000 * (Math.pow(2, userLevel) - 1)
                resul = `┏━━❉ *🇧🇷🇯🇵 Seu Status 🇧🇷🇯🇵* ❉━━\n\n┣⊱🌍 *Nome* : ${pushname}\n\n┣⊱🌎 *Numero* : wa.me/${sender.split("@")[0]}\n\n┣⊱🌏 *Jogador XP* :  ${userXp}/${requiredXp}\n\n┣⊱🌍 *Jogador Level* : ${userLevel}\n\n*👑 Voce consegue ficar no topo? 👑* (Sem flood)`
               client.sendMessage(from, resul, text, { quoted: mek})
                .catch(async (err) => {
                        console.error(err)
                        await reply(`Error!\n${err}`)
                    })
					await limitAdd(sender)
					break	
				case 'conta':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				const kantong = checkATMuser(sender)
			    const rankss = checkNANuser(sender)
				reply(ind.uangkau(pushname, sender, kantong, role, premi, divindade, onipotente, getLevelingLevel, rankss, emotion, personagem))
				break
				case 'tickets':
				   if (isBanned) return reply(ind.benned())
				   if (!isRegistered) return reply(ind.noregis())
				   checkLimit(sender)		   
			    break
/*
]=============================================================================> MENU DE IMAGENS GIFS VIDEOS <==========================================================================[
*/				
				case 'neko':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			    anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nekonime?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
			    await limitAdd(sender)
				break
                case 'waifus':
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isNsfw) return reply(ind.nsfwoff())
					gatauda = body.slice(8)
					reply(ind.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)
			    break
			    case 'waifu':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			    anu = await fetchJson(`https://tobz-api.herokuapp.com/api/waifu?apikey=BotWeA`)
				buf = await getBuffer(anu.image)
				texs = ` *🐬 Nome da personagem 🐬* : ${anu.name} \n\n*🐋 Descrição 🐋* : ${anu.desc} \n\n*🐳 Fonte 🐳* : ${anu.source} \n\n 🇧🇷🇯🇵`
				client.sendMessage(from, buf, image, { quoted: mek, caption: `${texs}` })
			    await limitAdd(sender)
				 break 		
		    case 'nome':
		    if (isBanned) return reply(ind.benned())
		    if (!isRegistered) return reply(ind.noregis())
		    if (isLimit(sender)) return reply(ind.limitend(pusname))
		    if (args.length < 1) return reply(ind.wrongf())
		    aruga = body.slice(5)
		    reply(ind.wait())
		    aruga = await getBuffer(`https://api.xteam.xyz/ttp?file&text=${aruga}`)
		    client.sendMessage(from, aruga, image, {caption: '*ok*', quoted: mek})
		    await limitAdd(sender)
				break
                case 'anime🚹':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				    try {
						res = await fetchJson(`https://tobz-api.herokuapp.com/api/husbu?apikey=BotWeA`)
						buffer = await getBuffer(res.image)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '*Universo Otaku*'})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('❌ *ERROR* ❌')
					}
					await limitAdd(sender)
				break
                case 'anime🚺':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					gatauda = body.slice(8)
					reply(ind.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					await limitAdd(sender)	
				break 
		    case 'nulis':
		    if (isBanned) return reply(ind.benned())
		    if (!isRegistered) return reply(ind.noregis())
		    if (isLimit(sender)) return reply(ind.limitend(pusname))
		    if (args.length < 1) return reply(ind.wrongf())
		    aruga = body.slice(7)
		    reply(ind.wait())
		    aruga = await getBuffer(`https://api.zeks.xyz/api/nulis?text=${aruga}&apikey=apivinz`)
		    client.sendMessage(from, aruga, image, {caption: 'ok', quoted: mek})
		    await limitAdd(sender)	
			    break 
					case 'pin':
					if (isBanned) return reply(ind.benned())
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					client.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.fdci.se/rep.php?gambar=${body.slice(11)}`, {method: 'get'})
					reply(ind.wait())
					n = JSON.parse(JSON.stringify(data));
					nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek, caption: `*🐯 Universo Otaku 🐯*`})
					await limitAdd(sender)
				break
                case 'imgale':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                const trut =['🦁 *Imagem Aleatoria Saindo* 🦁']
					const ttrth = trut[Math.floor(Math.random() * trut.length)]
					truteh = await getBuffer(`https://source.unsplash.com/user/erondu/1600x900`)
					client.sendMessage(from, truteh, image, { caption: '*Universo Otaku*\n\n'+ ttrth, quoted: mek })
					await limitAdd(sender)
					break
                case 'pokemon':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=pokemon`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
					break
                case 'loli':
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomloli?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
			break
                case 'imgmaker':
		if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                var ghh = body.slice(9)
		    var quote = ghh.split("-")[0];
		    var wm = ghh.split("-")[1];
		    var bg = ghh.split("-")[2];
		    const pref = `🖋️ *Como Usar* 🖋️: \n${prefix}imgmaker texto-nome-tema\n\n🖋️ *Exemplo* 🖋️ \n\n${prefix}imgmaker Meu Bot É Muito Top|Nando|random`
		    if (args.length < 1) return reply(pref)
		    reply(ind.wait())
		    anu = await fetchJson(`https://terhambar.com/aw/qts/?kata=${quote}&author=${wm}&tipe=${bg}`, {method: 'get'})
		    buffealr = await getBuffer(anu.result)
		    client.sendMessage(from, buffealr, image, {caption: '✒️', quoted: mek})
		    await limitAdd(sender)
		    break
                case 'kpop':
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomkpop?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'fofo':
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/husbu2?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'anime':
		if (isBanned) return reply(ind.benned())
		if (!isRegistered) return reply(ind.noregis())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
	        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=BotWeA` , {method: 'get'})
                buf = await getBuffer(anu.result)
                client.sendMessage(from, buf, image, { quoted: mek, caption: '⚓ *Nice* ⚓' })
	        await limitAdd(sender)
		    break
                case 'dog':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=anjing`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
					break
				case 'cat':
				if (isBanned) return reply(ind.benned())
                if (!isRegistered) return reply(ind.noregis())
                if (isLimit(sender)) return reply(ind.limitend(pusname))
                   if (!isGroup) return reply(ind.groupo())
                   if (!isNsfw) return reply(ind.nsfwoff())
					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=kucing`, {method: 'get'})
					reply(ind.wait())
					var n = JSON.parse(JSON.stringify(anu));
					var nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					client.sendMessage(from, pok, image, { quoted: mek })
					await limitAdd(sender)
					break
			    case 'map':
			if (isBanned) return reply(ind.benned())
			if (!isRegistered) return reply(ind.noregis())
			if (isLimit(sender)) return reply(ind.limitend(pusname))
                anu = await fetchJson(`https://mnazria.herokuapp.com/api/maps?search=${body.slice(5)}`, {method: 'get'})
                buffer = await getBuffer(anu.gambar)
                client.sendMessage(from, buffer, image, {quoted: mek, caption: `${body.slice(5)}`})
				await limitAdd(sender)	
                break
/*
]=============================================================================> FIGURINHAS <=============================================================================[
*/				
                case 'anime😢':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/cry?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
                case 'anime+18':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
					case 'animekiss':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/kiss?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
					case 'animegif':
				if (isBanned) return reply(ind.benned())	
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/hug?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
				case '🐯': 
				case '🦁':
				case 's':
				    if (!isRegistered) return reply(ind.noregis())
				    if (isBanned) return reply(ind.benned())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
                    await limitAdd(sender)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(ind.stikga())
							})
							.on('end', function () {
								console.log('Finish')
								buffer = fs.readFileSync(ran)
								client.sendMessage(from, buffer, sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(ind.wait())
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(ind.stikga())
							})
							.on('end', function () {
								console.log('Finish')
								buffer = fs.readFileSync(ran)
								client.sendMessage(from, buffer, sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					        } else {
						reply(`🦦 *Envie fotos com legendas ${prefix}🦁* 🦦`)
				    }
					break
					case 'toimg':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (!isQuotedSticker) return reply('📌 *Marque uma figurinha !* 📌 !')
					reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(ran)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '*🥶 Up 🥵* '})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
					break
/*
]==================================================================> VARIADOS <========================================================[
*/					
				case 'posso':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					posso = body.slice(1)
					const pos =['🇯🇵🇧🇷 Pode 🇯🇵🇧🇷','🇯🇵🇧🇷 Não pode 🇯🇵🇧🇷','🇯🇵🇧🇷 Irei pensar 🇯🇵🇧🇷','🇯🇵🇧🇷 Talvez 🇯🇵🇧🇷','🇯🇵🇧🇷 Voce decide dessa vez 🇯🇵🇧🇷','🇯🇵🇧🇷 Que pergunta sem noção 🇯🇵🇧🇷']
					const so = pos[Math.floor(Math.random() * pos.length)]
					client.sendMessage(from, 'Questão : *'+posso+'*\n\nResposta : '+ so, text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'sorte':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					sorte = body.slice(1)
					const sor =['*1*','*2*','*3*','*4*','*5*','*6*','*7*','*8*','*9*','*10*','*Perdeu 🐣*','*Ganhou 🦁*']
					const te = sor[Math.floor(Math.random() * sor.length)]
					client.sendMessage(from, 'Questão : *'+sorte+'*\n\nResposta : '+ te+'%', text, { quoted: mek })
					await limitAdd(sender)
					break
					break
				case 'quando':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					quando = body.slice(1)
					const qua =['*daqui 1*','*daqui 2*','*daqui 3*','*daqui 4*','*daqui 5*','*daqui 6*','*daqui 7*','*daqui 8*','*daqui 9*','*daqui 10*','*daqui 11*','*daqui 12*','*daqui 13*','*daqui 14*','*daqui 15*','*daqui 16*','*daqui 17*','*daqui 18*','*daqui 19*','*daqui 20*','*daqui 21*','*daqui 22*','*daqui 23*','*daqui 24*','*daqui 25*','*daqui 26*','*daqui 27*','*daqui 28*','*daqui 29*','*daqui 30*','*daqui 31*','*daqui 32*','*daqui 33*','*daqui 34*','*daqui 35*','*daqui 36*','*daqui 37*','*daqui 38*','*daqui 39*','*daqui 40*','*daqui 41*','*daqui 42*','*daqui 43*','*daqui 44*','*daqui 45*','*daqui 46*','*daqui 47*','*daqui 48*','*daqui 49*','*daqui 50*','*daqui 51*','*daqui 52*','*daqui 53*','*daqui 54*','*daqui 55*','*daqui 56*','*daqui 57*','*daqui 58*','*daqui 59*','*daqui 60*','*daqui 61*','*daqui 62*','*daqui 63*','*daqui 64*','*daqui 65*','*daqui 66*','*daqui 67*','*daqui 68*','*daqui 69*','*daqui 70*','*daqui 71*','*daqui 72*','*daqui 73*','*daqui 74*','*daqui 75*','*daqui 76*','*daqui 77*','*daqui 78*','*daqui 79*','*daqui 80*','*daqui 81*','*daqui 82*','*daqui 83*','*daqui 84*','*daqui 85*','*daqui 86*','*daqui 87*','*daqui 88*','*daqui 89*','*daqui 90*','*daqui 91*','*daqui 94*','*daqui 95*','*daqui 96*','*daqui 97*','*daqui 98*','*daqui 99*','*daqui 100*','*Iludido por mais de*']
					const ndo = qua[Math.floor(Math.random() * qua.length)]
					client.sendMessage(from, 'Questão : *'+quando+'*\n\nResposta : '+ ndo+' anos', text, { quoted: mek })
					await limitAdd(sender)
					break
/*
]========================================================================> ARMAZENAMENTO <======================================================================[
*/		
				case 'adaud':
				if (isLbimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					if (!isQuotedAudio) return reply('_Marque O Audio_')
					svst = body.slice(7)
					if (!svst) return reply('*Qual o nome do audio?*')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await client.downloadMediaMessage(boij)
					audionye.push(`${svst}`)
					fs.writeFileSync(`./strg/audio/${svst}.mp3`, delb)
					fs.writeFileSync('./strg/audio.json', JSON.stringify(audionye))
					client.sendMessage(from, `🌳 *Audio Adicionado com Sucesso digite ${prefix}audios* 🌳`, MessageType.text, { quoted: mek })
                    await lbimitAdd(sender)
					break
				case 'exaud':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					namastc = body.slice(7)
					buffer = fs.readFileSync(`./strg/audio/${namastc}.mp3`)
					client.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek, ptt: true })
					await limitAdd(sender)
					break
				case 'audios':
				case 'listaad':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					teks = '*🎧 Lista De Audios 🎧*\n\n'
					for (let awokwkwk of audionye) {
						teks += `-🎼 ${awokwkwk}\n`
					}
					teks += `\n*Total : ${audionye.length}*`
					client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": audionye } })
					await limitAdd(sender)
					break
				case 'addimage':
				if (isLbimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					if (!isQuotedImage) return reply('_Marque A Imagem_')
					svst = body.slice(10)
					if (!svst) return reply('*Qual o nome da imagem?*')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await client.downloadMediaMessage(boij)
					imagenye.push(`${svst}`)
					fs.writeFileSync(`./strg/image/${svst}.jpeg`, delb)
					fs.writeFileSync('./strg/image.json', JSON.stringify(imagenye))
					client.sendMessage(from, `🌳 *Imagem Adicionada com Sucesso digite ${prefix}imagens* 🌳`, MessageType.text, { quoted: mek })
                    await lbimitAdd(sender)
					break
				case 'eximagem':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					namastc = body.slice(10)
					buffer = fs.readFileSync(`./strg/image/${namastc}.jpeg`)
					client.sendMessage(from, buffer, image, { quoted: mek, caption: `Result From Database : ${namastc}.jpeg` })
					await limitAdd(sender)
					break
				case 'imagens':
				case 'listimage':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					teks = '*🏖️ Lista De Imagens 🏜️*\n\n'
					for (let awokwkwk of imagenye) {
						teks += `-🏝️ ${awokwkwk}\n`
					}
					teks += `\n*Total : ${imagenye.length}*`
					client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": imagenye } })
					await limitAdd(sender)
					break
/*
]=====================================================================================> CLÃS <================================================================[
*/	 
                    case 'adluz':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnomluz = `${args[0].replace('@','')}@s.whatsapp.net`
				    luz.push(pnomluz)
				    fs.writeFileSync('./database/cla/luz.json',JSON.stringify(luz))
				    reply(ind.premadd(args[0]))
					await limitAdd(sender)
					break
					case 'adescuridao':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnomescuri = `${args[0].replace('@','')}@s.whatsapp.net`
				    escuridao.push(pnomescuri)
				    fs.writeFileSync('./database/cla/escuridao.json',JSON.stringify(escuridao))
				    reply(ind.premadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exluz':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnomluz = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = luz
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnomluz) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/cla/luz.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellprem(args[0]))
					await limitAdd(sender)
                    break
				
				    case 'exescuridao':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnomescuridao = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = escuridao
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnomescuridao) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/cla/escuridao.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellprem(args[0]))
					await limitAdd(sender)
                    break
                    case 'escuridao':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const kremescuro = JSON.parse(fs.readFileSync('./database/cla/escuridao.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Da Escuridão 🇧🇷🇯🇵 ]==*\n'
				    for (let premauescuri of kremescuri){
				 	teks += `┣➢👑 @${premauescuri.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢🐺 *Total de membros do clã da ESCURIDÃO* : ${kremescuri.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": escuridao}})
					await limitAdd(sender)
					break
					case 'luz':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const kremluz = JSON.parse(fs.readFileSync('./database/cla/luz.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Da Luz 🇧🇷🇯🇵 ]==*\n'
				    for (let premauluz of kremluz){
				 	teks += `┣➢👑 @${premauluz.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢🐺 *Total de membros do clã da LUZ* : ${kremluz.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": luz}})
					await limitAdd(sender)
					break					
/*
]=============================================================================> MENU DE ADICIONAR OU REMOVER PREVILEGIOS OU CASTIGOS  <=======================================================[
*/					
				    case 'premiar':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnom = `${args[0].replace('@','')}@s.whatsapp.net`
				    prem.push(pnom)
				    fs.writeFileSync('./database/user/prem.json',JSON.stringify(prem))
				    reply(ind.premadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'despremiar':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnom = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = prem
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/prem.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellprem(args[0]))
					await limitAdd(sender)
					break
/*
]======> COMANDO ADICIONAR OU REMOVER DO JOGO (INTELIGENCIA)  <=======================[
*/
				    case 'addjogo':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnomresi = `${args[0].replace('@','')}@s.whatsapp.net`
				    resistencia.push(pnomresi)
				    fs.writeFileSync('./database/user/resistencia.json',JSON.stringify(resistencia))
				    reply(ind.jogoadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exjogo':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnomresi = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = resistencia
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnomresi) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/resistencia.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.delljogo(args[0]))
					await limitAdd(sender)
					break
/*
]============> COMANDO COLOCAR NA LISTA DE PORCOS  <=======================[
*/					
				    case 'addporco':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    if (!isOwner) return reply(ind.ownerb())
				    const pnomporco = `${args[0].replace('@','')}@s.whatsapp.net`
				    porco.push(pnomporco)
				    fs.writeFileSync('./database/user/porco.json',JSON.stringify(porco))
				    reply(ind.porcoadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'libertar':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.deuso())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const hnomporco = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = porco
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnomporco) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/porco.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellporco(args[0]))
					await leimitAdd(sender)
					break
/*
]============> COMANDO COLOCAR NA LISTA DE DIVINDADES  <=======================[
*/
				    case 'divindade':
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.onipo())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const pnom1 = `${args[0].replace('@','')}@s.whatsapp.net`
				    deuses.push(pnom1)
				    fs.writeFileSync('./database/user/deuses.json',JSON.stringify(deuses))
				    reply(ind.deuseadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exdivindade':
					if (!isRegistered) return reply(ind.noregis())
					if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (!isOwner) return reply(ind.onipo())
				    const hnom1 = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = deuses
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom1) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/deuses.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.delldeuse(args[0]))
					await limitAdd(sender)
					break
/*
]============> COMANDO COLOCAR NA LISTA DE ONIPOTENCIAS  <=======================[
*/					
				    case 'oni':
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.ownerb())
				    const pnom2 = `${args[0].replace('@','')}@s.whatsapp.net`
				    oni.push(pnom2)
				    fs.writeFileSync('./database/user/oni.json',JSON.stringify(oni))
				    reply(ind.oniadd(args[0]))
					await limitAdd(sender)
					break
				
				    case 'exoni':
					if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    if (!isOwner) return reply(ind.ownerb())
				    const hnom2 = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = oni
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom2) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/oni.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.delloni(args[0]))
					await limitAdd(sender)
					break
/*
]============> COMANDO COLOCAR NA LISTA DE EXILIO  <=======================[
*/					
					case 'exilar':
					if (isLcimit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    const pnom3 = `${args[0].replace('@','')}@s.whatsapp.net`
				    ban.push(pnom3)
				    fs.writeFileSync('./database/user/ban.json',JSON.stringify(ban))
				    reply(ind.banadd(args[0]))
					await lcimitAdd(sender)
					break
				
				    case 'buscar':
					if (isLcimit(sender)) return reply(ind.limitend(pusname))
					if (!isRegistered) return reply(ind.noregis())
				    const hnom3 = `${args[0].replace('@','')}@s.whatsapp.net`
				    var arr = ban
 			        for( var i = 0; i < arr.length; i++){ 
 		            if ( arr[i] === hnom3) { 
    		      	  arr.splice(i, 1); 
      		   	    i--; 
      				fs.writeFileSync('./database/user/ban.json',JSON.stringify(arr))
       			      }
 			        }
				    reply(ind.dellban(args[0]))
					await lcimitAdd(sender)
					break
/*
]=============================================================================> MENU TESTE <======================================================================[
*/					
				    case 'avaliar':
				if (!isOwner) return reply(ind.ownerb())
                if (!q) return reply(ind.wrongf())
                try {
         	           let evaled = await eval(q)
         	           if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
          	          await reply(evaled)
       	         } catch (err) {
        	            console.error(err)
          	          await reply('Error!')
  	   	       }
					break
/*
]=============================================================================> MENU COMANDOS QUE PODE MEXER NO BOT <===============================================================[
*/					
					case 'lptudo':
				    if (isBanned) return reply(ind.benned())
					if (!isOwner) return reply(ind.ownerb())
					if (!isRegistered) return reply(ind.noregis())	
					anu = await client.chats.all()
					client.setMaxListeners(25)
					for (let _ of anu) {
						client.deleteChat(_.jid)
					}
					reply(ind.clears())
					break
				case 'sair': 
				    if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
				    await reply(from, 'bye').then(() => client.groupLeave(groupId))
				     break
				case 'delete':
				case 'del':
				case 'd':
					if (isBanned) return reply(ind.benned())
				    if (!isGroup) return reply(ind.groupo())
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
					client.deleteMessage(from, { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true })
				    await limitAdd(sender)
					break
/*
]=============================================================================> MENU ALTERAR PREFIXOS <===============================================================[
*/					
				case 'alterar':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    game = args[0]
                    reply(`🐦 *piu* ${game} *Sucesso*`)
					break
				case 'prova':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    gprova = args[0]
                    reply(`🐦 *piu* ${gprova} *Sucesso*`)
					break
				case 'provawin':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    fprova = args[0]
                    reply(`🐦 *piu* ${fprova} *Sucesso*`)
					break
				case 'mudar':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    game1 = args[0]
                    reply(`🐦 *piu* ${game1} *Sucesso*`)
					break
				case 'alterando':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    libi = args[0]
                    reply(`🐦 *piu* ${libi} *Sucesso*`)
					break
				case 'um':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    umm = args[0]
                    reply(`🐦 *piu* ${umm} *Sucesso*`)
					break
				case 'dois':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    doism = args[0]
                    reply(`🐦 *piu* ${doism} *Sucesso*`)
					break
				case 'tres':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    tresm = args[0]
                    reply(`🐦 *piu* ${tresm} *Sucesso*`)
					break
				case 'quatro':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    quatrom = args[0]
                    reply(`🐦 *piu* ${quatrom} *Sucesso*`)
					break
				case 'cinco':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    cincom = args[0]
                    reply(`🐦 *piu* ${cincom} *Sucesso*`)
					break
				case 'seis':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    seism = args[0]
                    reply(`🐦 *piu* ${seism} *Sucesso*`)
					break
				case 'sete':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    setem = args[0]
                    reply(`🐦 *piu* ${setem} *Sucesso*`)
					break
				case 'oito':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    oitom = args[0]
                    reply(`🐦 *piu* ${oitom} *Sucesso*`)
					break
				case 'nove':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    novem = args[0]
                    reply(`🐦 *piu* ${novem} *Sucesso*`)
					break
				case 'dez':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    dezm = args[0]
                    reply(`🐦 *piu* ${dezm} *Sucesso*`)
					break
				case 'quiz':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    umm = args[0]
				    doism = args[0] 
					tresm = args[0]
					quatrom = args[0]
					cincom = args[0]
					seism = args[0]
					setem = args[0]
					oitom = args[0]
					novem = args[0]
					dezm = args[0]
                    reply(`🐦 *piu* palvras resetadas *Sucesso*`)
					break
				case 'setprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
                    prefix = args[0]
                    reply(`🐦 *piu* ${prefix} *Sucesso*`)
					break 
				case 'membros':
					if (args.length < 1) return
					if (!isOwner) return reply(ind.ownerb())
					if (isNaN(args[0])) return reply('*Deve ser um numero*')
                    memberlimit = args[0]
                    reply(`*Alterando a quantidade para ${memberlimit} Sucesso*`)
					break 
					case 'setreply':
					if (!isOwner) return reply(ind.ownerb())
					if (!isRegistered) return reply(ind.noregis())	
                    client.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					cr = body.slice(10)
					reply(`🐺 *Mensagem alterada* 🐺 : ${cr}`)
					await limitAdd(sender)
					break
/*
]=============================================================================> MENU REGISTRAR <===============================================================[
*/					
				case 'registrar':
				if (isBanned) return reply(ind.benned())
                if (isRegistered) return  reply(ind.rediregis())
                if (!q.includes('-')) return  reply(ind.wrongf())
                const namaUser = q.substring(0, q.indexOf('-') - 0)
                const umurUser = q.substring(q.lastIndexOf('-') + 1)
                const serialUser = createSerial(20)
                if(isNaN(umurUser)) return await reply('🦧  *A idade tem que ser um numero* 🦧 ')
                if (namaUser.length >= 30) return reply(`*Seu nome é longo demais*`)
                if (umurUser > 40) return reply(`*Você é muito velho*`)
                if (umurUser < 12) return reply(`*Você é muito novo*`)
                veri = sender
                if (isGroup) {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await reply(ind.registered(namaUser, umurUser, serialUser, time, sender))
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'), 'in', color(sender || groupName))
                } else {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await reply(ind.registered(namaUser, umurUser, serialUser, time, sender))
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'))
                }
					break
/*
]=============================================================================> MENU LISTA DE MENUS <===============================================================[
*/
               case 'help': 
				case 'menu':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (!isRegistered) return reply(ind.noregis())
				    const reqXp  = 5000 * (Math.pow(2, getLevelingLevel(sender)) - 1)
				    const uangku = checkATMuser(sender)
					const ranks = checkNANuser(sender)
					await costum(ind.menu(pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku, role, premi, divindade, onipotente, ranks), text, tescuk, cr)
                    await limitAdd(sender)
					break
				case 'donasi':
				case 'donate':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
					client.sendMessage(from, donasi(), text)
				    break
				case 'menucompleto':
				case 'comandosteste':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')	
					await costum(menucompleto(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
					 break
				case 'menualeatorio':
				case 'aleatorio':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
				if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')	
					await costum(menualeatorio(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					 break
				case 'menucompras':
				case 'resumido':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))		
				if (!isRegistered) return reply(ind.noregis())
					await costum(menucompras(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					 break
				case 'ajudaevento':
				case 'g':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(ajudaevento(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					 break
				case 'menudono':
				case 'editor':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(menudono(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					 break
				case 'menuprevilegio':
				case 'administrador':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(menuprevilegio(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					 break
				case 'titulos':
				case 'aleatorio':
				if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(titulos(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					break
				case 'menuevento':
				case 'menulvl':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(menuevento(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					break
				case 'menuprincipal':
				case 'principal':
				if (isGroup) return  reply( '*🎟️ Use esse comando no meu pv 🎟️*')
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))	
				if (!isRegistered) return reply(ind.noregis())
					await costum(menuprincipal(prefix, pushname, role, getLevelingLevel, sender, premi), text, tescuk, cr)
				    await limitAdd(sender)
					break
/*
]===========================================================================> MENU DE PERMISSOES & ATIVAMENTOS <=================================================================[
*/					
                                case 'antilink':
                  if (isBanned) return reply(ind.baned())				
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())					
					if (args.length < 1) return reply('*Digita 1 para ativar*')
					if (Number(args[0]) === 1) {
						if (isAntiLink) return reply('*Ja esta ativo*')
						antilink.push(from)
						fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
						reply('「 🇯🇵🇧🇷 _Anti Link Ativado No Grupo_ 🇯🇵🇧🇷 」')
						client.sendMessage(from,`🔥 *Se divulgarem link nesse grupo agora é ban na certa* 🔥`, text)
					} else if (Number(args[0]) === 0) {
						antilink.splice(from, 1)
						fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
						reply('「 🇯🇵🇧🇷 _Anti Link Desativado No Grupo_ 🇯🇵🇧🇷 」')
					} else {
						reply('*Digite 1 para ativar e 0 Para desativar*')
					}
					break
                                case 'antitrava':
                  if (isBanned) return reply(ind.baned())				
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())					
					if (args.length < 1) return reply('*Digita 1 para ativar*')
					if (Number(args[0]) === 1) {
						if (isAntiTrava) return reply('*Ja esta ativo*')
						antitrava.push(from)
						fs.writeFileSync('./database/group/antitrava.json', JSON.stringify(antitrava))
						reply('「 🇯🇵🇧🇷 _Anti Trava Ativado No Grupo_ 🇯🇵🇧🇷 」')
						client.sendMessage(from,`🔥 *Se mandarem trava aqui é ban* 🔥`, text)
					} else if (Number(args[0]) === 0) {
						antitrava.splice(from, 1)
						fs.writeFileSync('./database/group/antitrava.json', JSON.stringify(antitrava))
						reply('「 🇯🇵🇧🇷 _Anti Trava Desativado No Grupo_ 🇯🇵🇧🇷 」')
					} else {
						reply('*Digite 1 para ativar e 0 Para desativar*')
					}
					break
                                case 'porco':
                  if (isBanned) return reply(ind.baned())				
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())					
					if (args.length < 1) return reply('Uai Osh')
                if (args[0] === 'ativar') {
                if (isPorco) return reply('_Os Porcos ja estão Contidos_')
                 	   porco.push(from)
                 	   fs.writeFileSync('./database/user/porco.json', JSON.stringify(porco))
                  	   reply(`⛓️ *Os Porcos estão sendo vigiados* ⛓️`)
              	  } else if (args[0] === 'desativar') {
                  	  porco.splice(from, 1)
                 	   fs.writeFileSync('./database/user/porco.json', JSON.stringify(porco))
                 	    reply(`🐖 *Os Porcos estão a solta* 🐖`)
             	   } else {
                 	   reply(ind.satukos())
                	}
					break
                                case 'inteligencia':
                  if (isBanned) return reply(ind.baned())				
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())					
					if (args.length < 1) return reply('Uai Osh')
                if (args[0] === 'ativar') {
                if (isResistencia) return reply('_O jogo ja esta ativo_')
                 	   resistencia.push(from)
                 	   fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(resistencia))
                  	   reply(`⛓️ *Jogo de inteligencia ativado* ⛓️`)
              	  } else if (args[0] === 'desativar') {
                  	  resistencia.splice(from, 1)
                 	   fs.writeFileSync('./database/user/resistencia.json', JSON.stringify(resistencia))
                 	    reply(`🐖 *Jogo de inteligencia desativado* 🐖`)
             	   } else {
                 	   reply(ind.satukos())
                	}
					break	
				case 'nsfw':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isNsfw) return reply('🔑 *Coloca 1 ou 0 na frente com espaço* 🔑')
						nsfw.push(from)
						fs.writeFileSync('./database/bot/nsfw.json', JSON.stringify(nsfw))
						reply('❬ *Sucesso* ❭ NSFW esta ativado no grupo')
					} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./database/bot/nsfw.json', JSON.stringify(nsfw))
						reply('❬ *Sucesso* ❭ NSFW esta desativado no grupo')
					} else {
						reply(ind.satukos())
					}
					break
				case 'bv':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('🦄 *Digita o comando e o 1 ou 0 na frente com espaço* 🦄')
						welkom.push(from)
						fs.writeFileSync('./database/bot/welkom.json', JSON.stringify(welkom))
						reply('❬ *SUCESSO* ❭ 🐰 *Sistema de bem vindo esta ativado nesse grupo* 🐰')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./database/bot/welkom.json', JSON.stringify(welkom))
						reply('❬ *SUCESSO* ❭ 🐰 *Sistema de bem vindo esta desativado nesse grupo* 🐰')
					} else {
						reply(ind.satukos())
					}
					break
				case 'leveling':
				if (isBanned) return reply(ind.benned())
                if (!isGroup) return reply(ind.groupo())
                if (!isGroupAdmins) return reply(ind.admin())
                if (args.length < 1) return reply('Boo :??')
                if (args[0] === 'ativar') {
                    if (isLevelingOn) return reply('🔱 *Use o comando ativar ou desativar na frente com espaço* 🔱')
                    _leveling.push(from)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                     reply(ind.lvlon())
                } else if (args[0] === 'desativar') {
                    _leveling.splice(from, 1)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                     reply(ind.lvloff())
                } else {
                    reply(ind.satukos())
                }
				    break		
				case 'jogo':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isJogo) return reply('🦄 *Ativa ou desativa?* 🦄')
						jogo.push(from)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('🕋 *ATENÇAO GALERA VAI ROLAR QUIZ AGORA FIQUEM LIGADOS* 🕋\n\n🌟 O premio para quem acerta é muito variado 🌟\n\n 💸 _Boa sorte a todos_ 💸 ')
					} else if (Number(args[0]) === 0) {
						jogo.splice(from, 1)
						fs.writeFileSync('./database/bot/jogo.json', JSON.stringify(jogo))
						reply('*❬ 𝗦ucesso ❭ 🐮 O jogo esta desativado*')
					} else {
						reply(ind.satukos())
					}
					break	
				case 'game':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isUm) return reply('🦄 *Ativa ou desativa?* 🦄')
						liberei.push(from)
						um.push(from)
					    dois.push(from)
						tres.push(from)
						quatro.push(from)
						cinco.push(from)
						seis.push(from)
						sete.push(from)
						oito.push(from)
						nove.push(from)
						dez.push(from)
						fs.writeFileSync('./database/quiz/liberei.json', JSON.stringify(liberei))
						fs.writeFileSync('./database/quiz/um.json', JSON.stringify(um))
						fs.writeFileSync('./database/quiz/dois.json', JSON.stringify(dois))
						fs.writeFileSync('./database/quiz/tres.json', JSON.stringify(tres))
						fs.writeFileSync('./database/quiz/quatro.json', JSON.stringify(quatro))
						fs.writeFileSync('./database/quiz/cinco.json', JSON.stringify(cinco))
						fs.writeFileSync('./database/quiz/seis.json', JSON.stringify(seis))
						fs.writeFileSync('./database/quiz/sete.json', JSON.stringify(sete))
						fs.writeFileSync('./database/quiz/oito.json', JSON.stringify(oito))
						fs.writeFileSync('./database/quiz/nove.json', JSON.stringify(nove))
						fs.writeFileSync('./database/quiz/dez.json', JSON.stringify(dez))
						reply('🕋 *ATENÇAO GALERA VAI ROLAR QUIZ AGORA FIQUEM LIGADOS* 🕋\n\n🌟 *ACERTE AS PALAVRAS* 🌟\n\n 💸 _Boa sorte a todos_ 💸 ')
					} else if (Number(args[0]) === 0) {
						liberei.splice(from, 1)
						um.splice(from, 1)
                        dois.splice(from, 1)
						tres.splice(from, 1)
						quatro.splice(from, 1)
						cinco.splice(from, 1)
						seis.splice(from, 1)
						sete.splice(from, 1)
						oito.splice(from, 1)
						nove.splice(from, 1)
						dez.splice(from, 1)
						fs.writeFileSync('./database/quiz/liberei.json', JSON.stringify(liberei))
						fs.writeFileSync('./database/quiz/um.json', JSON.stringify(um))
						fs.writeFileSync('./database/quiz/dois.json', JSON.stringify(dois))
						fs.writeFileSync('./database/quiz/tres.json', JSON.stringify(tres))
						fs.writeFileSync('./database/quiz/quatro.json', JSON.stringify(quatro))
						fs.writeFileSync('./database/quiz/cinco.json', JSON.stringify(cinco))
						fs.writeFileSync('./database/quiz/seis.json', JSON.stringify(seis))
						fs.writeFileSync('./database/quiz/sete.json', JSON.stringify(sete))
						fs.writeFileSync('./database/quiz/oito.json', JSON.stringify(oito))
						fs.writeFileSync('./database/quiz/nove.json', JSON.stringify(nove))
						fs.writeFileSync('./database/quiz/dez.json', JSON.stringify(dez))
						reply('*❬ 𝗦ucesso ❭ 🐮 O jogo esta desativado*')
					} else {
						reply(ind.satukos())
					}
					break	
				case 'evento':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isEventon) return reply('🦄 *Digita o comando e o 1 ou 0 na frente com espaço* 🦄')
						event.push(from)
						fs.writeFileSync('./database/bot/event.json', JSON.stringify(event))
						reply('*❬ 𝗦𝗨cesso ❭ 🐮 Evento esta ativado nesse grupo*')
					} else if (Number(args[0]) === 0) {
						event.splice(from, 1)
						fs.writeFileSync('./database/bot/event.json', JSON.stringify(event))
						reply('*❬ 𝗦ucesso ❭ 🐮 Evento esta desativado nesse grupo*')
					} else {
						reply(ind.satukos())
					}
					break
/*
]===========================================================================> MENU MARCAR <=================================================================[
*/					
				case 'marcar':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `┣➥ 🇯🇵🇧🇷 @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break 
        		case 'online':
				if (!isRegistered) return reply(ind.noregis())
				if (isLcimit(sender)) return reply(ind.limitend(pusname))
        		let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
			    let online = [...Object.keys(client.chats.get(ido).presences), client.user.jid]
			    client.sendMessage(from, '*🕋 Lista De Pessoas Online No Grupo 🕋*\n\n' + online.map(v => '🔛 @' + v.replace(/@.+/, '')).join`\n`, text, { quoted: mek,
  			  contextInfo: { mentionedJid: online }
			    })
				  await lcimitAdd(sender)
					break
/*
]===========================================================================> MENU MODIFICAR COISAS NO GRUPO <=================================================================[
*/					
                case 'linkgp':
				    if (isBanned) return reply(ind.benned())
				    if (!isGroup) return reply(ind.groupo())
				    if (isLcimit(sender)) return reply(ind.limitend(pusname))
					if (!isBotGroupAdmins) return reply(ind.badmin())	
				    linkgc = await client.groupInviteCode (from)
				    yeh = `https://chat.whatsapp.com/${linkgc}\n\n🐺 *Link do grupo* 🐺  *${groupName}*`
				    client.sendMessage(from, yeh, text, {quoted: mek})
			        await lcimitAdd(sender)
					break
					case 'gp':
					case 'grupo':
					if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (isLbimit(sender)) return reply(ind.limitend(pusname))	
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (args[0] === 'abrir') {
					    reply(`🦊 *Grupo aberto* 🦊`)
						client.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'fechar') {
						reply(`🐶 *Grupo fechado* 🐶`)
						client.groupSettingChange(from, GroupSettingChange.messageSend, true)
					}
					await lbimitAdd(sender)
					break    
/*
]===========================================================================> MENU ADICIONAR PESSOAS NO GRUPO <=================================================================[
*/
                    break						
				case 'adicionar':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
				    if (isLdimit(sender)) return reply(ind.limitend(pusname))
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (args.length < 1) return reply('🐺 *Você quer adicionar um gênio?* 🐺')
					if (args[0].startsWith('08')) return reply('🐯 *Use o código do país mas* 🐯 *Exemplo: add 5598452532*')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						client.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :',e)
						reply('⚠️ *Falha ao adicionar destino, talvez porque é privado* ⚠️')
					}
					await ldimitAdd(sender)
					break
/*
]===========================================================================> MENU CONTRATAR & DEMITIR ADMS <=================================================================[
*/
           case 'demitir':
		            if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque Alguem*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `Rebaixado com sucesso :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupDemoteAdmin(from, mentioned)
					} else {
						mentions(`*O* @${mentioned[0].split('@')[0]}  *Acabou de perder o ADM*`, mentioned, true)
						client.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'contratar':
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque Alguem*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `*Contratado com sucesso* :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupMakeAdmin(from, mentioned)
					} else {
						mentions(`*Agora* @${mentioned[0].split('@')[0]} foi contratado como ADM* 🐼`, mentioned, true)
						client.groupMakeAdmin(from, mentioned)
					}
					break	
/*
]=======================================================================> Menu De Bans <===============================================================================[
*/
                    case 'contagem':
			if (isBanned) return reply(ind.benned())    
				if (!isRegistered) return reply(ind.noregis())
				if (isLgimit(sender)) return reply(ind.limitend(pusname))	
					if (!isGroup) return reply(ind.groupo())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('A marca-alvo que você deseja chutar!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedido recebido, emitido\n'
						for (let i= 0; i < 1; mentioned) {
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						 client.groupRemove(from, mentioned)
					} else {
						setTimeout( () => {
						mentions(`🛡️ *Contagem regressiva para eu te apagar* 🛡️ @${mentioned[0].split('@')[0]}`, mentioned, true)
						}, 1000)
					setTimeout( () => {
					 client.groupRemove(from, mentioned, {quoted: mek}) // ur cods
					}, 35000)
					setTimeout( () => {
					 client.sendMessage(from, '🛡️ *Tiro Confirmado, Na Cabeça Do Alvo, HeadShot Lindo !!!* 🛡️', text) // ur cods
					}, 30000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ ( ऀืົཽ₍₍ළ₎₎ ऀืົཽ)▄︻̷̿┻̿═━一 💥💥💥 🛡️*', text) // ur cods
					}, 20000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ Ajustando Mira He He He 🛡️*', text) // ur cods
					}, 10000)
					setTimeout( () => {
					 client.sendMessage(from, '*🛡️ Preparando Para Mirar 🛡️*', text, { quoted: mek }) // ur cods
					}, 5000)
					}
					await lgimitAdd(sender)
					break
			     	case 'ban':
					if (isBanned) return reply(ind.benned())
				    if (isLgimit(sender)) return reply(ind.limitend(pusname))
					if (!isGroup) return reply(ind.groupo())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque alguem que deseje banir*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let i= 0; i < 1; mentioned) {
							teks += `Pedidos recebidos, emitidos  :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`😨😨😨 @${mentioned[0].split('@')[0]} *foi banido 🦊* `, mentioned, true)
						client.groupRemove(from, mentioned)
					}
					await lgimitAdd(sender)
					break	
/*
]=============> COMANDO PARA DAR BAN SO MEMBROS PREMIUMS <================[
*/
			     	case 'banpremium':
					if (isBanned) return reply(ind.benned())
					if (!isPrem) return reply(ind.premon(pushname))	
				    if (isLfimit(sender)) return reply(ind.limitend(pusname))
					if (!isGroup) return reply(ind.groupo())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque alguem que deseje banir*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let i= 0; i < 1; mentioned) {
							teks += `Pedidos recebidos, emitidos  :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`😨😨😨 @${mentioned[0].split('@')[0]} *foi banido 🦊* `, mentioned, true)
						client.groupRemove(from, mentioned)
					}
					await lfimitAdd(sender)
					break	
/*
]=============> COMANDO PARA DAR BAN SO MEMBROS DIVINDADES <================[
*/
			     	case 'bandivino':
					if (isBanned) return reply(ind.benned())
					if (!isDeuses) return reply(ind.deuso(pushname))	
				    if (isLeimit(sender)) return reply(ind.limitend(pusname))
					if (!isGroup) return reply(ind.groupo())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('*Marque alguem que deseje banir*')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let i= 0; i < 1; mentioned) {
							teks += `Pedido recebido, emitido\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`😨😨😨 @${mentioned[0].split('@')[0]} *foi banido 🦊* `, mentioned, true)
						client.groupRemove(from, mentioned)
					}
					await leimitAdd(sender)
					break 
/*
]=============> COMANDO PARA REMOVER TODO MUNDO <================[
*/
                    case 'kickall':
                    if (!isOwner) return reply(ind.ownerb())
					if (!isRegistered) return reply(ind.noregis())	
			        members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `*😘* ${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					client.groupRemove(from, members_id)
					break
/*
]=======================================================================> MENU LISTA DE PREVILEGIOS E CASTIGO <===============================================================================[
*/	
				case 'adms':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					teks = `🔰 *Lista de admins do grupo* 🔰 *${groupMetadata.subject}*\n🔓 *Total* 🔒 : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					await limitAdd(sender)
					break
					case 'premiuns':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem = JSON.parse(fs.readFileSync('./database/user/prem.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Premiums 🇧🇷🇯🇵 ]==*\n'
				    for (let premau of krem){
				 	teks += `┣➢👑 @${premau.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢🐺 *Total de usuarios premiums* : ${krem.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": prem}})
					await limitAdd(sender)
					break
				case 'divindades':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem1 = JSON.parse(fs.readFileSync('./database/user/deuses.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Deuses 🇧🇷🇯🇵 ]==*\n'
				    for (let premau1 of krem1){
					teks += `┣➢👑 @${premau1.replace('@s.whatsapp.net','')}\n`
				    }
			 	    teks += `┣➢🐺 *Total de usuarios Deuses* : ${krem1.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": deuses}})
					await limitAdd(sender)
					break
				case 'participantes':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const kremresi = JSON.parse(fs.readFileSync('./database/user/resistencia.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Participantes Do Jogo  🇧🇷🇯🇵 ]==*\n'
				    for (let premauresi of kremresi){
					teks += `┣➢👑 @${premauresi.replace('@s.whatsapp.net','')}\n`
				    }
			 	    teks += `┣➢🐺 *Total Participantes* : ${kremresi.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": resistencia}})
					await limitAdd(sender)
					break
				case 'porcos':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem9 = JSON.parse(fs.readFileSync('./database/user/porco.json'))
				    teks = '🐖 *A famosa Lista Dos Porcos* 🐖\n'
				    for (let premau9 of krem9){
					teks += `┣➢🐷 @${premau9.replace('@s.whatsapp.net','')}\n`
				    }
			 	    teks += `┣➢🐽 *Total de usuarios Porcos* : ${krem9.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": porco}})
					await limitAdd(sender)
					break
				case 'onipotencias':
				    if (isBanned) return reply(ind.benned())
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem2 = JSON.parse(fs.readFileSync('./database/user/oni.json'))
				    teks = '*==[ 🇧🇷🇯🇵 Membros Onipotentes 🇧🇷🇯🇵 ]==*\n'
				    for (let premau2 of krem2){
					teks += `┣➢👑 @${premau2.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢🐺 *Total de usuarios Onipotentes* : ${krem2.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": oni}})
					await limitAdd(sender)
				    break
				case 'exilados':
                    if (isBanned) return reply(ind.benned())				
				    if (!isRegistered) return reply( ind.noregis()) 
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
				    const krem3 = JSON.parse(fs.readFileSync('./database/user/ban.json'))
				    teks = '*==[ 🇧🇷🇯🇵 ⚔️ Exilado ⚔️ 🇧🇷🇯🇵 ]==*\n'
				    for (let premau3 of krem3){
					teks += `┣➢🛡️ @${premau3.replace('@s.whatsapp.net','')}\n`
				    }
				    teks += `┣➢⌛ *Total de usuarios Exilados* : ${krem3.length}`
				    client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": ban}})	
					await limitAdd(sender)
					break
				case 'bloqueados': 
				    if (isBanned) return reply(ind.benned())
					if (isLimit(sender)) return reply(ind.limitend(pusname))	
					teks = 'LISTA DE BLOQUEADOS :\n'
					for (let block of blocked) {
						teks += `┣➢ 🇯🇵🇧🇷 @${block.split('@')[0]}\n`
					}
					teks += `𝗧𝗼𝘁𝗮𝗹 : ${blocked.length}`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					await limitAdd(sender)
					break
/*
]=======================================================================> SIMI <===============================================================================[
*/
                 case 'simi':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if (args.length < 1) return reply('*Cade o texto?*')
					teks = body.slice(5)
					anu = await simih(teks) 
					reply(anu)
				    await limitAdd(sender)
					break
				case 'simih':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (args.length < 1) return reply('Boo :𝘃')
					if (Number(args[0]) === 1) {
						if (isSimi) return reply('*Piu*')
						samih.push(from)
						fs.writeFileSync('./database/bot/simi.json', JSON.stringify(samih))
						reply('simi ativado neste grupo')
					} else if (Number(args[0]) === 0) {
						samih.splice(from, 1)
						fs.writeFileSync('./database/bot/simi.json', JSON.stringify(samih))
						reply('simi Desativado neste grupo')
					} else {
						reply(ind.satukos())
					}
					await limitAdd(sender)
					break
/*
]================================================================================> MENU DE INFORMAÇOES SOBRE O BOT <==========================================================================================================[
*/				                    
                case 'admin':
                case 'dono':
                case 'creator':
			         if (isBanned) return reply(ind.benned())
                     client.sendMessage(from, {displayname: "Nan", vcard: vcard}, MessageType.contact, { quoted: mek})
                     client.sendMessage(from, '*Esse é o numero do meu dono, cuidado quando for mandar mensagem para ele, voce pode ser bloqueado*',MessageType.text, { quoted: mek} )
                break
				case 'info':
				    if (isBanned) return reply(ind.benned())
					me = client.user
					uptime = process.uptime()
					teks = `*Nome bot* : ${me.name}\n*DONO* : *Nando*\n*AUTOR* : Nando\n*NUMERO* : @${me.jid.split('@')[0]}\n*Prefix* : ${prefix}\n*TOTAL CONTATOS BLOQUEADOS* : ${blocked.length}\n\n*BOT ESTA ATIVADO* : ${kyun(uptime)}`
					buffer = await getBuffer(me.imgUrl)
					client.sendMessage(from, buffer, image, {caption: teks, contextInfo:{mentionedJid: [me.jid]}})
				break
/*
]=============================================================================> MENU DE BAIXAR MODS APK <==========================================================================[
*/
                case 'mod':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			data = await fetchJson(`https://tobz-api.herokuapp.com/api/moddroid?q=${body.slice(10)}&apikey=BotWeA`)
			hepi = data.result[0] 
			teks = `*Nama*: ${data.result[0].title}\n*publisher*: ${hepi.publisher}\n*mod info:* ${hepi.mod_info}\n*size*: ${hepi.size}\n*latest version*: ${hepi.latest_version}\n*genre*: ${hepi.genre}\n*link:* ${hepi.link}\n*download*: ${hepi.download}`
			buffer = await getBuffer(hepi.image)
			client.sendMessage(from, buffer, image, {quoted: mek, caption: `${teks}`})
			await limitAdd(sender)	
			    break
			case 'modx':
			   if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
			data = await fetchJson(`https://tobz-api.herokuapp.com/api/happymod?q=${body.slice(10)}&apikey=BotWeA`)
			hupo = data.result[0] 
			teks = `*Nama*: ${data.result[0].title}\n*version*: ${hupo.version}\n*size:* ${hupo.size}\n*root*: ${hupo.root}\n*purchase*: ${hupo.price}\n*link*: ${hupo.link}\n*download*: ${hupo.download}`
			buffer = await getBuffer(hupo.image)
			client.sendMessage(from, buffer, image, {quoted: mek, caption: `${teks}`})
			await limitAdd(sender)
				break
/*
]=============================================================================> MENU DE BAIXAR MUSICAS E BAIXAR LETRAS DE MUSICAS <==========================================================================[
*/
				case 'music':
		if (isBanned) return reply(ind.benned())
		if (isLimit(sender)) return reply(ind.limitend(pusname))
		if (!isRegistered) return reply(ind.noregis())
                teks = body.slice(7)
		    anu = await fetchJson(`http://scrap.terhambar.com/lirik?word=${teks}`, {method: 'get'})
		    reply('✒️ *Letra da musica* ✒️ '+teks+' 🎼🎤 :\n\n'+anu.result.lirik)
		await limitAdd(sender)
		    break
                case 'boxmsc':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
                data = await fetchJson(`https://tobz-api.herokuapp.com/api/joox?q=${body.slice(6)}&apikey=BotWeA`, {method: 'get'})
               if (data.error) return reply(data.error)
                 infomp3 = `*🇧🇷🇯🇵 Canção encontrada 🇧🇷🇯🇵*\n*🎧 Titulo 🎧* : ${data.result.judul}\n*🎧 Album 🎧* : ${data.result.album}\n*🎧 Publicados 🎧*: ${data.result.dipublikasi}`
                buffer = await getBuffer(data.result.thumb)
                lagu = await getBuffer(data.result.mp3)
                client.sendMessage(from, buffer, image, {quoted: mek, caption: infomp3})
                client.sendMessage(from, lagu, audio, {mimetype: 'audio/mp4', filename: `${data.result.title}.mp3`, quoted: mek})
                await limitAdd(sender)
				break 
/*
]=============================================================================> MENU QUE TRANSFORMA VIDEOS EM AUDIO <==========================================================================[
*/
				case 'audio':
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (isBanned) return reply(ind.benned())
			    if (!isRegistered) return reply(ind.noregis())
				client.updatePresence(from, Presence.composing)
				if (!isQuotedVideo) return reply('*Isso é um video?*')
				reply(ind.wait())
				encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				media = await client.downloadAndSaveMediaMessage(encmedia)
				ran = getRandom('.mp4')
				exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media)
					if (err) return reply('*Oloco*')
					buffer = fs.readFileSync(ran)
					client.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek })
					fs.unlinkSync(ran)
				})
				await limitAdd(sender)
				break
/*
]=============================================================================> MENU DE BAIXAR AUDIOS E VIDEOS DO YOUTUBE <==========================================================================[
*/
					case 'tube':
				if (isBanned) return reply(ind.benned())	  
				if (!isRegistered) return reply(ind.noregis())
			    if (isLimit(sender)) return reply(ind.limitend(pusname))
                if (args.length < 1) return reply('🐤 *Cade o Texto?* 🐤')
				client.updatePresence(from, Presence.composing)	
			        texto = blody.slice(9)
					anu = await fetchJson(`http://indonesian-java-security.ezyro.com/playmp3.php?apikey=FarhanXCode7&query=${texto}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
				    esc = `${anu.result}`
					teks = `*Titulo* : ${anu.title}\n*Tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.esc.image)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.esc.mp3)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
					await limitAdd(sender)
                break
                case 'yta':
				    if (isBanned) return reply(ind.benned())
                    if (!isRegistered) return reply(ind.noregis())
                    if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply('🐤 *Cade a URL?* 🐤')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(ind.wrogf())
					anu = await fetchJson(`https://st4rz.herokuapp.com/api/yta2?url=${args[0]}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Titulo* : ${anu.title}\n*Tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
					await limitAdd(sender)
                break		
                case 'ytv':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
					if (args.length < 1) return reply('🐦 *Cade a URL mano* 🐦')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(ind.stikga())
					anu = await fetchJson(`https://st4rz.herokuapp.com/api/ytv2?url=${args[0]}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Titulo* : ${anu.title}\n*tamanho* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
					await limitAdd(sender)	
                break
/*
]=============================================================================> MENU DE VOZ <==========================================================================[
*/
				case 'voz':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				if (args.length < 1) return client.sendMessage(from, '⚜️ *Codigo idioma necessario* ⚜️', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return client.sendMessage(from, '🇧🇷 *qual texto voce esta criando? minha? voz?* 🇯🇵', text, {quoted: mek})
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 600
					? reply('*bem falhe, repeti dnv* 😤')
					: gtts.save(ranm, dtt, function() {
						exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
							fs.unlinkSync(ranm)
							buffer = fs.readFileSync(rano)
							if (err) return reply('😤:(')
							client.sendMessage(from, buffer, audio, {quoted: mek, ptt:true})
							fs.unlinkSync(rano)
						})
					})
					await limitAdd(sender)					
					break
/*
]=============================================================================> MENU DO TIKTOK <==========================================================================[
*/
					case 'tiktok':
				if (isBanned) return reply(ind.benned())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				anu = await fetchJson (`https://docs-jojo.herokuapp.com/api/tiktok_nowm?url=${args[0]}`, {method : 'get' })
				if (anu.error) return reply(anu.error)
					teks = `*A partir* : ${anu.result.from}\n*Título* : ${anu.result.title}\n*Envio* : ${anu.result.uploaded}`
					thumb = await getBuffer(anu.result.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result.url)
					client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
					await limitAdd(sender)
					break 
				case 'tiktokstalk':
				if (isBanned) return reply(ind.benned())
				if (!isRegistered) return reply(ind.noregis())
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				try {
						if (args.length < 1) return client.sendMessage(from, '*Nome do usuario*', text, {quoted: mek})
						let { user, stats } = await tiktod.getUserProfileInfo(args[0])
						reply(ind.wait())
						teks = `*ID* : ${user.id}\n*Nome de usuario* : ${user.uniqueId}\n*Nome* : ${user.nickname}\n*Seguidores* : ${stats.followerCount}\n*Seguindo* : ${stats.followingCount}\n*Posts* : ${stats.videoCount}\n*Curtidas* : ${stats.heart}\n`
						buffer = await getBuffer(user.avatarLarger)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('[𝗘𝗥𝗥𝗢𝗥] ❌ *Nome de usuario invalido ou incorreto* ❌')
					}
					await limitAdd(sender)
					break
				case 'wait':
				    if (isLimit(sender)) return reply(ind.limitend(pusname))
				    if (isBanned) return reply(ind.benned())
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(ind.wait())
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await client.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							client.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply(ind.ocron())
					}
					await limitAdd(sender)
					break
				default:
			if (body.startsWith(`${prefix}${command}`)) {
                  reply(`*Esse comando não tem no menu*`)
                  }
			if (/^>/.test(tas)) {
	            let txt = tas.replace(/^>/, '')
	            let type = Function
	            if (/await/.test(tas)) type = (async () => {}).constructor
	            let func = new type('print', 'client', 'MessageType', 'mek', 'text', 'from', 'image', 'os', 'fetch', txt)
	            console.log('[EvalF]', func.toString())
	            let output
	            try {
	                output = await func((...args) => {
	                    console.log('[EvalP]', ...args)
	                    client.sendMessage(from, util.format(...args), MessageType.extendedText, {
	                        quoted: mek
	                    })
	                }, client, MessageType, mek, text, from, await image, os, fetch)
	                console.log('[EvalO]', output)
	                client.sendMessage(from, util.format(output), MessageType.extendedText, {
	                    quoted: mek
	                })
	            } catch (e) {
	                console.error('[EvalE]', e)
	                client.sendMessage(from, util.format(e), MessageType.extendedText, {
	                    quoted: mek
	                })
	            }
            }
			if (isGroup && !isCmd && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						reply(ind.cmdnf(prefix, command))
					} else {
						console.log(color('[ERROR]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
					}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})